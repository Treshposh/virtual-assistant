const fs=require('fs'),vm=require('vm');
const ctx={console,setTimeout,clearTimeout,Math,Date,JSON,window:{},document:{querySelector(){},querySelectorAll(){return[]}},UI:{toast(){},celebrate(r){ctx.celebrated=r},render(){}},toast(){}};
vm.createContext(ctx);
const src=fs.readFileSync(__dirname+'/../web/src/01-core.js','utf8')+fs.readFileSync(__dirname+'/../web/src/02-engine.js','utf8')+`
;globalThis.T={D,resolveWhen,splitQuickAdd,S:()=>S,createTask,buildPlan,approvePlan,recommendNow,rescheduleOptions,rescheduleText,moveTask,completeTask,addHabit,addEvent,streak,weekStats,KB,chunkText,tokens,fitTime,claimReward,award,toggleHabit,habitDueOn,nowNext,goalProgress};`;
vm.runInContext(src,ctx);
const {D,resolveWhen}=ctx.T; const base='2026-09-23'; // Wednesday
const cases=[['tomorrow','2026-09-24'],['next thursday','2026-10-01'],['thursday','2026-09-24'],['before Friday','2026-09-25'],['in six months','2027-03-23'],['before October','2026-09-30'],['october 12','2026-10-12'],['by end of week','2026-09-25'],['next week','2026-09-28'],['this weekend','2026-09-26'],['today at 3pm','2026-09-23'],['in 2 weeks','2026-10-07'],['March 3','2027-03-03'],['in October','2026-10-31'],['day after tomorrow','2026-09-25']];
let fail=0;for(const [q,exp] of cases){const r=resolveWhen(q,base);const ok=r&&r.date===exp;if(!ok)fail++;console.log(ok?'ok ':'BAD',q,'->',r&&r.date,r&&r.time,ok?'':'(expected '+exp+')');}
console.log('time 3pm:',resolveWhen('move to 3 PM',base).time, 'at 4:', resolveWhen('call john at 4',base).time);
console.log(ctx.T.splitQuickAdd('Call John tomorrow at 3pm'));
// planner
const T=ctx.T,S=T.S();
S.profile.wake='07:00';S.profile.sleep='23:00';S.profile.freeHours={weekday:4,weekend:6};
T.addEvent({title:'School',days:[1,2,3,4,5],start:'09:00',end:'14:00'});
T.addHabit({title:'Exercise',perWeek:3,durMin:45,preferredTime:'evening'});
const tomorrow=D.add(D.today(),1);
['Finish proposal|120|high','Build website hero|180|high','Read 3 chapters|90|low','Study|300|medium','Email investors|30|medium'].forEach(s=>{const [t,e,p]=s.split('|');T.createTask({title:t,estMin:+e,priority:p,planDate:tomorrow});});
const p=T.buildPlan(tomorrow);
console.log('budget',p.budget,'requested',p.requested,'used',p.used,'overloaded',p.overloaded);
p.blocks.forEach(b=>console.log(' ',D.fmtRange(b.start,b.end),b.type,b.title));
console.log(' overflow:',p.overflow.map(o=>o.title+' ('+o.reason+')'));
T.approvePlan(p);
const t=Object.values(S.tasks.items)[0];
const ro=T.rescheduleOptions(t);console.log('resched',ro.options.map(o=>o.label+(o.recommended?' *':'')));console.log(T.rescheduleText(t,ro));
T.completeTask(t.id);console.log('balance',S.rewards.balance,'streak',T.streak());
S.rewards.rules.push({id:'r1',title:'Movie night',cost:20});T.award(5,'x');console.log('celebrated',ctx.celebrated&&ctx.celebrated.title);
console.log('recommend',JSON.stringify(T.recommendNow(),(k,v)=>k==='alternatives'?undefined:v).slice(0,300));
console.log('fit 120',T.fitTime(120).picks.map(x=>x.title));
console.log('chunks',T.chunkText('Launch plan. '.repeat(300)).length);
console.log('fails',fail);
