const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const app=fs.readFileSync(__dirname+'/../web/della.html','utf8');
 const html='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><script>'+fs.readFileSync(__dirname+'/mock.js','utf8')+'</script></head><body>'+app+'</body></html>';
 fs.writeFileSync('/tmp/della-test.html',html);
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:400,height:860}});
 const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
 await p.route('**/fonts.googleapis.com/**',r=>r.abort());
 await p.goto('file:///tmp/della-test.html');await p.waitForTimeout(800);
 const step=async(n)=>{console.log('--',n);};
 const click=async(sel)=>{await p.click(sel);await p.waitForTimeout(350)};
 await step('onboarding visible: '+(await p.textContent('.q')));
 await click('[data-act="ob-quick"]'); // skip setup → brain dump sheet
 await p.keyboard.press('Escape');await p.waitForTimeout(200);
 // FINAL SCENARIO via chat
 await click('[data-act="go"][data-tab="assistant"]');
 await p.fill('#composer',"I want to launch my business in six months. I need to learn the technology, build the product, find customers, create a website, create social media content, and talk to investors. I also have school and exercise three times a week.");
 await p.click('#composer-form button[type=submit]');await p.waitForTimeout(1500);
 console.log('chat receipts:',await p.$$eval('.receipt',e=>e.map(x=>x.textContent.trim())));
 await p.waitForSelector('[data-act="dc-commit"]',{timeout:5000});
 console.log('decomp crumb:',await p.textContent('.sheet .crumb'));
 await p.fill('#dc-cs-0','08:00');await p.fill('#dc-ce-0','14:00');
 await p.screenshot({path:'/tmp/s-decomp.png'});
 await click('[data-act="dc-commit"]');
 console.log('plan sheet:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,400));
 await p.screenshot({path:'/tmp/s-plan.png'});
 await click('[data-act="plan-approve"]');
 await click('[data-act="go"][data-tab="home"]');
 await p.screenshot({path:'/tmp/s-home.png',fullPage:true});
 console.log('home now:',(await p.textContent('#view')).replace(/\s+/g,' ').slice(0,300));
 // what now
 await click('[data-act="now"]');console.log('what now:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,250));await click('[data-act="close"]');
 // reminders + check-in: shift first task block into the past
 const r=await p.evaluate(()=>{const d=S.plan.days[D.today()];const b=d.blocks.find(x=>x.type==='task');const n=D.nowMin();b.start=n-40;b.end=n-2;b.startPrompted=true;checkinTick();return b.title});
 await p.waitForTimeout(300);console.log('checkin for',r,':',await p.textContent('#checkin-slot'));
 await click('[data-act="ci"][data-v="partial"]');
 console.log('reschedule sheet:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,300));
 await click('.sheet [data-act="move-to"]');
 // complete a task, points
 const pts0=await p.evaluate(()=>S.rewards.balance);
 await p.evaluate(()=>{const t=openTasks().find(t=>t.priority==='high');completeTask(t.id);UI.render()});
 console.log('points',pts0,'->',await p.evaluate(()=>S.rewards.balance),'streak',await p.evaluate(()=>streak()));
 // reward unlock
 await p.evaluate(()=>{S.rewards.rules=[{id:'r1',title:'Movie night',cost:30,claimed:0}];award(5,'x')});await p.waitForTimeout(700);
 console.log('celebrate:',(await p.textContent('#sheet-slot')).replace(/\s+/g,' ').slice(0,160));
 await click('[data-act="claim"]');
 // stuck
 await p.evaluate(()=>openStuck(openTasks()[0].id));await p.waitForTimeout(200);await click('#st-chips .chip');await click('[data-act="st-go"]');await p.waitForTimeout(600);
 console.log('stuck:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,200));await click('[data-act="close"]');
 // chat: couldn't finish, remind me, memory w/ doc
 await click('[data-act="go"][data-tab="assistant"]');
 for(const m of ["I couldn't finish the problem statement","Remind me to call John tomorrow"]){await p.fill('#composer',m);await p.click('#composer-form button[type=submit]');await p.waitForTimeout(900);}
 console.log('last receipts/cards:',(await p.$$eval('.msg.ai',e=>e.slice(-2).map(x=>x.textContent.replace(/\s+/g,' ').trim().slice(0,160)))));
 await p.evaluate(async()=>{await KB.add('launch-plan.txt','Launch plan. Target launch period: November. Current milestone: completing the MVP. Budget is small.')});
 await p.fill('#composer','What did I say about my business launch?');await p.click('#composer-form button[type=submit]');await p.waitForTimeout(900);
 console.log('memory answer:',(await p.$$eval('.msg.ai',e=>e.at(-1).textContent.replace(/\s+/g,' ').trim())));
 console.log('retrieval got excerpt:',await p.evaluate(()=>KB.search('What did I say about my business launch?').map(c=>c.name)));
 await p.screenshot({path:'/tmp/s-chat.png'});
 // overwhelm → brain dump
 await p.fill('#composer',"I have a lot to do. I don't know where to start.");await p.click('#composer-form button[type=submit]');await p.waitForTimeout(400);
 console.log('dump mode reply:',(await p.$$eval('.msg.ai',e=>e.at(-1).textContent.trim())));
 await p.fill('#composer',"I need to call David, finish the proposal, read that book, exercise three times this week, research the new business idea, remember to buy groceries and prepare for Friday's meeting.");
 await p.click('#composer-form button[type=submit]');await p.waitForSelector('[data-act="dump-commit"]',{timeout:5000});
 console.log('dump headline:',await p.textContent('#dump-head'));
 await click('[data-act="dump-commit"]');
 console.log('dump result:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,420));
 await p.screenshot({path:'/tmp/s-dump.png'});
 await click('[data-act="close"]');
 // today, goals, progress + weekly review
 for(const t of ['today','goals','progress']){await click(`[data-act="go"][data-tab="${t}"]`);await p.screenshot({path:`/tmp/s-${t}.png`,fullPage:true});}
 await click('[data-act="go"][data-tab="goals"]');await click('[data-act="goal"]');await p.screenshot({path:'/tmp/s-goal.png',fullPage:true});
 await click('[data-act="go"][data-tab="progress"]');await click('[data-act="review"]');await p.waitForTimeout(700);
 console.log('review:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,300));await click('[data-act="close"]');
 // persistence: reload, same mock store survives? store is per page; emulate by reading store keys
 await p.waitForTimeout(1200);
 console.log('stored docs:',await p.evaluate(()=>[...__store.keys()].map(k=>k.split('/').pop()+':'+JSON.stringify(__store.get(k)).length)));
 console.log('AI calls:',await p.evaluate(()=>__calls.length));
 console.log('ERRORS:',errs);
 await b.close();
})();
