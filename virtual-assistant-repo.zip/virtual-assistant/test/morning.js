const {chromium}=require('playwright');
(async()=>{
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:400,height:860}});
 const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route('**/fonts.googleapis.com/**',r=>r.abort());
 await p.clock.install({time:new Date('2026-09-24T09:30:00')});
 await p.goto('file:///tmp/della-test.html');await p.clock.runFor(1500);
 await p.click('[data-act="ob-quick"]');await p.keyboard.press('Escape');
 await p.evaluate(()=>{['Draft chapter 2|90|high','Email supervisor|15|medium','Clean data set|60|medium'].forEach(s=>{const[a,e,pr]=s.split('|');createTask({title:a,estMin:+e,priority:pr,planDate:D.today()})});createTask({title:'Submit abstract',estMin:120,due:D.add(D.today(),1),priority:'high'});createTask({title:'Slides',estMin:180,due:D.add(D.today(),1),priority:'high'});addHabit({title:'Exercise',perWeek:3,durMin:45,preferredTime:'evening'});UI.render()});
 await p.clock.runFor(500);
 console.log('home:',(await p.textContent('#view')).replace(/\s+/g,' ').slice(0,520));
 await p.screenshot({path:'/tmp/m-home.png'});
 await p.click('[data-act="brief-start"]');await p.clock.runFor(400);
 console.log('plan blocks:',await p.evaluate(()=>S.plan.days[D.today()].blocks.map(b=>D.toHHMM(b.start)+' '+b.title).join(' | ')));
 // delay: first block ran long → still working → shift rest
 await p.evaluate(()=>{const d=S.plan.days[D.today()];const bl=d.blocks.filter(b=>b.type==='task');bl[0].start=D.nowMin()-50;bl[0].end=D.nowMin()-5;bl[0].startPrompted=true;bl[1].start=D.nowMin()+5;bl[1].end=bl[1].start+15;UI.checkin=null;checkinTick()});
 await p.clock.runFor(300);
 await p.click('[data-act="ci"][data-v="working"]');await p.clock.runFor(300);
 console.log('toast:',await p.textContent('#toast-slot'));
 await p.click('#toast-slot button');await p.clock.runFor(300);
 console.log('reflow sheet:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,300));
 await p.click('[data-act="reflow-apply"]');await p.clock.runFor(300);
 console.log('after reflow:',await p.evaluate(()=>S.plan.days[D.today()].blocks.filter(b=>b.status!=='moved').map(b=>D.toHHMM(b.start)+' '+b.title+' ['+b.status+']').join(' | ')));
 // week plan
 await p.evaluate(()=>ACT.week());await p.clock.runFor(300);
 console.log('week sheet:',(await p.textContent('.sheet .sb')).replace(/\s+/g,' ').slice(0,380));
 await p.screenshot({path:'/tmp/m-week.png'});
 await p.click('[data-act="week-apply"]');await p.clock.runFor(300);
 // recurrence in task sheet
 await p.evaluate(()=>openTaskSheet(openTasks()[0].id));await p.clock.runFor(200);
 await p.click('[data-act="t-rec"][data-v="weekdays"]');await p.clock.runFor(200);
 console.log('recurrence:',await p.evaluate(()=>openTasks()[0].recurrence));
 // evening wrap-up
 await p.keyboard.press('Escape');
 await p.clock.setFixedTime(new Date('2026-09-24T20:00:00'));await p.evaluate(()=>UI.render());
 console.log('evening:',(await p.textContent('#view')).replace(/\s+/g,' ').slice(0,360));
 await p.screenshot({path:'/tmp/m-eve.png'});
 await p.click('[data-act="wrap-move"]');
 console.log('after wrap:',await p.evaluate(()=>openTasks().filter(t=>t.planDate===D.add(D.today(),1)).map(t=>t.title).join(', ')));
 console.log('ERRORS',errs);await b.close();
})();
