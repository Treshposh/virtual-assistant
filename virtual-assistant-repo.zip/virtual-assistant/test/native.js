const {chromium}=require('playwright');const fs=require('fs');
(async()=>{
 const mod=fs.readFileSync(__dirname+'/../mobile/della-html.js','utf8');const html=JSON.parse(mod.slice(mod.indexOf('export default ')+15).trim().replace(/;$/,''));
 const bridge=`window.__msgs=[];window.__db={};window.__key=null;window.ReactNativeWebView={postMessage(s){const m=JSON.parse(s);window.__msgs.push(m.type);setTimeout(()=>{let ok=true,d=null;
  if(m.type==='db.get')d=window.__db[m.path]?JSON.parse(window.__db[m.path]):null;
  else if(m.type==='db.set')window.__db[m.path]=JSON.stringify(m.data);
  else if(m.type==='key.set')window.__key=m.key; else if(m.type==='key.status')d=!!window.__key;
  else if(m.type==='reminders'){window.__rem=m.items;d={scheduled:m.items.length}}
  else if(m.type==='ai'){ if(!window.__key){ok=false;d={code:'no_key',message:'x'}} else d='Sure thing.\\n{"reply":"Noted.","actions":[{"type":"add_task","title":"Call John","when":"tomorrow 3pm","estMin":15}]}'; }
  window.__nativeReply(m.id,ok,d)},30)}};`;
 fs.writeFileSync('/tmp/native.html',html.replace('<head>','<head><script>'+bridge+'</script>'));
 const b=await chromium.launch();const p=await b.newPage({viewport:{width:390,height:844}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.route('**/fonts.googleapis.com/**',r=>r.abort());
 await p.clock.install({time:new Date('2026-09-24T09:00:00')});
 await p.goto('file:///tmp/native.html');await p.clock.runFor(1500);
 console.log('mode:',await p.evaluate(()=>Store.mode),'onboarding:',!!(await p.$('.onb')));
 await p.click('[data-act="ob-quick"]');await p.keyboard.press('Escape');
 await p.click('[data-act="go"][data-tab="assistant"]');
 await p.fill('#composer','Remind me to call John tomorrow at 3pm');await p.click('#composer-form button[type=submit]');await p.clock.runFor(800);
 console.log('no key →',(await p.$$eval('.msg.ai',e=>e.at(-1).textContent.replace(/\s+/g,' ').trim())));
 await p.evaluate(()=>openSettings());await p.clock.runFor(200);
 await p.fill('#api-key','sk-ant-test');await p.click('[data-form="api-key"] button');await p.clock.runFor(500);
 await p.keyboard.press('Escape');
 await p.click('[data-act="retry"]');await p.clock.runFor(800);
 console.log('with key →',(await p.$$eval('.msg.ai',e=>e.at(-1).textContent.replace(/\s+/g,' ').trim())));
 await p.evaluate(()=>{createTask({title:'Write report',estMin:60,planDate:D.today(),priority:'high'});approvePlan(buildPlan(D.today()));});await p.clock.runFor(3500);
 console.log('reminders:',await p.evaluate(()=>(window.__rem||[]).map(r=>new Date(r.at).toTimeString().slice(0,5)+' '+r.title+' / '+r.body)));
 console.log('stored on phone:',await p.evaluate(()=>Object.keys(__db).map(k=>k.split('/').pop())));
 console.log('bridge msgs:',await p.evaluate(()=>[...new Set(__msgs)]));
 await p.screenshot({path:'/tmp/native.png'});
 console.log('ERRORS',errs);await b.close();
})();
