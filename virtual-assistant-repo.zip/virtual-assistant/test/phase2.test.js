const fs=require('fs'),vm=require('vm');
const ctx={console,setTimeout,clearTimeout,Math,Date,JSON,window:{},document:{querySelector(){},querySelectorAll(){return[]}},UI:{toast(){},celebrate(){},render(){}},toast(){}};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(__dirname+'/../web/src/01-core.js','utf8')+fs.readFileSync(__dirname+'/../web/src/02-engine.js','utf8')+';globalThis.X={S:()=>S,D,createTask,buildPlan,approvePlan,planWeek,applyWeek,deadlineRisks,reflowToday,applyReflow,completeTask,paceStats,paceFactor,logActivity,nextOccurrence,addEvent,learnedPeak};',ctx);
const X=ctx.X,S=X.S(),D=X.D,today=D.today();let fail=0;const ok=(c,m)=>{console.log(c?'ok ':'BAD',m);if(!c)fail++};
S.profile.freeHours={weekday:3,weekend:5};
// pace learning
for(let i=0;i<6;i++)X.logActivity('actual',{taskId:'x',est:30,min:45});
ok(Math.abs(X.paceFactor()-1.5)<0.01,'pace factor learned 1.5 = '+X.paceFactor());
const t=X.createTask({title:'Essay',estMin:60,planDate:today,priority:'high'});
const p=X.buildPlan(D.add(today,1),{fromNow:false});
const t2=X.createTask({title:'Report',estMin:40,planDate:D.add(today,1)});
const p2=X.buildPlan(D.add(today,1),{fromNow:false});
const blk=p2.blocks.find(b=>b.taskId===t2.id);ok(blk&&blk.end-blk.start===60,'plan uses pace: 40m→'+(blk&&blk.end-blk.start)+'m');
// starter session for chronic postponement
const t3=X.createTask({title:'Tax forms',estMin:90,planDate:D.add(today,1)});t3.postponed=3;
const b3=X.buildPlan(D.add(today,1),{fromNow:false}).blocks.find(b=>b.taskId===t3.id);ok(b3&&b3.starter&&b3.end-b3.start===25,'postponed 3x → 25m starter');
// recurrence
ok(X.nextOccurrence('weekdays','2026-09-25')==='2026-09-28','weekdays skips weekend');
const r=X.createTask({title:'Standup notes',estMin:10,planDate:today});r.recurrence='daily';X.completeTask(r.id);
ok(Object.values(S.tasks.items).some(x=>x.title==='Standup notes'&&x.status==='todo'&&x.planDate===D.add(today,1)),'daily recurrence spawns tomorrow');
// week plan & risks
['A','B','C','D','E'].forEach((n,i)=>X.createTask({title:'Due '+n,estMin:120,due:D.add(today,2),priority:'high'}));
const risks=X.deadlineRisks();ok(risks.length>0,'deadline risk detected: '+(risks[0]&&D.dur(risks[0].work)+' vs '+D.dur(risks[0].free)));
const w=X.planWeek();ok(w.assign.length>0&&w.assign.every(a=>!a.t.due||a.date<=a.t.due||D.diff(a.t.due,today)<0),'week plan respects deadlines ('+w.assign.length+' assigned)');
console.log('   ',w.assign.slice(0,6).map(a=>a.t.title+'→'+D.label(a.date)+(a.tight?'(tight)':'')).join(', '));
// reflow
X.approvePlan(X.buildPlan(today));const day=S.plan.days[today];const tb=day.blocks.filter(b=>b.type!=='event');
if(tb.length){const n=D.nowMin();tb[0].start=n-60;tb[0].end=n-20;const rf=X.reflowToday();ok(rf.moves.every(m=>m.to>=n),'reflow starts from now ('+rf.moves.length+' moved, '+rf.overflow.length+' overflow)');X.applyReflow(rf);}
else console.log('   (no time left today to test reflow)');
console.log('fails',fail);
