window.__calls=[];
(function(){
  const store=new Map();
  const db={doc(path){return{path,async get(){const v=store.get(path);return{exists:!!v,data:()=>v&&JSON.parse(JSON.stringify(v)),id:path.split('/').pop(),metadata:{}}},async set(d){if(JSON.stringify(d).length>256*1024)throw{code:'invalid_argument',message:'too big'};store.set(path,JSON.parse(JSON.stringify(d)))},async delete(){store.delete(path)}}},collection(){return{}}};
  window.__store=store;
  const pick=(ctx)=>{const m=ctx.match(/- (t_[a-z0-9]+) \| ([^|]+)/);return m?m[1]:null};
  async function json(input,opts={}){
    const text=typeof input==='string'?input:input.map(t=>t.content).join('\n\n');
    const last=typeof input==='string'?input:input[input.length-1].content;
    window.__calls.push(last.slice(0,80));
    await new Promise(r=>setTimeout(r,300));
    const stream=(o)=>{const s=JSON.stringify(o);opts.onText&&opts.onText({text:s,delta:s});return o};
    if(text.includes('Break this goal into the MINIMUM')) return stream({goal:{title:'Launch my business',why:'Build something of my own within six months'},
      milestones:[{key:'m1',title:'Learn the core technology & define the product',month:1,projects:[{key:'p1',title:'Learning'},{key:'p2',title:'Product definition'}]},
        {key:'m2',title:'Validate with 10 customer conversations',month:2,projects:[{key:'p3',title:'Customer discovery'}]},
        {key:'m3',title:'MVP built and website live',month:4,projects:[{key:'p4',title:'Product build'},{key:'p5',title:'Website'}]},
        {key:'m4',title:'Audience & investor pipeline',month:5,projects:[{key:'p6',title:'Social content'},{key:'p7',title:'Investor outreach'}]},
        {key:'m5',title:'Public launch',month:6,projects:[{key:'p8',title:'Launch'}]}],
      weekly_objectives:[{projectKey:'p2',title:'Write a one-page product brief'},{projectKey:'p1',title:'Finish first module of the tech course'},{projectKey:'p3',title:'List 20 potential customers'}],
      tasks:[{key:'t1',title:'Write the one-sentence problem statement',projectKey:'p2',estMin:25,priority:'high',energy:'medium',day:0,dependsOn:[]},
        {key:'t2',title:'Draft the one-page product brief',projectKey:'p2',estMin:90,priority:'high',energy:'high',day:1,dependsOn:['t1']},
        {key:'t3',title:'Tech course: module 1',projectKey:'p1',estMin:60,priority:'medium',energy:'high',day:0,dependsOn:[]},
        {key:'t4',title:'List 20 potential customers',projectKey:'p3',estMin:45,priority:'medium',energy:'low',day:2,dependsOn:[]},
        {key:'t5',title:'Pick a website builder and domain',projectKey:'p5',estMin:30,priority:'low',energy:'low',day:4,dependsOn:[]}],
      habits:[{title:'Exercise',perWeek:3,durMin:45,preferredTime:'evening'}],
      commitments:[{title:'School',days:['mon','tue','wed','thu','fri'],start:null,end:null}],
      note:'About 4 hours of work this week on top of school — deliberately light for week one.'});
    if(text.includes('just brain-dumped')) return stream({items:[
      {kind:'followup',title:'Call David',when:null,estMin:15,priority:'medium',people:['David']},
      {kind:'task',title:'Finish the proposal',when:'before Friday',estMin:120,priority:'high',energy:'high'},
      {kind:'task',title:'Read that book',when:null,estMin:60,priority:'low'},
      {kind:'habit',title:'Exercise',perWeek:3,durMin:45},
      {kind:'project',title:'Research the new business idea',when:null},
      {kind:'task',title:'Buy groceries',when:'tomorrow',estMin:40,priority:'medium',energy:'low'},
      {kind:'task',title:"Prepare for Friday's meeting",when:'before Friday',estMin:45,priority:'high'}],focus:'Finish the proposal',summary:'Mostly this week.'});
    if(text.includes('The user is stuck')) return stream({reply:"You've moved this twice. The blocker is size, not ability.",firstStep:{title:'Open the doc and write the first paragraph',estMin:15},steps:[{title:'Outline 3 sections',estMin:15},{title:'Draft pricing section',estMin:30}]});
    if(text.includes("weekly review")) return stream({completed:'You completed 3 tasks.',movedForward:'Launch my business moved forward.',missed:'Tech course slipped.',postponing:'Product brief (twice).',attention:'Customer list is overdue.',priorities:[{title:'Draft the one-page product brief',taskId:null}],adjustment:'Move study to mornings.'});
    if(text.includes('HOW YOU WORK')){
      if(/launch my business/i.test(last)) return stream({reply:"That's a six-month goal with several workstreams. I'll break it down around school and exercise.",actions:[{type:'add_goal',title:'Launch my business',why:'',when:'in six months',decompose:true},{type:'add_habit',title:'Exercise',perWeek:3,durMin:45,preferredTime:'evening'}]});
      if(/couldn.t finish/i.test(last)) return stream({reply:"No problem.",actions:[{type:'offer_reschedule',taskId:pick(text)}]});
      if(/remind me to call john/i.test(last)) return stream({reply:"Noted.",actions:[{type:'add_task',title:'Call John',when:'tomorrow',estMin:15,priority:'medium',kind:'followup',people:['John']}]});
      if(/launch plan|what did i say/i.test(last)) return stream({reply:"Your document 'launch-plan.txt' says the target launch period is November and the current milestone is completing the MVP.",actions:[]});
      return stream({reply:'Okay.',actions:[{type:'what_now'}]});
    }
    return stream({summary:'x',goals:[],commitments:[],habits:[],tasks:[],memory:[]});
  }
  const sample=async()=>({text:'ok',truncated:false});sample.json=json;sample.limits=async()=>({maxPromptBytes:65536});
  window.claude={use:async(n)=>n==='db'?db:n==='user'?{id:async()=>'u1',isOwner:()=>true}:n==='sample'?sample:null};
})();
