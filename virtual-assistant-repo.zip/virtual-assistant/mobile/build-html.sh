#!/bin/sh
# Regenerates mobile/della-html.js from the web build. Run web/build.sh first.
cd "$(dirname "$0")/.."
node -e '
const fs=require("fs");
const head=fs.readFileSync("web/src/head.html","utf8"), app=fs.readFileSync("web/della.html","utf8").split("<script>")[1].split("</script>")[0];
const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0}img{max-width:100%}[hidden]{display:none!important}</style>${head}<script>${fs.readFileSync("web/src/native-shim.js","utf8")}</script></head><body><div id="app"></div><script>${app}</script></body></html>`;
fs.writeFileSync("mobile/della-html.js","// Generated from the Della web app. Rebuild instead of editing by hand.\nexport default "+JSON.stringify(html)+";\n");
console.log("built mobile/della-html.js");'
