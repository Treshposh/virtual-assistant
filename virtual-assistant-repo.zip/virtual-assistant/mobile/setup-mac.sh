#!/bin/sh
# Creates the Della Expo app next to this folder (../della-app) and copies Della's files in.
set -e
cd "$(dirname "$0")"
npx create-expo-app@latest ../della-app --template blank --yes
cp App.js app.json eas.json della-html.js ../della-app/
cp -R assets/. ../della-app/assets/
cd ../della-app
npx expo install react-native-webview expo-notifications expo-secure-store @react-native-async-storage/async-storage react-native-safe-area-context
echo ""
echo "Done. Next: cd ../della-app && npx expo start"
