// Della — Expo wrapper around the Della web app.
// Adds: on-phone storage, real notifications for planned sessions, and AI through the
// user's own Anthropic API key (stored in SecureStore, sent only to api.anthropic.com).
import { useCallback, useEffect, useRef } from "react";
import { BackHandler, Platform, StatusBar, useColorScheme } from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { WebView } from "react-native-webview";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import * as Notifications from "expo-notifications";
import html from "./della-html";

const KEY_NAME = "anthropic_api_key";
const MODELS = { quick: "claude-haiku-4-5-20251001", default: "claude-sonnet-5", complex: "claude-opus-5-5" };

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
});

/* ---------- Claude (Anthropic Messages API) ---------- */
function toMessages(input) {
  const turns = typeof input === "string" ? [{ role: "user", content: input }] : input;
  const out = [];
  for (const t of turns) {
    const last = out[out.length - 1];
    if (last && last.role === t.role) last.content += "\n\n" + t.content; // API wants alternating roles
    else out.push({ role: t.role, content: String(t.content) });
  }
  return out;
}
async function askClaude({ input, tier, json }) {
  const key = await SecureStore.getItemAsync(KEY_NAME);
  if (!key) throw { code: "no_key", message: "No API key" };
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: MODELS[tier] || MODELS.default,
      max_tokens: 4096,
      system: json ? "Your reply is machine-parsed. Reply with exactly one JSON value and nothing else." : undefined,
      messages: toMessages(input),
    }),
  }).catch(() => { throw { code: "upstream_error", message: "Network error" }; });
  if (res.status === 401 || res.status === 403) throw { code: "bad_key", message: "Key rejected" };
  if (res.status === 429 || res.status === 529) throw { code: "rate_limited", message: "Busy" };
  if (!res.ok) throw { code: "upstream_error", message: "HTTP " + res.status };
  const body = await res.json();
  const text = (body.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  if (!text.trim()) throw { code: "empty_completion", message: "Empty reply" };
  return text;
}

/* ---------- Notifications ---------- */
async function ensureNotificationPermission() {
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("reminders", { name: "Session reminders", importance: Notifications.AndroidImportance.HIGH });
  }
  const current = await Notifications.getPermissionsAsync();
  if (current.granted) return true;
  const asked = await Notifications.requestPermissionsAsync();
  return asked.granted;
}
async function scheduleReminders(items) {
  if (!(await ensureNotificationPermission())) return { scheduled: 0 };
  await Notifications.cancelAllScheduledNotificationsAsync();
  const now = Date.now(); let n = 0;
  for (const it of items) {
    if (it.at <= now + 5000) continue;
    await Notifications.scheduleNotificationAsync({
      content: { title: it.title, body: it.body, data: { id: it.id } },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(it.at), channelId: "reminders" },
    });
    n++;
  }
  return { scheduled: n };
}

/* ---------- App ---------- */
export default function App() {
  const web = useRef(null);
  const dark = useColorScheme() === "dark";

  const reply = useCallback((id, ok, data) => {
    web.current?.injectJavaScript(`window.__nativeReply(${JSON.stringify(id)}, ${ok}, ${JSON.stringify(data ?? null)}); true;`);
  }, []);

  const onMessage = useCallback(async (e) => {
    let m; try { m = JSON.parse(e.nativeEvent.data); } catch { return; }
    if (m.type === "exit") { BackHandler.exitApp(); return; }
    try {
      let data = null;
      switch (m.type) {
        case "db.get": { const v = await AsyncStorage.getItem("della:" + m.path); data = v ? JSON.parse(v) : null; break; }
        case "db.set": await AsyncStorage.setItem("della:" + m.path, JSON.stringify(m.data)); break;
        case "db.delete": await AsyncStorage.removeItem("della:" + m.path); break;
        case "key.set": await SecureStore.setItemAsync(KEY_NAME, String(m.key).trim()); break;
        case "key.status": data = !!(await SecureStore.getItemAsync(KEY_NAME)); break;
        case "ai": data = await askClaude(m); break;
        case "reminders": data = await scheduleReminders(m.items || []); break;
        default: throw { code: "unknown", message: "Unknown message " + m.type };
      }
      reply(m.id, true, data);
    } catch (err) {
      reply(m.id, false, { code: err?.code || "upstream_error", message: String(err?.message || err) });
    }
  }, [reply]);

  // Android back button closes open panels first, then leaves the app.
  useEffect(() => {
    const sub = BackHandler.addEventListener("hardwareBackPress", () => {
      web.current?.injectJavaScript(`(function(){ if (typeof UI !== "undefined" && UI.sheetOpen) { closeSheet(); } else if (typeof UI !== "undefined" && UI.tab !== "home") { UI.go("home"); } else { window.ReactNativeWebView.postMessage(JSON.stringify({type:"exit"})); } })(); true;`);
      return true;
    });
    return () => sub.remove();
  }, []);

  // Tapping a notification brings the app forward; the page shows the matching check-in.
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener(() => {
      web.current?.injectJavaScript(`if (typeof checkinTick === "function") { UI.checkin = null; checkinTick(); } true;`);
    });
    return () => sub.remove();
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle={dark ? "light-content" : "dark-content"} backgroundColor={dark ? "#0E1311" : "#F2F3EF"} />
      <SafeAreaView style={{ flex: 1, backgroundColor: dark ? "#0E1311" : "#F2F3EF" }} edges={["top", "bottom"]}>
        <WebView
          ref={web}
          source={{ html, baseUrl: "https://della.local/" }}
          originWhitelist={["*"]}
          onMessage={onMessage}
          javaScriptEnabled
          domStorageEnabled
          allowFileAccess
          setSupportMultipleWindows={false}
          keyboardDisplayRequiresUserAction={false}
          style={{ flex: 1, backgroundColor: "transparent" }}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
