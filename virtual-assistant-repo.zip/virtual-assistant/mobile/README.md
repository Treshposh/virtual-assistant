# Della for Android (Expo)

This turns the Della assistant into a real Android app you can install and share as an APK.
It adds phone notifications for your planned sessions, keeps your data on the phone,
and uses your own Anthropic API key for the AI features.

## 1. Set up (once, about 5 minutes)

You need Node.js 20+ (nodejs.org, LTS version).

- **Windows:** double-click `setup-windows.bat`
- **Mac:** open Terminal in this folder and run `sh setup-mac.sh`

This creates a `della-app` folder next to this one with everything installed.

## 2. Try it on your phone (optional)

```
cd della-app
npx expo start
```
Scan the QR code with the Expo Go app (same Wi-Fi). If it won't connect: `npx expo start --tunnel`.

## 3. Build the shareable APK

```
npm install -g eas-cli
eas login            (create a free account at expo.dev if you don't have one)
eas build -p android --profile preview
```
- Say **yes** when it asks to create a project and to generate a keystore.
- The build runs on Expo's servers (about 10–20 minutes on the free tier).
- You get a link to the `.apk` file. Send that link to anyone with an Android phone.
  They open it, tap Install, and allow installs from this source if asked.

## 4. First launch

1. Answer the setup questions (or skip to a brain dump).
2. Open **Settings (your initial, top right) → Assistant** and paste an Anthropic API key
   from console.anthropic.com. API usage is billed by Anthropic to the key's owner.
   Each person who installs the app uses their own key.
3. Allow notifications when asked — reminders arrive when sessions start and end.

## Notes

- Notifications are scheduled for today's and tomorrow's approved plans and refresh whenever the plan changes.
- Android may deliver a notification a few minutes late when the phone is in battery-saver mode.
- Data lives on the phone only. Uninstalling the app deletes it.
- iPhone: Apple doesn't allow installing app files directly. Use `eas build -p ios` with a paid Apple Developer account and share through TestFlight.
- Updating: when Della changes, replace `della-html.js` in `della-app` and rebuild.
