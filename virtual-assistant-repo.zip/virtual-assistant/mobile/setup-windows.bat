@echo off
REM Creates the Della Expo app next to this folder (..\della-app) and copies Della's files in.
cd /d "%~dp0"
call npx create-expo-app@latest ..\della-app --template blank --yes || goto :fail
copy /Y App.js ..\della-app\ >nul
copy /Y app.json ..\della-app\ >nul
copy /Y eas.json ..\della-app\ >nul
copy /Y della-html.js ..\della-app\ >nul
xcopy /Y /E /I assets ..\della-app\assets >nul
cd ..\della-app
call npx expo install react-native-webview expo-notifications expo-secure-store @react-native-async-storage/async-storage react-native-safe-area-context || goto :fail
echo.
echo Done. Next: cd ..\della-app  then  npx expo start
goto :eof
:fail
echo Setup stopped with an error. Scroll up to see what went wrong.
