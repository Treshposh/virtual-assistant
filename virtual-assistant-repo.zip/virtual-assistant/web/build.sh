#!/bin/sh
# Builds web/della.html (single file) from web/src.
cd "$(dirname "$0")"
{ cat src/head.html; echo '<div id="app"></div>'; echo '<script>'; cat src/01-core.js src/02-engine.js src/03-ai.js src/04-ui.js src/05-flows.js src/06-boot.js; echo '</script>'; } > della.html
node -e "const s=require('fs').readFileSync('della.html','utf8');new Function(s.split('<script>')[1].split('</script>')[0]);console.log('built della.html', (s.length/1024|0)+'KB')"
