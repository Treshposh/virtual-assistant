/* ============================================================
   02 ENGINE — deterministic application logic:
   tasks, goal hierarchy, planner, rescheduling, rewards, streaks,
   analytics, document retrieval. No LLM calls in this file.
   ============================================================ */

/* ---------------- Tasks ---------------- */
const PRI_W = { high: 30, medium: 18, low: 8 };
function createTask(o = {}) {
  const t = {
    id: uid("t"), title: String(o.title || "Untitled").slice(0, 200), notes: o.notes || "",
    priority: ["high", "medium", "low"].includes(o.priority) ? o.priority : "medium",
    importance: o.importance || (o.goalId ? 3 : 2),
    estMin: clamp(Math.round(Number(o.estMin) || 30), 5, 480),
    due: o.due || null, dueTime: o.dueTime || null, planDate: o.planDate || null,
    projectId: o.projectId || null, goalId: o.goalId || null, milestoneId: o.milestoneId || null,
    parentId: o.parentId || null, deps: o.deps || [], status: "todo",
    recurrence: o.recurrence || null, energy: ["high", "medium", "low"].includes(o.energy) ? o.energy : "medium",
    kind: o.kind || "task", people: o.people || [], postponed: 0, isNextAction: !!o.isNextAction,
    createdAt: Date.now(), doneAt: null, source: o.source || "manual",
  };
  if (t.projectId && !t.goalId) { const p = S.goals.projects[t.projectId]; if (p) { t.goalId = p.goalId; t.milestoneId = t.milestoneId || p.milestoneId; } }
  S.tasks.items[t.id] = t;
  Store.save("tasks");
  logActivity("create", { taskId: t.id });
  return t;
}
const allTasks = () => Object.values(S.tasks.items);
const openTasks = () => allTasks().filter((t) => t.status === "todo" || t.status === "doing");
const childrenOf = (id) => allTasks().filter((t) => t.parentId === id);
function isBlocked(t) { return (t.deps || []).some((d) => S.tasks.items[d] && S.tasks.items[d].status !== "done" && S.tasks.items[d].status !== "dropped"); }
function taskGoal(t) { return t.goalId ? S.goals.goals[t.goalId] : null; }
function taskProject(t) { return t.projectId ? S.goals.projects[t.projectId] : null; }
function deadlineOf(t) { return t.due || null; }

function scoreTask(t, date) {
  let s = PRI_W[t.priority] || 18;
  const due = deadlineOf(t);
  if (due) { const dd = D.diff(due, date); s += dd < 0 ? 40 : dd === 0 ? 35 : dd === 1 ? 25 : dd <= 3 ? 15 : dd <= 7 ? 8 : 2; }
  if (t.planDate === date) s += 50;
  if (t.planDate && D.diff(t.planDate, date) < 0) s += 30; // carried over
  if (t.goalId) s += 10;
  if (t.isNextAction) s += 8;
  s += Math.min(12, (t.postponed || 0) * 4);
  if (t.importance === 3) s += 5;
  return s;
}
function isMustDo(t, date) { const due = deadlineOf(t); return t.planDate === date || (t.planDate && D.diff(t.planDate, date) < 0) || (due && D.diff(due, date) <= 0); }

function candidateTasks(date) {
  return openTasks().filter((t) => {
    if (isBlocked(t)) return false;
    if (childrenOf(t.id).some((c) => c.status === "todo")) return false; // schedule its sub-steps instead
    if (t.planDate && D.diff(t.planDate, date) > 0) return false; // pinned to a later day
    if (t.kind === "idea") return false;
    return true;
  }).sort((a, b) => scoreTask(b, date) - scoreTask(a, date));
}

/* ---------------- Goal hierarchy ---------------- */
function goalTasks(gid) { return allTasks().filter((t) => t.goalId === gid && t.status !== "dropped"); }
function goalMilestones(gid) { return Object.values(S.goals.milestones).filter((m) => m.goalId === gid).sort((a, b) => a.order - b.order); }
function milestoneProjects(mid) { return Object.values(S.goals.projects).filter((p) => p.milestoneId === mid); }
function goalProjects(gid) { return Object.values(S.goals.projects).filter((p) => p.goalId === gid); }
function projectTasks(pid) { return allTasks().filter((t) => t.projectId === pid && t.status !== "dropped" && !t.parentId); }
function goalProgress(gid) {
  const ms = goalMilestones(gid);
  const ts = goalTasks(gid);
  if (!ms.length) return ts.length ? ts.filter((t) => t.status === "done").length / ts.length : 0;
  const done = ms.filter((m) => m.status === "done").length;
  const cur = ms.find((m) => m.status !== "done");
  let frac = 0;
  if (cur) { const mt = ts.filter((t) => t.milestoneId === cur.id); if (mt.length) frac = mt.filter((t) => t.status === "done").length / mt.length; }
  return clamp((done + frac * 0.9) / ms.length, 0, 1);
}
function currentMilestone(gid) { return goalMilestones(gid).find((m) => m.status !== "done") || null; }
function nextActionFor(gid) {
  const today = D.today();
  const c = candidateTasks(today).filter((t) => t.goalId === gid);
  return c.find((t) => t.isNextAction) || c[0] || null;
}
function thisWeekObjectives(gid) { const wk = D.weekStart(D.today()); return Object.values(S.goals.objectives).filter((o) => o.week === wk && (!gid || o.goalId === gid)); }

/* ---------------- Calendar (provider-agnostic) ----------------
   Every event carries `source`. Only the internal provider exists today; Google, Apple and
   Outlook adapters implement the same shape: list(date) → [{id,title,start,end,source}]. */
const CalendarProviders = {
  internal: {
    label: "Della calendar",
    list(date) {
      const w = D.dow(date);
      return Object.values(S.cal.events).filter((e) => (e.date === date) || (Array.isArray(e.days) && e.days.includes(w) && (!e.from || D.diff(date, e.from) >= 0) && (!e.until || D.diff(e.until, date) >= 0)))
        .map((e) => ({ id: e.id, title: e.title, start: D.toMin(e.start), end: D.toMin(e.end), source: "internal", kind: e.kind || "event" }));
    },
  },
  // google: { label: "Google Calendar", list: async (date) => … } — Phase 3
};
function eventsOn(date) {
  return Object.values(CalendarProviders).flatMap((p) => p.list(date)).filter((e) => e.start != null && e.end != null && e.end > e.start).sort((a, b) => a.start - b.start);
}
function addEvent(o) {
  const e = { id: uid("e"), title: o.title, date: o.date || null, days: o.days || null, start: o.start, end: o.end || D.toHHMM(D.toMin(o.start) + (o.durMin || 60)), kind: o.kind || "event", source: "internal", from: o.from || null, until: o.until || null, createdAt: Date.now() };
  S.cal.events[e.id] = e; Store.save("cal"); return e;
}

/* ---------------- Habits (flexible weekly targets, never stacked) ---------------- */
function habitWeekCount(h, date = D.today()) { const ws = D.weekStart(date); let n = 0; for (let i = 0; i < 7; i++) if (h.log?.[D.add(ws, i)]) n++; return n; }
function habitDueOn(h, date) {
  if (h.log?.[date]) return false;
  const ws = D.weekStart(date), remaining = (h.perWeek || 3) - habitWeekCount(h, date);
  if (remaining <= 0) return false;
  const daysLeft = 7 - D.diff(date, ws);
  if (h.perWeek >= 7) return true;
  if (remaining >= daysLeft) return true; // behind — but still only one session a day
  const yesterday = D.add(date, -1);
  return !h.log?.[yesterday]; // spread sessions out
}
function toggleHabit(id, date = D.today()) {
  const h = S.habits.items[id]; if (!h) return;
  h.log = h.log || {};
  if (h.log[date]) { delete h.log[date]; award(-(S.profile.pointsRules.habit || 5), "Undo: " + h.title); }
  else { h.log[date] = true; award(S.profile.pointsRules.habit || 5, h.title); logActivity("habit", { habitId: id }); }
  const day = S.plan.days[date]; if (day) day.blocks.forEach((b) => { if (b.habitId === id) b.status = h.log[date] ? "done" : "planned"; });
  Store.save("habits", "plan");
}
function addHabit(o) {
  const same = Object.values(S.habits.items).find((x) => x.title.trim().toLowerCase() === String(o.title || "").trim().toLowerCase());
  if (same) return same;
  const h = { id: uid("h"), title: o.title, perWeek: clamp(Number(o.perWeek) || 3, 1, 7), durMin: clamp(Number(o.durMin) || 30, 5, 240), preferredTime: o.preferredTime || "any", log: {}, createdAt: Date.now() };
  S.habits.items[h.id] = h; Store.save("habits"); return h;
}

/* ---------------- Planner ---------------- */
const PEAK = { morning: [480, 720], afternoon: [780, 1020], evening: [1080, 1320], night: [1260, 1440], any: [0, 1440] };
function dayBounds() {
  const wake = D.toMin(S.profile.wake) ?? 420;
  let sleep = D.toMin(S.profile.sleep) ?? 1380;
  if (sleep <= wake) sleep = 1425;
  return [wake + 30, sleep - 45];
}
function subtract(segs, s, e) {
  const out = [];
  for (const [a, b] of segs) { if (e <= a || s >= b) { out.push([a, b]); continue; } if (s > a) out.push([a, s]); if (e < b) out.push([e, b]); }
  return out.filter(([a, b]) => b - a >= 10);
}
function freeSegments(date, { fromMin = null, excludeBlocks = true } = {}) {
  let [a, b] = dayBounds();
  if (fromMin != null) a = Math.max(a, Math.ceil(fromMin / 5) * 5);
  let segs = a < b ? [[a, b]] : [];
  for (const e of eventsOn(date)) segs = subtract(segs, e.start - 10, e.end + 10);
  const day = S.plan.days[date];
  if (excludeBlocks && day) for (const bl of day.blocks) if (bl.type !== "event" && bl.status !== "skipped" && bl.status !== "moved") segs = subtract(segs, bl.start, bl.end + 10);
  return segs;
}
function capacityFor(date) { return Math.round((D.isWeekend(date) ? S.profile.freeHours.weekend : S.profile.freeHours.weekday) * 60); }
function doneMinutesOn(date) { return sum(allTasks().filter((t) => t.status === "done" && t.doneAt && D.ymd(t.doneAt) === date), (t) => t.estMin); }

function place(segs, est, pref) {
  const fits = [];
  for (const [a, b] of segs) if (b - a >= est) fits.push([a, b]);
  if (!fits.length) return null;
  if (pref) {
    const [ps, pe] = pref.range;
    if (pref.inside) { for (const [a, b] of fits) { const s = Math.max(a, ps); if (s + est <= Math.min(b, pe + 30)) return s; } }
    else { for (const [a, b] of fits) { if (a + est <= ps || a >= pe) return a; const s = Math.max(a, pe); if (s + est <= b) return s; } }
  }
  return fits[0][0];
}

/* Build a proposal for `date`. Nothing is saved until the user approves it. */
function buildPlan(date, { fromNow = date === D.today() } = {}) {
  const fromMin = fromNow ? D.nowMin() + 5 : null;
  let segs = freeSegments(date, { fromMin, excludeBlocks: false });
  const windowMin = sum(segs, ([a, b]) => b - a);
  let budget = capacityFor(date);
  if (fromNow) budget = Math.max(0, Math.min(budget - doneMinutesOn(date), Math.round(windowMin * 0.75)));
  const peak = PEAK[learnedPeak()] || PEAK.morning;
  const pace = paceFactor();

  const habitItems = Object.values(S.habits.items).filter((h) => habitDueOn(h, date)).map((h) => ({ type: "habit", habitId: h.id, title: h.title, est: h.durMin || 30, energy: "medium", score: 62, must: true, pref: h.preferredTime && PEAK[h.preferredTime] ? { range: PEAK[h.preferredTime], inside: true } : null }));
  const cands = candidateTasks(date);
  const taskItems = cands.map((t) => { const real = round5((t.estMin || 30) * pace); const starter = (t.postponed || 0) >= 3 && real > 25; const est = starter ? 25 : Math.min(real, 120); return { type: "task", taskId: t.id, title: t.title, est, full: real, session: starter || real > 120, starter, energy: t.energy, score: scoreTask(t, date), must: isMustDo(t, date), pref: t.energy === "high" ? { range: peak, inside: true } : t.energy === "low" ? { range: peak, inside: false } : null, dueTime: t.dueTime }; });
  const items = [...taskItems, ...habitItems];
  items.sort((x, y) => (y.must ? 1000 : 0) + y.score - ((x.must ? 1000 : 0) + x.score));

  const blocks = [], overflow = [];
  let used = 0;
  const requested = sum(items.filter((i) => i.must), (i) => i.full || i.est);
  const maxOptional = 6; let optional = 0;
  for (const it of items) {
    const optionalItem = !it.must && it.type === "task";
    if (optionalItem && optional >= maxOptional) continue;
    if (used + it.est > budget) { if (it.must || it.type === "habit") overflow.push({ ...it, reason: "capacity" }); continue; }
    let start = null;
    if (it.dueTime) { const want = D.toMin(it.dueTime); const seg = segs.find(([a, b]) => want >= a && want + it.est <= b); if (seg) start = want; }
    if (start == null) start = place(segs, it.est, it.pref);
    if (start == null) { if (it.must || it.type === "habit") overflow.push({ ...it, reason: "slot" }); continue; }
    blocks.push({ id: uid("b"), type: it.type, taskId: it.taskId || null, habitId: it.habitId || null, title: it.title, start, end: start + it.est, status: "planned", session: it.session ? it.est : 0, starter: !!it.starter });
    segs = subtract(segs, start, start + it.est + 10);
    used += it.est;
    if (optionalItem) optional++;
  }
  for (const e of eventsOn(date)) blocks.push({ id: uid("b"), type: "event", eventId: e.id, title: e.title, start: e.start, end: e.end, status: "fixed" });
  blocks.sort((a, b) => a.start - b.start);
  const focusTask = cands.find((t) => t.goalId && blocks.some((b) => b.taskId === t.id)) || cands.find((t) => blocks.some((b) => b.taskId === t.id));
  return { date, blocks, overflow, budget, used, requested, windowMin, focus: focusTask ? focusTask.title : "", focusTaskId: focusTask?.id || null, overloaded: requested > budget, pace, peakUsed: learnedPeak() };
}

function approvePlan(p) {
  const prev = S.plan.days[p.date];
  const kept = prev ? prev.blocks.filter((b) => b.status === "done" || b.status === "partial") : [];
  S.plan.days[p.date] = { approved: true, focus: p.focus, focusTaskId: p.focusTaskId, blocks: [...kept, ...p.blocks.filter((b) => !kept.some((k) => k.taskId && k.taskId === b.taskId))].sort((a, b) => a.start - b.start), createdAt: Date.now() };
  for (const b of p.blocks) if (b.taskId && S.tasks.items[b.taskId]) S.tasks.items[b.taskId].planDate = p.date;
  for (const o of p.overflow) if (o.taskId && S.tasks.items[o.taskId]?.planDate === p.date) S.tasks.items[o.taskId].planDate = null;
  prunePlans();
  Store.save("plan", "tasks");
  logActivity("plan", { date: p.date, blocks: p.blocks.length });
}
function prunePlans() { const cut = D.add(D.today(), -35); for (const k of Object.keys(S.plan.days)) if (k < cut) delete S.plan.days[k]; }

function dayPlan(date = D.today()) { return S.plan.days[date] || null; }
function plannedLoad(date) {
  const day = S.plan.days[date];
  if (day) return sum(day.blocks.filter((b) => b.type !== "event" && b.status !== "skipped" && b.status !== "moved"), (b) => b.end - b.start);
  return sum(openTasks().filter((t) => t.planDate === date || (!t.planDate && t.due === date)), (t) => t.estMin);
}

/* Insert one task into an already-approved day without disturbing other blocks. */
function insertIntoDay(t, date, atMin = null) {
  const day = S.plan.days[date];
  t.planDate = date; Store.save("tasks");
  if (!day) return null;
  const segs = freeSegments(date, { fromMin: date === D.today() ? D.nowMin() + 5 : null });
  let start = atMin;
  if (start == null || !segs.some(([a, b]) => start >= a && start + t.estMin <= b)) start = place(segs, t.estMin, null);
  if (start == null) return null;
  day.blocks = day.blocks.filter((b) => !(b.taskId === t.id && b.status === "planned"));
  day.blocks.push({ id: uid("b"), type: "task", taskId: t.id, title: t.title, start, end: start + t.estMin, status: "planned" });
  day.blocks.sort((a, b) => a.start - b.start);
  Store.save("plan");
  return start;
}

/* ---------------- Now / next ---------------- */
function nowNext(date = D.today()) {
  const day = S.plan.days[date]; const n = D.nowMin();
  if (!day) return { now: null, next: null, later: [] };
  const live = day.blocks.filter((b) => b.status === "planned" || b.status === "fixed" || b.status === "active");
  const now = live.find((b) => b.start <= n && n < b.end) || null;
  const upcoming = live.filter((b) => b.start > n || (b === now ? false : b.start >= n));
  const next = upcoming.find((b) => b !== now) || null;
  const later = upcoming.filter((b) => b !== next && b !== now);
  return { now, next, later };
}
function minutesUntilNextFixed(date = D.today()) {
  const n = D.nowMin(); const e = eventsOn(date).find((x) => x.start > n);
  const [, end] = dayBounds();
  return e ? { min: e.start - n, event: e } : { min: Math.max(0, end - n), event: null };
}

/* "What should I do now?" — deterministic recommendation, one primary action. */
function recommendNow() {
  const date = D.today(), n = D.nowMin();
  const { min: window, event } = minutesUntilNextFixed(date);
  const { now } = nowNext(date);
  const peak = PEAK[S.profile.peak] || PEAK.morning, inPeak = n >= peak[0] && n < peak[1];
  const reasons = [];
  if (now && now.type !== "event") {
    const t = now.taskId && S.tasks.items[now.taskId];
    return { kind: now.type, block: now, task: t || null, habitId: now.habitId, window, event, minutes: Math.min(now.end - n, window), reason: "It's on your plan for right now." };
  }
  if (now && now.type === "event") return { kind: "event", block: now, window: now.end - n, event, reason: "You're in " + now.title + " until " + D.fmtTime(now.end) + "." };
  if (window < 15) return { kind: "break", window, event, reason: event ? "Only " + window + " minutes before " + event.title + ". Get ready for it." : "The day is almost over." };
  const day = S.plan.days[date];
  const plannedIds = new Set((day?.blocks || []).filter((b) => b.status === "planned" && b.taskId).map((b) => b.taskId));
  const cands = candidateTasks(date).map((t) => {
    let s = scoreTask(t, date) + (plannedIds.has(t.id) ? 15 : 0);
    if (t.estMin > window) s -= 25; // won't finish — still possible to start
    if (t.energy === "high" && !inPeak) s -= 6; if (t.energy === "high" && inPeak) s += 6;
    return { t, s };
  }).sort((a, b) => b.s - a.s);
  if (!cands.length) {
    const h = Object.values(S.habits.items).find((h) => habitDueOn(h, date));
    if (h) return { kind: "habit", habitId: h.id, title: h.title, window, event, minutes: h.durMin, reason: "Nothing urgent is open, so this is a good moment for " + h.title.toLowerCase() + "." };
    return { kind: "empty", window, event, reason: "Nothing is open. Tell me what's on your mind or add a goal." };
  }
  const best = cands[0].t;
  const due = deadlineOf(best);
  if (due) { const dd = D.diff(due, date); reasons.push(dd < 0 ? "overdue" : dd === 0 ? "due today" : dd === 1 ? "due tomorrow" : "due " + D.label(due)); }
  if (best.goalId && taskGoal(best)) reasons.push("moves “" + taskGoal(best).title + "” forward");
  if (best.postponed >= 2) reasons.push("postponed " + best.postponed + " times");
  if (plannedIds.has(best.id)) reasons.push("on today's plan");
  return { kind: "task", task: best, window, event, minutes: Math.min(best.estMin, window), alternatives: cands.slice(1, 4).map((c) => c.t), reason: reasons.length ? cap1(reasons.join(", ")) + "." : "Highest-impact open item that fits your time." };
}
const cap1 = (s) => s.charAt(0).toUpperCase() + s.slice(1);

/* Fit a free window: "I have two hours free" */
function fitTime(minutes) {
  const date = D.today(); let left = minutes; const picks = [];
  for (const t of candidateTasks(date)) { if (t.estMin <= left) { picks.push(t); left -= t.estMin + 5; } if (left < 15 || picks.length >= 4) break; }
  return { picks, used: minutes - Math.max(0, left) };
}

/* ---------------- Rescheduling ---------------- */
function rescheduleOptions(t) {
  const today = D.today(), est = t.estMin || 30, opts = [];
  const laterSegs = freeSegments(today, { fromMin: D.nowMin() + 10 });
  const ls = place(laterSegs, est, null);
  if (ls != null) opts.push({ id: "later", date: today, start: ls, label: D.fmtTime(ls) + " today", load: plannedLoad(today), cap: capacityFor(today) });
  for (let i = 1; i <= 7; i++) {
    const d = D.add(today, i);
    const segs = freeSegments(d, {});
    const pref = { range: PEAK[S.profile.peak] || PEAK.morning, inside: true };
    const st = place(segs, est, t.energy === "high" ? pref : null);
    const load = plannedLoad(d), cap = capacityFor(d);
    if (st != null) opts.push({ id: i === 1 ? "tomorrow" : "d" + i, date: d, start: S.plan.days[d] ? st : null, hint: st, label: (i === 1 ? "Tomorrow" : D.label(d)) + (S.plan.days[d] ? " " + D.fmtTime(st) : st < 720 ? " morning" : st < 1020 ? " afternoon" : " evening"), load, cap });
  }
  // recommend: the earliest option whose day is under 80% of capacity
  const light = opts.find((o) => (o.load + est) / Math.max(1, o.cap) <= 0.8) || opts[0];
  const shown = [opts.find((o) => o.id === "later"), opts.find((o) => o.id === "tomorrow"), light].filter(Boolean);
  const uniq = [...new Map(shown.map((o) => [o.id, o])).values()];
  uniq.forEach((o) => (o.recommended = o === light));
  return { options: uniq, all: opts };
}
function loadWord(o) { const r = o.load / Math.max(1, o.cap); return r >= 0.9 ? "already full" : r >= 0.6 ? "fairly full" : r > 0.2 ? "moderate" : "light"; }
function rescheduleText(t, ro) {
  const [a, b] = ro.options; if (!a) return "There's no free slot in the next week. Consider dropping or shrinking it.";
  const L = (o) => o.id === "later" ? "You have time at " + o.label : "Tomorrow is " + loadWord(o);
  let s = a.id === "later" ? "You have " + D.dur(t.estMin) + " free at " + D.fmtTime(a.start) + " today." : "Today is full.";
  if (b && b.id === "tomorrow") s += " Tomorrow is " + loadWord(b) + " (" + D.dur(b.load) + " of " + D.dur(b.cap) + " planned).";
  const rec = ro.options.find((o) => o.recommended);
  if (rec) s += " " + (rec.id === "later" ? "Later today is the lighter option." : rec.label + " is the lighter option.");
  return s;
}
function moveTask(t, date, startMin = null, { reason = "moved" } = {}) {
  const from = t.planDate;
  const today = D.today();
  // release old blocks
  for (const [d, day] of Object.entries(S.plan.days)) day.blocks.forEach((b) => { if (b.taskId === t.id && b.status === "planned" && (d !== date || startMin != null)) b.status = "moved"; });
  if (from && D.diff(date, from) > 0 || (!from && date !== today)) { t.postponed = (t.postponed || 0) + 1; logActivity("postpone", { taskId: t.id, from, to: date, reason }); }
  let start = null;
  if (S.plan.days[date]) start = insertIntoDay(t, date, startMin);
  else { t.planDate = date; }
  Store.save("tasks", "plan");
  return start;
}

/* ---------------- Completion, rewards, streaks ---------------- */
function award(pts, reason, key = null) {
  const R = S.rewards;
  if (key) { if (R.awarded[key]) return false; R.awarded[key] = Date.now(); }
  R.balance = Math.max(0, (R.balance || 0) + pts); if (pts > 0) R.lifetime = (R.lifetime || 0) + pts;
  R.ledger.push({ at: Date.now(), pts, reason });
  if (R.ledger.length > 400) R.ledger = R.ledger.slice(-300);
  Store.save("rewards");
  if (pts > 0) checkRewardUnlocks();
  return true;
}
function checkRewardUnlocks() {
  for (const r of S.rewards.rules) if (!r.notified && S.rewards.balance >= r.cost) { r.notified = true; Store.save("rewards"); setTimeout(() => UI.celebrate(r), 400); }
}
function claimReward(id) {
  const r = S.rewards.rules.find((x) => x.id === id); if (!r || S.rewards.balance < r.cost) return false;
  S.rewards.balance -= r.cost; r.claimed = (r.claimed || 0) + 1; r.notified = false;
  S.rewards.ledger.push({ at: Date.now(), pts: -r.cost, reason: "Claimed: " + r.title });
  Store.save("rewards"); logActivity("claim", { rewardId: id }); return true;
}
function completeTask(id, { partial = false } = {}) {
  const t = S.tasks.items[id]; if (!t) return;
  const today = D.today();
  if (partial) {
    t.estMin = Math.max(15, Math.round(t.estMin / 2 / 5) * 5); t.status = "todo";
    const day = S.plan.days[today]; if (day) day.blocks.forEach((b) => { if (b.taskId === id && b.status === "planned") b.status = "partial"; });
    logActivity("partial", { taskId: id }); award(Math.round((S.profile.pointsRules.task || 10) / 2), "Progress: " + t.title);
    Store.save("tasks", "plan"); return;
  }
  t.status = "done"; t.doneAt = Date.now();
  const day = S.plan.days[today]; if (day) day.blocks.forEach((b) => { if (b.taskId === id && (b.status === "planned" || b.status === "active" || b.status === "partial")) b.status = "done"; });
  award((S.profile.pointsRules.task || 10) * (t.priority === "high" ? 2 : 1), t.title);
  logActivity("complete", { taskId: id, est: t.estMin, goalId: t.goalId });
  if (t.recurrence) {
    const next = nextOccurrence(t.recurrence, t.planDate || t.due || today);
    const n = createTask({ ...t, id: undefined, source: "recurrence", due: t.due ? next : null, planDate: next });
    n.recurrence = t.recurrence; n.postponed = 0; Store.save("tasks");
  }
  if (t.parentId) { const p = S.tasks.items[t.parentId]; if (p && childrenOf(p.id).every((c) => c.status === "done" || c.status === "dropped")) UI.toast("All steps of “" + p.title + "” are done.", { label: "Complete it", fn: () => { completeTask(p.id); UI.render(); } }); }
  Store.save("tasks", "plan");
  checkDailyGoal(today); checkWeekly(); checkMilestone(t);
}
function uncompleteTask(id) {
  const t = S.tasks.items[id]; if (!t || t.status !== "done") return;
  t.status = "todo"; t.doneAt = null;
  award(-(S.profile.pointsRules.task || 10) * (t.priority === "high" ? 2 : 1), "Undo: " + t.title);
  const day = S.plan.days[D.today()]; if (day) day.blocks.forEach((b) => { if (b.taskId === id && b.status === "done") b.status = "planned"; });
  S.activity.events = S.activity.events.filter((e) => !(e.type === "complete" && e.taskId === id && e.day === D.today()));
  Store.save("tasks", "plan", "activity");
}
function importantToday(date = D.today()) {
  const day = S.plan.days[date]; if (!day) return { done: 0, total: 0 };
  const bl = day.blocks.filter((b) => b.type === "task" && b.status !== "moved" && b.status !== "skipped");
  const ids = [...new Set(bl.map((b) => b.taskId))];
  return { done: ids.filter((i) => S.tasks.items[i]?.status === "done").length, total: ids.length };
}
function checkDailyGoal(date) {
  const { done, total } = importantToday(date);
  if (total >= 2 && done === total && award(S.profile.pointsRules.daily || 50, "Daily plan complete", "daily:" + date)) UI.toast("Today's plan is complete. +" + (S.profile.pointsRules.daily || 50) + " points.");
}
function checkWeekly() {
  const obj = thisWeekObjectives(); if (!obj.length) return;
  if (obj.every((o) => o.done) && award(S.profile.pointsRules.weekly || 250, "Weekly objectives complete", "weekly:" + D.weekStart(D.today()))) UI.toast("Every objective this week is done. +" + (S.profile.pointsRules.weekly || 250) + " points.");
}
function checkMilestone(t) {
  if (!t.milestoneId) return; const m = S.goals.milestones[t.milestoneId]; if (!m || m.status === "done") return;
  const ts = allTasks().filter((x) => x.milestoneId === m.id && x.status !== "dropped");
  if (ts.length >= 3 && ts.every((x) => x.status === "done")) UI.toast("Every task under “" + m.title + "” is done.", { label: "Mark milestone complete", fn: () => { completeMilestone(m.id); UI.render(); } });
}
function completeMilestone(id) {
  const m = S.goals.milestones[id]; if (!m || m.status === "done") return;
  m.status = "done"; m.doneAt = Date.now(); Store.save("goals");
  award(S.profile.pointsRules.milestone || 1000, "Milestone: " + m.title, "ms:" + id);
  logActivity("milestone", { milestoneId: id, goalId: m.goalId });
}
function activeDays() {
  const set = new Set();
  for (const e of S.activity.events) if (e.type === "complete" || e.type === "habit") set.add(e.day);
  return set;
}
function streak() {
  const days = activeDays(); let d = D.today(); if (!days.has(d)) d = D.add(d, -1);
  let n = 0; while (days.has(d)) { n++; d = D.add(d, -1); }
  return n;
}

/* ---------------- Carry-over (missed yesterday / earlier today) ---------------- */
function carryOver() {
  const today = D.today();
  return openTasks().filter((t) => t.planDate && D.diff(t.planDate, today) < 0);
}
function missedBlocksToday() {
  const day = S.plan.days[D.today()]; if (!day) return [];
  const n = D.nowMin();
  return day.blocks.filter((b) => b.type !== "event" && b.status === "planned" && b.end < n - 180);
}

/* ---------------- Analytics ---------------- */
function weekStats(ws = D.weekStart(D.today())) {
  const we = D.add(ws, 6), inWeek = (day) => day >= ws && day <= we;
  const ev = S.activity.events.filter((e) => inWeek(e.day));
  const completedIds = [...new Set(ev.filter((e) => e.type === "complete").map((e) => e.taskId))];
  const completed = completedIds.map((i) => S.tasks.items[i]).filter(Boolean);
  let planned = 0, plannedDone = 0;
  const daily = [];
  for (let i = 0; i < 7; i++) {
    const d = D.add(ws, i), day = S.plan.days[d];
    const tb = day ? day.blocks.filter((b) => b.type === "task" && b.status !== "moved") : [];
    const ids = [...new Set(tb.map((b) => b.taskId))];
    const done = ids.filter((x) => { const t = S.tasks.items[x]; return t && t.status === "done" && t.doneAt && D.ymd(t.doneAt) <= we; }).length;
    if (d <= D.today()) { planned += ids.length; plannedDone += done; }
    daily.push({ d, completed: ev.filter((e) => e.type === "complete" && e.day === d).length, planned: ids.length });
  }
  const postponeEv = ev.filter((e) => e.type === "postpone");
  const postCount = {};
  postponeEv.forEach((e) => (postCount[e.taskId] = (postCount[e.taskId] || 0) + 1));
  const postponed = Object.entries(postCount).map(([id, n]) => ({ t: S.tasks.items[id], n })).filter((x) => x.t).sort((a, b) => b.n - a.n);
  const parts = { morning: 0, afternoon: 0, evening: 0 };
  ev.filter((e) => e.type === "complete").forEach((e) => { parts[e.hour < 12 ? "morning" : e.hour < 17 ? "afternoon" : "evening"]++; });
  const habits = Object.values(S.habits.items).map((h) => ({ h, done: habitWeekCount(h, ws), target: h.perWeek }));
  const goals = Object.values(S.goals.goals).filter((g) => g.status !== "archived").map((g) => ({ g, progress: goalProgress(g.id), doneThisWeek: completed.filter((t) => t.goalId === g.id).length }));
  const overdue = openTasks().filter((t) => t.due && D.diff(t.due, D.today()) < 0);
  const productiveMin = sum(completed, (t) => t.estMin) + sum(ev.filter((e) => e.type === "focus"), (e) => e.min || 0);
  const milestones = ev.filter((e) => e.type === "milestone").length;
  return { ws, we, completed, planned, plannedDone, rate: planned ? plannedDone / planned : null, rescheduled: postponeEv.length, postponed, parts, habits, goals, overdue, productiveMin, daily, milestones };
}
function bestDaypart() {
  const parts = { morning: 0, afternoon: 0, evening: 0 };
  S.activity.events.filter((e) => e.type === "complete").slice(-200).forEach((e) => { parts[e.hour < 12 ? "morning" : e.hour < 17 ? "afternoon" : "evening"]++; });
  const tot = parts.morning + parts.afternoon + parts.evening;
  if (tot < 8) return null;
  const top = Object.entries(parts).sort((a, b) => b[1] - a[1])[0];
  return top[1] / tot >= 0.45 ? top[0] : null;
}

/* ---------------- Personal knowledge: chunking + BM25 retrieval ----------------
   Retriever interface: search(query, k) → [{docId, name, part, text, score}].
   Today: lexical BM25 in the browser. An embedding retriever can replace it without
   touching callers. */
const STOP = new Set("a an the and or but if of to in on at by for with from is are was were be been it this that these those i me my we our you your he she they them his her its as not no do does did have has had will would can could should about into over than then so just also what which who whom when where why how all any each more most other some such only own same too very s t now there here up out".split(" "));
function tokens(s) { return String(s).toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w)).map((w) => w.replace(/(ing|ed|es|s)$/, "").slice(0, 24)); }
function chunkText(text, size = 900, overlap = 150) {
  const clean = String(text).replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
  const out = []; let i = 0;
  while (i < clean.length) {
    let end = Math.min(clean.length, i + size);
    if (end < clean.length) { const br = clean.lastIndexOf("\n", end); const dot = clean.lastIndexOf(". ", end); const cut = Math.max(br, dot); if (cut > i + size * 0.5) end = cut + 1; }
    out.push(clean.slice(i, end).trim()); if (end >= clean.length) break; i = Math.max(end - overlap, i + 1);
  }
  return out.filter(Boolean);
}
const KB = {
  chunks: [], loaded: new Set(),
  async ensure() {
    const docs = Object.values(S.kbindex.docs);
    await Promise.all(docs.filter((d) => !this.loaded.has(d.id)).map(async (d) => {
      const parts = await Promise.all(Array.from({ length: d.parts || 1 }, (_, i) => Store.read("kb_" + d.id + "_" + i).catch(() => null)));
      const chunks = parts.flatMap((p) => (p && p.chunks) || []);
      chunks.forEach((text, i) => this.chunks.push({ docId: d.id, name: d.name, part: i + 1, text, tok: tokens(text) }));
      this.loaded.add(d.id);
    }));
    this.chunks = this.chunks.filter((c) => S.kbindex.docs[c.docId]);
  },
  search(q, k = 4) {
    const qt = [...new Set(tokens(q))]; if (!qt.length || !this.chunks.length) return [];
    const N = this.chunks.length, avg = sum(this.chunks, (c) => c.tok.length) / N;
    const df = {}; qt.forEach((w) => (df[w] = this.chunks.filter((c) => c.tok.includes(w)).length));
    const scored = this.chunks.map((c) => {
      let s = 0; const len = c.tok.length;
      for (const w of qt) { const f = c.tok.filter((x) => x === w).length; if (!f) continue; const idf = Math.log(1 + (N - df[w] + 0.5) / (df[w] + 0.5)); s += idf * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * len / avg)); }
      if (tokens(c.name).some((w) => qt.includes(w))) s += 0.8;
      return { ...c, score: s };
    }).filter((c) => c.score > 0.6).sort((a, b) => b.score - a.score);
    return scored.slice(0, k);
  },
  async add(name, text) {
    const id = uid("d"); const chunks = chunkText(text);
    const parts = []; let cur = [], size = 0;
    for (const c of chunks) { if (size + c.length > 180000 && cur.length) { parts.push(cur); cur = []; size = 0; } cur.push(c); size += c.length; }
    if (cur.length) parts.push(cur);
    for (let i = 0; i < parts.length; i++) await Store.write("kb_" + id + "_" + i, { name, chunks: parts[i] });
    S.kbindex.docs[id] = { id, name, chars: text.length, chunks: chunks.length, parts: parts.length, addedAt: Date.now() };
    Store.save("kbindex");
    chunks.forEach((t, i) => this.chunks.push({ docId: id, name, part: i + 1, text: t, tok: tokens(t) }));
    this.loaded.add(id);
    return S.kbindex.docs[id];
  },
  async remove(id) {
    const d = S.kbindex.docs[id]; if (!d) return;
    for (let i = 0; i < (d.parts || 1); i++) await Store.remove("kb_" + id + "_" + i).catch(() => {});
    delete S.kbindex.docs[id]; this.chunks = this.chunks.filter((c) => c.docId !== id); this.loaded.delete(id); Store.save("kbindex");
  },
};

/* ---------------- Memory facts ---------------- */
function remember(text, type = "fact") {
  const dup = Object.values(S.memory.facts).find((f) => f.text.toLowerCase() === String(text).toLowerCase());
  if (dup) return dup;
  const f = { id: uid("m"), text: String(text).slice(0, 400), type, at: Date.now() };
  S.memory.facts[f.id] = f; Store.save("memory"); return f;
}

/* A block may be one session of a larger task (> 2h). Finishing the session shrinks the
   remaining estimate; the task completes when nothing remains. */
function completeBlock(b) {
  if (!b) return;
  if (b.type === "habit") { const h = S.habits.items[b.habitId]; if (h && !h.log?.[D.today()]) toggleHabit(h.id); b.status = "done"; Store.save("plan"); return; }
  const t = b.taskId && S.tasks.items[b.taskId]; if (!t) return;
  if (b.session && t.estMin > b.session + 10) {
    t.estMin -= b.session; b.status = "done";
    award(S.profile.pointsRules.task || 10, "Session: " + t.title);
    logActivity("focus", { taskId: t.id, min: b.session });
    t.planDate = null; Store.save("tasks", "plan");
    UI.toast("Session done. " + D.dur(t.estMin) + " left on “" + t.title + "”.");
    return;
  }
  completeTask(t.id);
}


/* ================= Adaptive layer (phase 2) =================
   Everything here learns from the activity log with plain arithmetic. */
const round5 = (m) => Math.max(5, Math.round(m / 5) * 5);
function nextOccurrence(rule, fromDate) {
  const base = D.diff(fromDate, D.today()) < 0 ? D.today() : fromDate;
  let d = D.add(base, 1);
  if (rule === "weekly") return D.add(base, 7);
  if (rule === "weekdays") { while (D.isWeekend(d)) d = D.add(d, 1); return d; }
  return d; // daily
}
/* How long things really take vs. the estimate (median ratio of focus sessions). */
function paceStats() {
  if (S.profile.adaptive === false) return null;
  const r = S.activity.events.filter((e) => e.type === "actual" && e.est >= 10 && e.min >= 3).slice(-30).map((e) => e.min / e.est).sort((a, b) => a - b);
  if (r.length < 4) return null;
  return { factor: clamp(r[Math.floor(r.length / 2)], 0.8, 1.8), n: r.length };
}
function paceFactor() { const p = paceStats(); return p && Math.abs(p.factor - 1) >= 0.1 ? p.factor : 1; }
/* Use the time of day the user actually finishes things, once there's enough evidence. */
function learnedPeak() { if (S.profile.adaptive === false) return S.profile.peak; return bestDaypart() || S.profile.peak; }

/* Shift the rest of today after a delay. Order is kept; nothing is saved until approved. */
function reflowToday() {
  const today = D.today(), day = S.plan.days[today]; if (!day) return null;
  const n = D.nowMin();
  const fixed = day.blocks.filter((b) => b.type === "event" || b.status !== "planned" || (b.taskId && S.tasks.items[b.taskId]?.status === "done"));
  const movable = day.blocks.filter((b) => !fixed.includes(b)).sort((a, b) => a.start - b.start);
  let segs = freeSegments(today, { fromMin: n + 5, excludeBlocks: false });
  for (const b of fixed) if (b.type !== "event" && b.end > n && b.status !== "skipped" && b.status !== "moved") segs = subtract(segs, b.start, b.end + 10);
  let budget = Math.max(0, capacityFor(today) - doneMinutesOn(today));
  const moves = [], overflow = [];
  for (const b of movable) {
    const dur = b.end - b.start;
    if (dur > budget) { overflow.push(b); continue; }
    // keep a block where it is when its slot is still free; otherwise take the next free slot
    const keep = b.start >= n + 5 && segs.some(([a, e]) => b.start >= a && b.end <= e);
    const st = keep ? b.start : place(segs, dur, null);
    if (st == null) { overflow.push(b); continue; }
    moves.push({ b, from: b.start, to: st }); segs = subtract(segs, st, st + dur + 10); budget -= dur;
  }
  return { moves, overflow };
}
function applyReflow(r) {
  for (const m of r.moves) { const d = m.b.end - m.b.start; m.b.start = m.to; m.b.end = m.to + d; m.b.startPrompted = false; m.b.checked = false; }
  const tmr = D.add(D.today(), 1);
  for (const b of r.overflow) { if (b.taskId && S.tasks.items[b.taskId]) moveTask(S.tasks.items[b.taskId], tmr, null, { reason: "reflow" }); else b.status = "skipped"; }
  S.plan.days[D.today()].blocks.sort((a, b) => a.start - b.start);
  Store.save("plan", "tasks"); logActivity("reflow", { moved: r.moves.length, overflow: r.overflow.length });
}

/* Spread open work across the next 7 days, before deadlines, by lightest load. */
function planWeek() {
  const today = D.today(), days = Array.from({ length: 7 }, (_, i) => D.add(today, i));
  const cap = {}, load = {};
  for (const d of days) {
    cap[d] = d === today ? Math.max(0, Math.min(capacityFor(d) - doneMinutesOn(d), sum(freeSegments(d, { fromMin: D.nowMin() + 5, excludeBlocks: false }), ([a, b]) => b - a) * 0.75)) : capacityFor(d);
    const habits = sum(Object.values(S.habits.items), (h) => h.durMin * (h.perWeek || 3) / 7);
    load[d] = S.plan.days[d] ? plannedLoad(d) : sum(openTasks().filter((t) => t.planDate === d), (t) => t.estMin) + habits;
  }
  const pace = paceFactor();
  const pool = candidateTasks(today).filter((t) => !t.planDate || D.diff(t.planDate, today) < 0)
    .filter((t) => t.due || t.priority === "high" || t.goalId || t.isNextAction)
    .sort((a, b) => (a.due || "9999") < (b.due || "9999") ? -1 : (a.due || "9999") > (b.due || "9999") ? 1 : scoreTask(b, today) - scoreTask(a, today));
  const assign = [], unplaced = [];
  for (const t of pool) {
    const est = round5(t.estMin * pace);
    const last = t.due ? (D.diff(t.due, today) < 0 ? today : D.diff(t.due, days[6]) > 0 ? days[6] : t.due) : days[6];
    const allowed = days.filter((d) => d <= last);
    const fits = allowed.filter((d) => load[d] + Math.min(est, 120) <= cap[d] * 0.9);
    const pick = (fits.length ? fits : allowed).sort((a, b) => load[a] / Math.max(1, cap[a]) - load[b] / Math.max(1, cap[b]) || (a < b ? -1 : 1))[0];
    if (!pick || (!fits.length && !t.due)) { unplaced.push(t); continue; }
    load[pick] += Math.min(est, 120);
    assign.push({ t, date: pick, tight: !fits.length });
    if (assign.length >= 25) break;
  }
  return { days, cap, load, assign, unplaced };
}
function applyWeek(w) {
  for (const a of w.assign) { a.t.planDate = a.date; if (S.plan.days[a.date]) insertIntoDay(a.t, a.date); }
  Store.save("tasks", "plan"); logActivity("planweek", { n: w.assign.length });
}

/* Deadlines that can't fit in the free time left before them. */
function deadlineRisks() {
  const today = D.today();
  const due = openTasks().filter((t) => t.due && D.diff(t.due, today) >= 0 && D.diff(t.due, today) <= 7);
  const dates = [...new Set(due.map((t) => t.due))].sort();
  const pace = paceFactor(); const risks = [];
  for (const d of dates) {
    const work = sum(openTasks().filter((t) => t.due && t.due <= d && D.diff(t.due, today) >= 0), (t) => t.estMin * pace);
    let free = 0; for (let x = today; x <= d; x = D.add(x, 1)) free += x === today ? Math.max(0, Math.min(capacityFor(x) - doneMinutesOn(x), sum(freeSegments(x, { fromMin: D.nowMin(), excludeBlocks: false }), ([a, b]) => b - a) * 0.75)) : capacityFor(x);
    if (work > free) risks.push({ date: d, work: Math.round(work), free: Math.round(free), tasks: due.filter((t) => t.due === d) });
  }
  return risks;
}
