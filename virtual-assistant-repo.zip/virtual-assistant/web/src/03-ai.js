/* ============================================================
   03 AI ORCHESTRATION — language understanding, decomposition,
   planning advice, summaries. The model proposes structured
   actions; deterministic code (02) executes them.
   ============================================================ */

const AI = {
  fn: null, ready: false, off: false, offReason: "",
  async init() {
    try { if (window.claude && typeof window.claude.use === "function") this.fn = await window.claude.use("sample"); } catch {}
    this.ready = true; if (!this.fn) { this.off = true; this.offReason = "unavailable"; }
    UI.render();
  },
  get on() { return !!this.fn && !this.off; },
  message(e) {
    const c = e && e.code;
    if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].includes(c)) return "The assistant isn't allowed in this view. Planning, tasks and reminders still work.";
    if (c === "no_key") return "Add your Anthropic API key in Settings → Assistant to use the AI features.";
    if (c === "bad_key") return "Your Anthropic API key was rejected. Check it in Settings → Assistant.";
    if (c === "rate_limited") return "Too many requests right now. Try again in a minute.";
    if (c === "session_expired") return "Your session expired. Sign in again to use the assistant.";
    if (c === "prompt_too_large") return "That's too much at once. Try a shorter message.";
    if (c === "invalid_json") return "I couldn't structure that answer. Try again.";
    if (c === "refused") return "I can't help with that one.";
    if (c === "cancelled") return "Stopped.";
    return "Connection problem. Try again.";
  },
  disableIf(e) { if (["not_granted", "sampling_disabled", "not_declared", "capability_disabled", "capability_removed"].includes(e?.code)) { this.off = true; this.offReason = e.code; } },
  async json(input, opts = {}) {
    if (!this.on) throw { code: "not_granted", message: "AI unavailable" };
    try { return await this.fn.json(input, { cache: false, ...opts }); }
    catch (e) { this.disableIf(e); throw e; }
  },
};

const STRICT = {
  gentle: "Gentle — soft suggestions, never pushy. e.g. 'This is still pending. Want to move it?'",
  balanced: "Balanced — clear and kind, name the trade-off.",
  direct: "Direct — say it plainly. e.g. 'You've postponed this twice. Let's schedule it now.'",
  strict: "Strict — hold the line. e.g. 'This has been postponed three times. It stays on today's plan; do the smallest version.'",
};
function persona() {
  const p = S.profile;
  return `You are the personal executive assistant inside ${p.name}'s planning app. You behave like an excellent human executive assistant: intelligent, calm, concise, direct, practical, supportive without hype, occasionally challenging, never judgmental. No motivational clichés, no cheerleading, no emoji, no exclamation marks. Usually 1–4 short sentences.
Strictness setting: ${STRICT[p.strictness] || STRICT.balanced}`;
}
function calendarTable() {
  const t = D.today(); const out = [];
  for (let i = -1; i <= 13; i++) { const d = D.add(t, i); out.push(d + " " + DOW[D.dow(d)] + (i === 0 ? " (today)" : i === 1 ? " (tomorrow)" : i === -1 ? " (yesterday)" : "")); }
  return out.join("; ");
}
function taskLine(t) {
  const bits = [t.id, t.title];
  if (t.planDate) bits.push("planned " + t.planDate); if (t.due) bits.push("due " + t.due);
  bits.push(t.estMin + "m", t.priority);
  if (t.projectId && S.goals.projects[t.projectId]) bits.push("project: " + S.goals.projects[t.projectId].title);
  else if (t.goalId && S.goals.goals[t.goalId]) bits.push("goal: " + S.goals.goals[t.goalId].title);
  if (t.postponed) bits.push("postponed ×" + t.postponed);
  if (isBlocked(t)) bits.push("blocked");
  return "- " + bits.join(" | ");
}
function buildContext({ query = "", excerpts = [] } = {}) {
  const p = S.profile, today = D.today(), now = new Date();
  const L = [];
  L.push(`NOW: ${today} ${DOW[now.getDay()]} ${D.toHHMM(D.nowMin())} (local time)`);
  L.push("CALENDAR: " + calendarTable());
  L.push(`PROFILE: name ${p.name}; wakes ${p.wake}; sleeps ${p.sleep}; most productive: ${p.peak}; free time ~${p.freeHours.weekday}h weekdays, ${p.freeHours.weekend}h weekends; tends to forget: ${p.forgets || "—"}; usual blockers: ${p.blockers || "—"}; motivated by: ${(p.motivators || []).join(", ") || "—"}.`);
  if (p.summary) L.push("PROFILE SUMMARY: " + p.summary);
  const day = S.plan.days[today];
  if (day) {
    L.push(`TODAY'S PLAN (focus: ${day.focus || "—"}):`);
    day.blocks.forEach((b) => L.push(`- ${D.fmtRange(b.start, b.end)} ${b.title} [${b.type}${b.taskId ? " " + b.taskId : ""}; ${b.status}]`));
  } else L.push("TODAY'S PLAN: not planned yet.");
  L.push(`TODAY LOAD: capacity ${D.dur(capacityFor(today))}, planned ${D.dur(plannedLoad(today))}, free until next fixed item: ${D.dur(minutesUntilNextFixed(today).min)}.`);
  const ps = paceStats(); if (ps) L.push(`LEARNED: tasks usually take ${ps.factor.toFixed(1)}× the estimate (${ps.n} sessions); finishes most in the ${bestDaypart() || "—"}.`);
  const risks = deadlineRisks(); if (risks.length) L.push("DEADLINE RISKS: " + risks.map((r) => `${r.date}: ${D.dur(r.work)} of work vs ${D.dur(r.free)} free`).join("; "));
  const vision = S.goals.vision; if (vision) L.push("VISION: " + vision);
  const goals = Object.values(S.goals.goals).filter((g) => g.status !== "archived");
  if (goals.length) {
    L.push("GOALS:");
    goals.forEach((g) => {
      L.push(`- [${g.id}] ${g.title}${g.targetDate ? " (target " + g.targetDate + ")" : ""} — ${Math.round(goalProgress(g.id) * 100)}%`);
      goalMilestones(g.id).forEach((m) => L.push(`   milestone [${m.id}] ${m.title} due ${m.due} ${m.status === "done" ? "(done)" : ""}; projects: ${milestoneProjects(m.id).map((x) => x.title).join(", ")}`));
    });
  }
  const loose = Object.values(S.goals.projects).filter((x) => !x.goalId); if (loose.length) L.push("OTHER PROJECTS: " + loose.map((x) => x.title).join(", "));
  const open = openTasks().sort((a, b) => scoreTask(b, today) - scoreTask(a, today)).slice(0, 60);
  L.push("OPEN TASKS (" + openTasks().length + "):"); open.forEach((t) => L.push(taskLine(t)));
  const recentDone = allTasks().filter((t) => t.status === "done" && t.doneAt && Date.now() - t.doneAt < 7 * 864e5).slice(-10);
  if (recentDone.length) L.push("DONE THIS WEEK: " + recentDone.map((t) => t.title).join("; "));
  const habits = Object.values(S.habits.items);
  if (habits.length) L.push("HABITS: " + habits.map((h) => `${h.title} ${habitWeekCount(h)}/${h.perWeek} this week`).join("; "));
  const ev = Object.values(S.cal.events).slice(0, 25);
  if (ev.length) L.push("FIXED COMMITMENTS: " + ev.map((e) => `${e.title} ${e.date || (e.days || []).map((d) => DOW[d]).join("/")} ${e.start}-${e.end}`).join("; "));
  const facts = Object.values(S.memory.facts).slice(-40);
  if (facts.length) { L.push("MEMORY (things the user told you):"); facts.forEach((f) => L.push(`- (${f.type}) ${f.text}`)); }
  const docs = Object.values(S.kbindex.docs);
  if (docs.length) L.push("UPLOADED DOCUMENTS: " + docs.map((d) => "'" + d.name + "'").join(", "));
  if (excerpts.length) {
    L.push("DOCUMENT EXCERPTS (retrieved for this message — quote only from these):");
    excerpts.forEach((c) => L.push(`[${c.name}, part ${c.part}] ${c.text.slice(0, 1400)}`));
  } else if (docs.length) L.push("DOCUMENT EXCERPTS: none matched this message.");
  return L.join("\n");
}

const ACTION_SPEC = `Return ONLY JSON: {"reply": string, "actions": [ ... ]} — "reply" first.
Action types:
{"type":"add_task","title":str,"when":phrase|null,"repeat":"daily|weekdays|weekly"|null,"estMin":int,"priority":"high|medium|low","energy":"high|medium|low","kind":"task|followup|errand","project":name|null,"goal":name|null,"people":[str],"notes":str}
{"type":"add_event","title":str,"when":phrase,"start":"HH:MM","end":"HH:MM"|null,"repeat":["mon","tue",...]|null}
{"type":"add_habit","title":str,"perWeek":int,"durMin":int,"preferredTime":"morning|afternoon|evening|any"}
{"type":"add_goal","title":str,"why":str,"when":phrase|null,"decompose":true}
{"type":"complete_task","taskId":id}
{"type":"update_task","taskId":id,"title":str?,"estMin":int?,"priority":str?,"notes":str?}
{"type":"move_task","taskId":id,"when":phrase}  — only when the user names the new day/time
{"type":"offer_reschedule","taskId":id} — couldn't finish / wants it moved without a target
{"type":"drop_task","taskId":id}
{"type":"stuck","taskId":id|null} — avoiding, blocked, procrastinating
{"type":"what_now"}  {"type":"plan_day","day":"today|tomorrow"}  {"type":"fit_time","minutes":int}
{"type":"carry_over"} — didn't finish things yesterday
{"type":"open_brain_dump"} — wants to unload lots of things / overwhelmed
{"type":"remember","text":str,"category":"preference|fact|person|goal_context"} — durable facts the user states about themselves only
{"type":"set_strictness","value":"gentle|balanced|direct|strict"}
{"type":"weekly_review"}
{"type":"plan_week"} — too much this week / organise the week / deadlines piling up
{"type":"reflow_today"} — running late, a session ran over, "push everything back"`;

const CHAT_RULES = () => `${persona()}

HOW YOU WORK
- You change data ONLY through actions. Never say you added, moved, completed or scheduled something unless that action is in "actions"; the app shows the user what each action did, so don't repeat details at length.
- Never calculate dates or times yourself. Copy the user's own phrase into "when" ("tomorrow", "next Thursday", "before Friday", "in six months", "today 3pm"). The app resolves it.
- Schedules, free time, load and "what now" are computed by the app: use what_now, plan_day, plan_week, reflow_today, fit_time, offer_reschedule, carry_over rather than inventing a schedule.
- Recurring tasks ("every morning", "each Monday") → add_task with repeat; recurring behaviours with flexible weekly targets (exercise 3x/week) → add_habit.
- Multi-week or multi-month ambitions → one add_goal with decompose true (the app runs a breakdown the user reviews). Don't list its tasks yourself.
- Several separate things in one message → one action per item.
- Questions about what the user said, planned or wrote: answer only from MEMORY, DOCUMENT EXCERPTS, GOALS/TASKS or this conversation, and name the source ("Your document 'Launch plan' says…", "You told me…"). If it isn't there, say you don't have that information. Never invent what the user said.
- Plans that exceed free time: say so plainly with the numbers the app gives you, and use plan_day so the app can prioritise.
- Use task ids exactly as listed (e.g. t_ab12x). If the user refers to "my 3 PM task", find it in TODAY'S PLAN.

${ACTION_SPEC}`;

/* Stream the "reply" field out of partial JSON so the answer appears as it is written. */
function partialReply(raw) {
  const m = raw.match(/"reply"\s*:\s*"((?:[^"\\]|\\.)*)/); if (!m) return "";
  try { return JSON.parse('"' + m[1].replace(/\\$/, "") + '"'); } catch { return m[1].replace(/\\n/g, "\n").replace(/\\"/g, '"'); }
}

async function aiChat(userText, { onText, signal } = {}) {
  await KB.ensure().catch(() => {});
  const excerpts = KB.search(userText + " " + (S.chat.turns.slice(-2).map((t) => t.text).join(" ")), 4);
  const hist = S.chat.turns.filter((t) => t.text && !t.local).slice(-12).map((t) => ({ role: t.role === "user" ? "user" : "assistant", content: t.text.slice(0, 1500) }));
  const input = [{ role: "user", content: CHAT_RULES() + "\n\nCONTEXT\n" + buildContext({ query: userText, excerpts }) + "\n\n(Conversation follows.)" }, ...hist, { role: "user", content: userText }];
  while (JSON.stringify(input).length > 60000 && input.length > 3) input.splice(1, 1);
  const res = await AI.json(input, { signal, onText: ({ text }) => onText && onText(partialReply(text)) });
  return { reply: String(res?.reply || "").trim(), actions: Array.isArray(res?.actions) ? res.actions : [], excerpts };
}

async function aiBrainDump(text) {
  const prompt = `${persona()}
The user just brain-dumped everything on their mind. Organise it. Extract every distinct item; don't invent items and don't split one item into many.
Kinds: "task" (single action; includes deadlines — set when), "followup" (contact/reply to someone), "appointment" (fixed-time meeting/event), "habit" (recurring behaviour like exercise 3x/week), "goal" (outcome over weeks/months), "project" (multi-step effort), "idea" (not actionable yet), "info" (something to remember).
Per item: {"kind","title" (short, imperative for tasks),"when" (the user's exact time phrase or null — e.g. "before Friday", "tomorrow at 3pm"),"estMin" (realistic minutes, tasks only),"priority":"high|medium|low","energy":"high|medium|low","project" (name of a project/goal from this dump or EXISTING if it belongs to one, else null),"people":[names],"perWeek" (habits),"durMin" (habits/appointments),"notes"}.
Also "focus": the single most important objective for this week (short), and "summary": one plain sentence.
Return ONLY JSON {"items":[...],"focus":str,"summary":str}.

EXISTING GOALS/PROJECTS: ${[...Object.values(S.goals.goals), ...Object.values(S.goals.projects)].map((x) => x.title).join("; ") || "none"}
TODAY: ${D.today()} ${DOW[D.dow(D.today())]}

BRAIN DUMP:
"""${text.slice(0, 12000)}"""`;
  const res = await AI.json(prompt, { modelTier: "default" });
  return { items: Array.isArray(res?.items) ? res.items : [], focus: res?.focus || "", summary: res?.summary || "" };
}

async function aiDecompose({ title, why = "", months = 6, extra = "" }) {
  const p = S.profile;
  const commitments = Object.values(S.cal.events).map((e) => `${e.title} ${(e.days || []).map((d) => DOW[d]).join("/") || e.date} ${e.start}-${e.end}`).join("; ") || "none recorded";
  const prompt = `${persona()}
Break this goal into the MINIMUM useful structure for execution. No busywork, no hundreds of tasks.
GOAL: ${title}
WHY: ${why || "(not given)"}
HORIZON: ${months} months
USER CONTEXT: free time ~${p.freeHours.weekday}h on weekdays, ${p.freeHours.weekend}h weekends; most productive in the ${p.peak}; fixed commitments: ${commitments}; habits: ${Object.values(S.habits.items).map((h) => h.title + " " + h.perWeek + "x/week").join(", ") || "none"}; other active goals: ${Object.values(S.goals.goals).map((g) => g.title).join("; ") || "none"}.
${extra ? "WHAT THE USER SAID: " + extra.slice(0, 3000) : ""}

Rules:
- 3–6 milestones in order; "month" = the month (1..${months}) by which it should be done.
- Each milestone has 1–3 projects (the workstreams, e.g. product, customers, website, content, investors, learning).
- weekly_objectives: THIS week only, at most 4, each tied to a projectKey.
- tasks: THIS week only, 4–8 total, realistic inside the user's free time after commitments. Each: estMin 15–120, priority, energy, "day" (0 = today … 6), projectKey, dependsOn (keys). The FIRST task is a small next action (≤ 30 min) that can start today.
- If the user mentions recurring obligations: fixed-schedule ones (school, work, classes) → commitments (days/times only if the user gave them, else null); flexible ones (exercise 3x/week, reading) → habits.
- note: one sentence on realism/load.
Return ONLY JSON:
{"goal":{"title":str,"why":str},"milestones":[{"key":"m1","title":str,"month":int,"projects":[{"key":"p1","title":str}]}],"weekly_objectives":[{"projectKey":str,"title":str}],"tasks":[{"key":"t1","title":str,"projectKey":str,"estMin":int,"priority":str,"energy":str,"day":int,"dependsOn":[str]}],"habits":[{"title":str,"perWeek":int,"durMin":int,"preferredTime":str}],"commitments":[{"title":str,"days":["mon"],"start":"HH:MM"|null,"end":"HH:MM"|null}],"note":str}`;
  return AI.json(prompt, { modelTier: "default" });
}

async function aiStuck(t, blocker) {
  const prompt = `${persona()}
The user is stuck on a task. Help them move, practically. Reduce it to the smallest useful next step (5–15 minutes) they can start right now. If the task is big, also give 2–5 concrete steps.
TASK: ${t ? t.title + (t.notes ? " — " + t.notes : "") + ` (estimate ${t.estMin}m, postponed ${t.postponed || 0} times${t.goalId && S.goals.goals[t.goalId] ? ", part of goal: " + S.goals.goals[t.goalId].title : ""})` : "(not specified)"}
WHAT'S BLOCKING THEM: ${blocker}
Return ONLY JSON {"reply":str (2–3 sentences, direct, no cheerleading),"firstStep":{"title":str,"estMin":int},"steps":[{"title":str,"estMin":int}]}`;
  return AI.json(prompt, { modelTier: "default" });
}

async function aiOnboard(answers) {
  const prompt = `${persona()}
You just interviewed the user during onboarding. Build their initial personal productivity profile and extract structure. Don't invent anything they didn't say.
ANSWERS:
${Object.entries(answers).map(([k, v]) => k + ": " + (Array.isArray(v) ? v.join(", ") : v)).join("\n")}
TODAY: ${D.today()} ${DOW[D.dow(D.today())]}
Return ONLY JSON {"summary": str (3–4 sentences in second person: how they work, what gets in the way, how you'll support them),"goals":[{"title":str,"why":str,"when":phrase|null}],"commitments":[{"title":str,"days":["mon"],"start":"HH:MM"|null,"end":"HH:MM"|null}],"habits":[{"title":str,"perWeek":int,"durMin":int,"preferredTime":str}],"tasks":[{"title":str,"when":phrase|null,"estMin":int,"priority":str}],"memory":[{"text":str,"category":"preference|fact|person"}],"focus":str}`;
  return AI.json(prompt, { modelTier: "default" });
}

async function aiWeeklyReview(ws) {
  const st = weekStats(ws);
  const data = {
    week: ws + " to " + st.we, completionRate: st.rate == null ? null : Math.round(st.rate * 100) + "%",
    completed: st.completed.map((t) => t.title + (t.goalId && S.goals.goals[t.goalId] ? " (" + S.goals.goals[t.goalId].title + ")" : "")),
    planned: st.planned, plannedDone: st.plannedDone, rescheduled: st.rescheduled,
    mostPostponed: st.postponed.slice(0, 5).map((x) => x.t.title + " ×" + x.n),
    overdue: st.overdue.map((t) => t.title), productiveHours: +(st.productiveMin / 60).toFixed(1),
    completionsByTimeOfDay: st.parts, habits: st.habits.map((x) => x.h.title + " " + x.done + "/" + x.target),
    goals: st.goals.map((x) => x.g.title + " " + Math.round(x.progress * 100) + "% (" + x.doneThisWeek + " tasks this week)"),
    openHighPriority: openTasks().filter((t) => t.priority === "high").slice(0, 10).map((t) => t.id + " " + t.title),
    freeTime: S.profile.freeHours,
  };
  const prompt = `${persona()}
Write the user's weekly review from these numbers (computed by the app — use them as given, don't recalculate). Useful insight, not vanity stats. If data is thin, say so briefly.
DATA: ${JSON.stringify(data)}
Return ONLY JSON {"completed":str,"movedForward":str,"missed":str,"postponing":str,"attention":str,"priorities":[{"title":str,"taskId":id|null}] (max 3),"adjustment":str (one concrete change to next week's plan, e.g. move study to their most productive time or reduce load)}`;
  const r = await AI.json(prompt, { modelTier: "default" });
  return { ...r, stats: { rate: st.rate, completed: st.completed.length, rescheduled: st.rescheduled, productiveMin: st.productiveMin } };
}

/* ---------------- Deterministic fallbacks (AI unavailable) ---------------- */
function heuristicDump(text) {
  const parts = String(text).split(/\n|;|\.(?=\s)|,(?=\s)|\band\s+(?=(?:i\s+)?(?:need|want|have|should|must|remember|call|email|finish|read|buy|prepare|research|exercise|write|send|book|pay)\b)/i).map((s) => s.trim()).filter((s) => s.length > 2);
  const items = parts.map((raw) => {
    let s = raw.replace(/^(and |also |then |i (?:also )?(?:need|have|want|should|must) to |remember to |i need |i want to |need to |to )/i, "").trim();
    const w = resolveWhen(s);
    const habit = raw.match(/(\d+|one|two|three|four|five|six|seven) times (?:a|per) week|every day|daily/i);
    const kind = habit ? "habit" : /\b(call|email|text|message|reply|follow up|ping)\b/i.test(s) ? "followup" : /\b(launch|start a|build a|become|learn)\b.*\b(months?|year)\b/i.test(s) ? "goal" : /\bidea\b/i.test(s) ? "idea" : "task";
    const { title } = splitQuickAdd(s);
    return { kind, title: cap1(title.replace(/\s+(\d+|one|two|three|four|five|six|seven) times (?:a|per) week/i, "")), when: w ? s : null, estMin: 30, priority: "medium", perWeek: habit ? (NUMW[habit[1]?.toLowerCase()] || +habit[1] || 7) : undefined };
  });
  return { items, focus: "", summary: "" };
}

/* ---------------- Action executor ---------------- */
function findByName(coll, name) {
  if (!name) return null; const n = String(name).toLowerCase().trim();
  const arr = Object.values(coll);
  return arr.find((x) => x.title.toLowerCase() === n) || arr.find((x) => x.title.toLowerCase().includes(n) || n.includes(x.title.toLowerCase())) || null;
}
function findTask(ref) {
  if (!ref) return null; if (S.tasks.items[ref]) return S.tasks.items[ref];
  return findByName(Object.fromEntries(openTasks().map((t) => [t.id, t])), ref);
}
function ensureProject(name, goalId = null) {
  if (!name) return null;
  const g = findByName(S.goals.goals, name); if (g && !goalId) return { goalId: g.id, projectId: null };
  let p = findByName(S.goals.projects, name);
  if (!p) { p = { id: uid("p"), title: cap1(String(name)), goalId, milestoneId: null, status: "active", createdAt: Date.now() }; S.goals.projects[p.id] = p; Store.save("goals"); }
  return { goalId: p.goalId, projectId: p.id };
}
const DAYMAP = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
const daysFrom = (arr) => (Array.isArray(arr) ? arr.map((d) => DAYMAP[String(d).toLowerCase().slice(0, 3)]).filter((x) => x != null) : null);

function taskFromSpec(a, source) {
  const w = resolveWhen(a.when);
  let link = {};
  if (a.project) link = ensureProject(a.project) || {};
  else if (a.goal) { const g = findByName(S.goals.goals, a.goal); if (g) link = { goalId: g.id }; }
  const t = createTask({ recurrence: ["daily", "weekdays", "weekly"].includes(a.repeat) ? a.repeat : null, title: a.title, notes: a.notes, estMin: a.estMin, priority: a.priority, energy: a.energy, kind: a.kind === "followup" ? "followup" : a.kind === "errand" ? "errand" : "task", people: a.people, due: w?.date || null, dueTime: w?.time || null, source, ...link });
  // a date + time on a single task = do it then; a date alone = deadline
  if (w?.date && w.time) t.planDate = w.date;
  if (t.planDate && S.plan.days[t.planDate]) insertIntoDay(t, t.planDate, w?.time ? D.toMin(w.time) : null);
  return t;
}

/* Returns {receipts:[{text, undo}], cards:[{type,...}]} — cards need the user's decision. */
function applyActions(actions, source = "chat") {
  const receipts = [], cards = [];
  for (const a of actions || []) {
    try {
      switch (a.type) {
        case "add_task": {
          if (!a.title) break;
          const t = taskFromSpec(a, source);
          receipts.push({ text: "Added “" + t.title + "”" + (t.due ? " · " + (t.planDate ? D.label(t.planDate) + (t.dueTime ? " " + D.fmtTime(t.dueTime) : "") : "due " + D.label(t.due)) : ""), undo: { kind: "task", id: t.id } });
          break;
        }
        case "add_event": {
          const w = resolveWhen(a.when || "") || {};
          const start = a.start || w.time; if (!start) { cards.push({ type: "note", text: "I need a time for “" + a.title + "” to put it on your calendar." }); break; }
          const days = daysFrom(a.repeat);
          const e = addEvent({ title: a.title, date: days && days.length ? null : w.date || D.today(), days: days && days.length ? days : null, start, end: a.end || null });
          receipts.push({ text: "Calendar: " + e.title + " · " + (e.days ? e.days.map((d) => DOW[d]).join("/") : D.label(e.date)) + " " + D.fmtTime(e.start), undo: { kind: "event", id: e.id } });
          break;
        }
        case "add_habit": { const h = addHabit(a); receipts.push({ text: "Habit: " + h.title + " · " + h.perWeek + "×/week", undo: { kind: "habit", id: h.id } }); break; }
        case "add_goal": cards.push({ type: "goal", title: a.title, why: a.why || "", when: a.when || null }); break;
        case "complete_task": { const t = findTask(a.taskId); if (t && t.status !== "done") { completeTask(t.id); receipts.push({ text: "Completed “" + t.title + "”", undo: { kind: "complete", id: t.id } }); } break; }
        case "update_task": {
          const t = findTask(a.taskId); if (!t) break;
          const before = clone(t);
          if (a.title) t.title = String(a.title); if (a.estMin) t.estMin = clamp(+a.estMin, 5, 480); if (a.priority) t.priority = a.priority; if (a.notes) t.notes = a.notes;
          Store.save("tasks"); receipts.push({ text: "Updated “" + t.title + "”", undo: { kind: "restore", task: before } }); break;
        }
        case "move_task": { const t = findTask(a.taskId); const w = resolveWhen(a.when); if (t && w?.date) cards.push({ type: "move", taskId: t.id, date: w.date, time: w.time || null }); else if (t) cards.push({ type: "reschedule", taskId: t.id }); break; }
        case "offer_reschedule": { const t = findTask(a.taskId); if (t) cards.push({ type: "reschedule", taskId: t.id }); break; }
        case "drop_task": { const t = findTask(a.taskId); if (t) cards.push({ type: "drop", taskId: t.id }); break; }
        case "stuck": cards.push({ type: "stuck", taskId: findTask(a.taskId)?.id || null }); break;
        case "what_now": cards.push({ type: "now" }); break;
        case "plan_day": cards.push({ type: "plan", date: a.day === "tomorrow" ? D.add(D.today(), 1) : D.today() }); break;
        case "fit_time": cards.push({ type: "fit", minutes: clamp(+a.minutes || 60, 10, 600) }); break;
        case "carry_over": cards.push({ type: "carry" }); break;
        case "open_brain_dump": cards.push({ type: "dump" }); break;
        case "remember": { if (a.text) { const f = remember(a.text, a.category || "fact"); receipts.push({ text: "Remembered: " + f.text, undo: { kind: "memory", id: f.id } }); } break; }
        case "set_strictness": if (STRICT[a.value]) { S.profile.strictness = a.value; Store.save("profile"); receipts.push({ text: "Strictness set to " + a.value }); } break;
        case "weekly_review": cards.push({ type: "review" }); break;
        case "plan_week": cards.push({ type: "week" }); break;
        case "reflow_today": cards.push({ type: "reflow" }); break;
      }
    } catch (e) { console.warn("action failed", a, e); }
  }
  return { receipts, cards };
}
function undoReceipt(u) {
  if (!u) return;
  if (u.kind === "task") { delete S.tasks.items[u.id]; Object.values(S.plan.days).forEach((d) => (d.blocks = d.blocks.filter((b) => b.taskId !== u.id))); Store.save("tasks", "plan"); }
  if (u.kind === "event") { delete S.cal.events[u.id]; Store.save("cal"); }
  if (u.kind === "habit") { delete S.habits.items[u.id]; Store.save("habits"); }
  if (u.kind === "complete") uncompleteTask(u.id);
  if (u.kind === "memory") { delete S.memory.facts[u.id]; Store.save("memory"); }
  if (u.kind === "restore") { S.tasks.items[u.task.id] = u.task; Store.save("tasks"); }
}

/* Commit a reviewed decomposition into the goal hierarchy. */
function commitDecomposition(r, { months = 6, sel = null, goalId = null, habitSel = null } = {}) {
  const today = D.today();
  let g = goalId && S.goals.goals[goalId];
  if (g) { g.title = r.goal.title || g.title; g.why = g.why || r.goal.why || ""; g.targetDate = g.targetDate || D.addMonths(today, months); }
  else { g = { id: uid("g"), title: r.goal.title, why: r.goal.why || "", targetDate: D.addMonths(today, months), status: "active", createdAt: Date.now() }; S.goals.goals[g.id] = g; }
  const pmap = {};
  (r.milestones || []).forEach((m, i) => {
    const mid = uid("m");
    S.goals.milestones[mid] = { id: mid, goalId: g.id, title: m.title, due: D.endOfMonth(D.addMonths(today, clamp(+m.month || i + 1, 1, months) - 1)), order: i, status: "todo" };
    (m.projects || []).forEach((p) => { const pid = uid("p"); pmap[p.key] = pid; S.goals.projects[pid] = { id: pid, goalId: g.id, milestoneId: mid, title: p.title, status: "active", createdAt: Date.now() }; });
  });
  const ws = D.weekStart(today);
  (r.weekly_objectives || []).forEach((o) => { const id = uid("o"); const pid = pmap[o.projectKey] || null; S.goals.objectives[id] = { id, goalId: g.id, projectId: pid, week: ws, title: o.title, done: false }; });
  const tmap = {};
  (r.tasks || []).filter((t, i) => !sel || sel.has(i)).forEach((t, i) => {
    const pid = pmap[t.projectKey] || null;
    const nt = createTask({ title: t.title, estMin: t.estMin, priority: t.priority, energy: t.energy, projectId: pid, goalId: g.id, milestoneId: pid ? S.goals.projects[pid].milestoneId : null, planDate: D.add(today, clamp(+t.day || 0, 0, 6)), isNextAction: i === 0, source: "decompose" });
    tmap[t.key] = nt.id; t._id = nt.id;
  });
  (r.tasks || []).forEach((t) => { if (t._id && t.dependsOn) S.tasks.items[t._id].deps = t.dependsOn.map((k) => tmap[k]).filter(Boolean); });
  (r.habits || []).filter((h, i) => !habitSel || habitSel.has(i)).forEach((h) => { if (!findByName(S.habits.items, h.title)) addHabit(h); });
  (r.commitments || []).forEach((c) => { if (c.start && c.end && !findByName(S.cal.events, c.title)) addEvent({ title: c.title, days: daysFrom(c.days), start: c.start, end: c.end, kind: "commitment" }); });
  Store.save("goals", "tasks");
  logActivity("goal", { goalId: g.id });
  return g;
}
