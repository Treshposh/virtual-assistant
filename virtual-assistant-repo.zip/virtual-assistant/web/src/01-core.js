/* ============================================================
   DELLA — Personal executive assistant
   01 CORE: utilities, dates (deterministic), state, persistence
   ============================================================ */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = (p = "x") => p + "_" + Math.random().toString(36).slice(2, 7) + Date.now().toString(36).slice(-3);
const clone = (o) => JSON.parse(JSON.stringify(o));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sum = (arr, f = (x) => x) => arr.reduce((a, x) => a + (Number(f(x)) || 0), 0);

/* ---------------- Dates: all calendar math lives here, never in the LLM ---------------- */
const DOW = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
const DOW_LONG = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
const MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
const NUMW = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, a: 1, an: 1, couple: 2, few: 3 };

const D = {
  now: () => new Date(),
  ymd(d) { const x = new Date(d); return x.getFullYear() + "-" + String(x.getMonth() + 1).padStart(2, "0") + "-" + String(x.getDate()).padStart(2, "0"); },
  parse(s) { const [y, m, d] = String(s).split("-").map(Number); return new Date(y, m - 1, d); },
  today() { return D.ymd(new Date()); },
  add(s, n) { const d = D.parse(s); d.setDate(d.getDate() + n); return D.ymd(d); },
  addMonths(s, n) { const d = D.parse(s); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return D.ymd(d); },
  diff(a, b) { return Math.round((D.parse(a) - D.parse(b)) / 86400000); }, // a - b in days
  dow(s) { return D.parse(s).getDay(); },
  weekStart(s) { const w = D.dow(s); return D.add(s, w === 0 ? -6 : 1 - w); }, // Monday
  endOfMonth(s) { const d = D.parse(s); return D.ymd(new Date(d.getFullYear(), d.getMonth() + 1, 0)); },
  isWeekend(s) { const w = D.dow(s); return w === 0 || w === 6; },
  toMin(hhmm) { if (!hhmm) return null; const [h, m] = String(hhmm).split(":").map(Number); return h * 60 + (m || 0); },
  toHHMM(min) { min = Math.round(min); const h = Math.floor(min / 60) % 24, m = min % 60; return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0"); },
  nowMin() { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); },
  fmtTime(hhmm) { if (!hhmm) return ""; const m = typeof hhmm === "number" ? hhmm : D.toMin(hhmm); let h = Math.floor(m / 60) % 24; const mm = m % 60; const ap = h >= 12 ? "PM" : "AM"; h = h % 12 || 12; return h + (mm ? ":" + String(mm).padStart(2, "0") : "") + " " + ap; },
  fmtRange(a, b) { return D.toHHMM(a) + "–" + D.toHHMM(b); },
  label(s) {
    if (!s) return "";
    const t = D.today(), dd = D.diff(s, t);
    if (dd === 0) return "Today"; if (dd === 1) return "Tomorrow"; if (dd === -1) return "Yesterday";
    const d = D.parse(s);
    const base = d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" });
    return dd > 1 && dd < 7 ? d.toLocaleDateString(undefined, { weekday: "long" }) : base;
  },
  long(s) { return D.parse(s).toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" }); },
  dur(min) { min = Math.round(min || 0); if (min < 60) return min + "m"; const h = Math.floor(min / 60), m = min % 60; return h + "h" + (m ? " " + m + "m" : ""); },
  greeting() { const h = new Date().getHours(); return h < 5 ? "Working late" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"; },
};

/* Natural-language date resolution. The AI copies the user's own phrase ("next Thursday",
   "before Friday", "in six months"); this function turns it into a date. Returns
   {date:'YYYY-MM-DD'|null, time:'HH:MM'|null} or null when nothing is recognised. */
function resolveWhen(text, base = D.today()) {
  if (!text) return null;
  let s = " " + String(text).toLowerCase().replace(/[,.;!?]/g, " ").replace(/\s+/g, " ") + " ";
  let date = null, time = null;
  // ---- time ----
  let m;
  if ((m = s.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m|p\.m)\b/))) {
    let h = +m[1] % 12; if (m[3].startsWith("p")) h += 12; time = D.toHHMM(h * 60 + (+m[2] || 0));
  } else if ((m = s.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/))) {
    time = D.toHHMM(+m[1] * 60 + +m[2]);
  } else if ((m = s.match(/\bat (\d{1,2})\b/))) {
    let h = +m[1]; if (h >= 1 && h <= 7) h += 12; time = D.toHHMM(h * 60);
  } else if (/\bnoon\b|\bmidday\b/.test(s)) time = "12:00";
  else if (/\btonight\b/.test(s)) time = "20:00";
  else if (/\bthis morning\b|\bin the morning\b|\bmorning\b/.test(s)) time = "09:00";
  else if (/\bafternoon\b/.test(s)) time = "14:00";
  else if (/\bevening\b/.test(s)) time = "18:00";

  const before = /\b(before|by|until|no later than)\b/.test(s);
  // ---- explicit ISO ----
  if ((m = s.match(/\b(\d{4})-(\d{2})-(\d{2})\b/))) date = m[1] + "-" + m[2] + "-" + m[3];
  // ---- relative words ----
  if (!date) {
    if (/\bday after tomorrow\b/.test(s)) date = D.add(base, 2);
    else if (/\b(tomorrow|tmrw|tmr)\b/.test(s)) date = D.add(base, 1);
    else if (/\b(today|tonight|this afternoon|this evening|this morning|now|asap)\b/.test(s)) date = base;
    else if (/\bthis weekend\b|\bweekend\b/.test(s)) { const w = D.dow(base); date = D.add(base, w === 6 || w === 0 ? 0 : 6 - w); }
    else if (/\bend of (the )?week\b|\bthis week\b/.test(s)) { const w = D.dow(base); date = D.add(base, w <= 5 ? 5 - w : 0); if (w === 6 || w === 0) date = base; }
    else if (/\bnext week\b/.test(s)) date = D.add(D.weekStart(base), 7);
    else if (/\bend of (the )?month\b|\bthis month\b/.test(s)) date = D.endOfMonth(base);
    else if (/\bnext month\b/.test(s)) date = D.endOfMonth(D.addMonths(D.ymd(new Date(D.parse(base).getFullYear(), D.parse(base).getMonth(), 1)), 1));
    else if (/\bnext year\b/.test(s)) date = D.addMonths(base, 12);
  }
  // ---- in N units ----
  if (!date && (m = s.match(/\b(?:in |within |over the next |for )?(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|a|an|couple|few)(?: of)? (day|days|week|weeks|month|months|year|years)\b/))) {
    const n = /^\d+$/.test(m[1]) ? +m[1] : NUMW[m[1]] || 1;
    const u = m[2];
    if (u.startsWith("day")) date = D.add(base, n);
    else if (u.startsWith("week")) date = D.add(base, 7 * n);
    else if (u.startsWith("month")) date = D.addMonths(base, n);
    else date = D.addMonths(base, 12 * n);
  }
  // ---- month + day ----
  if (!date) {
    const mi = MONTHS.findIndex((mo) => new RegExp("\\b(" + mo + "|" + mo.slice(0, 3) + ")\\b").test(s));
    if (mi >= 0) {
      const mo3 = MONTHS[mi].slice(0, 3);
      const dm = s.match(new RegExp("\\b(\\d{1,2})(?:st|nd|rd|th)? (?:of )?(?:" + MONTHS[mi] + "|" + mo3 + ")\\b")) || s.match(new RegExp("\\b(?:" + MONTHS[mi] + "|" + mo3 + ") (\\d{1,2})(?:st|nd|rd|th)?\\b"));
      const b = D.parse(base);
      let y = b.getFullYear();
      if (dm) {
        let cand = D.ymd(new Date(y, mi, +dm[1]));
        if (D.diff(cand, base) < -1) cand = D.ymd(new Date(y + 1, mi, +dm[1]));
        date = cand;
      } else {
        // bare month: "before October" → last day of September; "in/by October" → end of October
        if (D.diff(D.ymd(new Date(y, mi + 1, 0)), base) < 0) y += 1;
        date = before ? D.add(D.ymd(new Date(y, mi, 1)), -1) : D.ymd(new Date(y, mi + 1, 0));
        if (D.diff(date, base) < 0) date = before ? D.add(D.ymd(new Date(y + 1, mi, 1)), -1) : D.ymd(new Date(y + 1, mi + 1, 0));
      }
    }
  }
  // ---- weekday ----
  if (!date) {
    const wi = DOW_LONG.findIndex((d) => new RegExp("\\b(" + d + "|" + d.slice(0, 3) + ")\\b").test(s));
    if (wi >= 0) {
      const w = D.dow(base);
      let delta = (wi - w + 7) % 7;
      if (delta === 0) delta = /\btoday\b/.test(s) ? 0 : 7;
      let cand = D.add(base, delta);
      if (/\bnext\b/.test(s) && D.weekStart(cand) === D.weekStart(base)) cand = D.add(cand, 7);
      date = cand;
    }
  }
  if (!date && time) date = base;
  if (!date && !time) return null;
  return { date, time };
}

/* Pull a trailing date phrase out of a quick-add string: "Call John tomorrow 3pm" */
function splitQuickAdd(text) {
  const r = resolveWhen(text);
  if (!r) return { title: text.trim(), when: null };
  const pat = /\s+(on |by |before |at |this |next |in )?(today|tonight|tomorrow|day after tomorrow|this weekend|next week|end of (the )?(week|month)|(next |this )?(mon|tues|wednes|thurs|fri|satur|sun)day|in \d+ (days?|weeks?|months?)|\d{1,2}(:\d{2})?\s*(am|pm)|at \d{1,2}(:\d{2})?|(january|february|march|april|may|june|july|august|september|october|november|december)( \d{1,2})?)\b/gi;
  const title = text.replace(pat, "").replace(/\s{2,}/g, " ").trim();
  return { title: title || text.trim(), when: r };
}

/* ---------------- State ---------------- */
const DEFAULTS = () => ({
  profile: {
    name: "Della", onboarded: false, wake: "07:00", sleep: "23:00", peak: "morning",
    freeHours: { weekday: 4, weekend: 6 }, strictness: "balanced", remind: "checkins",
    motivators: [], forgets: "", blockers: "", working: "", commitmentsText: "", summary: "",
    pointsRules: { task: 10, habit: 5, daily: 50, weekly: 250, milestone: 1000 },
    createdAt: Date.now(),
  },
  tasks: { items: {} },
  goals: { vision: "", goals: {}, milestones: {}, projects: {}, objectives: {} },
  habits: { items: {} },
  cal: { events: {}, providers: { internal: { connected: true } } },
  plan: { days: {} },
  rewards: { balance: 0, lifetime: 0, ledger: [], rules: [], awarded: {} },
  chat: { turns: [] },
  memory: { facts: {} },
  reviews: { items: {} },
  activity: { events: [] },
  kbindex: { docs: {} },
});
const KEYS = Object.keys(DEFAULTS());
let S = DEFAULTS();

/* ---------------- Persistence: db capability (private per user), localStorage fallback ---------------- */
const Store = {
  mode: "memory", db: null, uid: null, dirty: new Set(), writing: new Set(), timer: null, lastError: null, listeners: [],
  async init() {
    const cl = window.claude;
    if (cl && typeof cl.use === "function") {
      try {
        const [db, user] = await Promise.all([cl.use("db"), cl.use("user")]);
        const id = user ? await user.id() : null;
        if (db && id) { this.db = db; this.uid = id; this.mode = "cloud"; }
      } catch (e) { this.lastError = e; }
    }
    if (this.mode !== "cloud") { try { localStorage.setItem("della:probe", "1"); this.mode = "local"; } catch { this.mode = "memory"; } }
  },
  ref(key) { return this.db.doc("data/users/" + this.uid + "/" + key); },
  async read(key) {
    if (this.mode === "cloud") {
      for (let i = 0; i < 2; i++) {
        try { const snap = await this.ref(key).get(); return snap.exists ? clone(snap.data()) : null; }
        catch (e) { if (e && e.code === "unavailable" && i === 0) { await new Promise((r) => setTimeout(r, 400 + Math.random() * 600)); continue; } throw e; }
      }
    }
    if (this.mode === "local") { try { const v = localStorage.getItem("della:" + key); return v ? JSON.parse(v) : null; } catch { return null; } }
    return null;
  },
  async loadAll() {
    const base = DEFAULTS();
    const results = await Promise.all(KEYS.map((k) => this.read(k).catch((e) => { this.lastError = e; return null; })));
    KEYS.forEach((k, i) => { S[k] = deepMerge(base[k], results[i] || {}); });
  },
  save(...keys) { keys.forEach((k) => this.dirty.add(k)); clearTimeout(this.timer); this.timer = setTimeout(() => this.flush(), 500); this.emit(); },
  async flush() {
    const keys = [...this.dirty];
    for (const k of keys) {
      if (this.writing.has(k)) continue; // next flush picks it up
      this.dirty.delete(k); this.writing.add(k);
      try { await this.write(k, S[k]); this.lastError = null; }
      catch (e) { this.lastError = e; this.dirty.add(k); if (e && e.code === "quota_exceeded") toast("Storage is full. Delete old documents in Settings → Memory."); }
      finally { this.writing.delete(k); }
    }
    this.emit();
    if (this.dirty.size) { clearTimeout(this.timer); this.timer = setTimeout(() => this.flush(), 2500); }
  },
  async write(key, value) {
    if (this.mode === "cloud") return this.ref(key).set(clone(value));
    if (this.mode === "local") localStorage.setItem("della:" + key, JSON.stringify(value));
  },
  async remove(key) {
    if (this.mode === "cloud") return this.ref(key).delete();
    if (this.mode === "local") localStorage.removeItem("della:" + key);
  },
  pending() { return this.dirty.size + this.writing.size; },
  onChange(fn) { this.listeners.push(fn); },
  emit() { this.listeners.forEach((f) => { try { f(); } catch {} }); },
};
function deepMerge(base, over) {
  if (Array.isArray(base) || typeof base !== "object" || base === null) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over || {})) out[k] = base[k] !== undefined && typeof base[k] === "object" && !Array.isArray(base[k]) && over[k] && typeof over[k] === "object" && !Array.isArray(over[k]) ? deepMerge(base[k], over[k]) : over[k];
  return out;
}

/* Activity log (bounded) — feeds analytics and "learn from behaviour" */
function logActivity(type, data = {}) {
  S.activity.events.push({ at: Date.now(), day: D.today(), hour: new Date().getHours(), type, ...data });
  if (S.activity.events.length > 1500) S.activity.events = S.activity.events.slice(-1200);
  Store.save("activity");
}
