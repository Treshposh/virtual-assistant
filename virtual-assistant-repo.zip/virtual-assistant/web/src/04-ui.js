/* ============================================================
   04 UI — shell, views (Home, Today, Goals, Assistant, Progress)
   ============================================================ */

const IC = {
  home: '<path d="M3 11 12 4l9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  today: '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  goals: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
  chat: '<path d="M4 5.5h16v10H9l-5 4z" stroke-linejoin="round"/>',
  progress: '<path d="M5 20V11M12 20V5M19 20v-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  dump: '<path d="M4 6h16M4 12h10M4 18h13"/>',
  flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21"/>',
  send: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  check: '<path d="M5 12.5 10 17 19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  chev: '<path d="M9 6l6 6-6 6"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  compass: '<circle cx="12" cy="12" r="8.5"/><path d="M15.5 8.5 13.5 13.5 8.5 15.5 10.5 10.5z"/>',
  help: '<circle cx="12" cy="12" r="8.5"/><path d="M9.8 9.5a2.3 2.3 0 1 1 3.4 2c-.8.5-1.2 1-1.2 2M12 16.8v.2"/>',
  file: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/>',
  medal: '<circle cx="12" cy="14.5" r="5.5"/><path d="M8.5 3.5 12 9l3.5-5.5M12 12.5v4"/>',
  flame: '<path d="M12 21c-3.5 0-6-2.4-6-5.6 0-3.4 3-5.4 3.6-8.9C11.9 8 13 9.8 13 11.5c1-.6 1.6-1.8 1.7-3 1.9 1.5 3.3 4 3.3 6.9 0 3.2-2.5 5.6-6 5.6z"/>',
  play: '<path d="M8 5.5v13l10-6.5z"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v5h-5"/>',
  trash: '<path d="M5 7h14M10 7V4.5h4V7M7 7l1 13h8l1-13"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M5 20h14"/>',
  more: '<circle cx="6" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="18" cy="12" r="1.4" fill="currentColor"/>',
  bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20.5h4"/>',
  move: '<path d="M4 12h14M13 7l5 5-5 5"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
};
const icon = (n, cls = "") => `<svg class="${cls}" width="20" height="20" style="flex:none" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ""}</svg>`;

const UI = {
  tab: "home", day: null, goalId: null, dumpMode: false, busy: false, sheetStack: [], checkin: null, streaming: null,
  init() {
    document.body.insertAdjacentHTML("beforeend", `<div id="tabbar" class="tabbar"></div><div id="composer-slot"></div><div id="checkin-slot"></div><div id="sheet-slot"></div><div id="overlay-slot"></div><div id="toast-slot" aria-live="polite"></div>`);
    try { const t = localStorage.getItem("della:tab"); if (t) this.tab = t; } catch {}
    if (/^#(home|today|goals|assistant|progress)$/.test(location.hash)) this.tab = location.hash.slice(1);
  },
  go(tab) {
    this.tab = tab; this.goalId = tab === "goals" ? this.goalId : null;
    try { localStorage.setItem("della:tab", tab); } catch {}
    this.render(); window.scrollTo(0, 0);
    if (tab === "assistant") setTimeout(() => { const c = $("#chat-end"); c && c.scrollIntoView({ block: "end" }); }, 30);
  },
  render() {
    const app = $("#app"); if (!app) return;
    if (!BOOTED) { app.innerHTML = `<div class="view" style="padding-top:40px"><div class="skeleton" style="width:40%"></div><div class="skeleton" style="width:70%;height:28px"></div><div class="skeleton" style="height:140px;border-radius:18px"></div></div>`; return; }
    if (!S.profile.onboarded) { $("#tabbar").innerHTML = ""; $("#composer-slot").innerHTML = ""; app.innerHTML = Onboarding.view(); return; }
    // preserve typed text + focus across re-render
    const keep = {}; $$("#app input[id], #app textarea[id]").forEach((el) => (keep[el.id] = el.value));
    const focused = document.activeElement && document.activeElement.id;
    const views = { home: viewHome, today: viewToday, goals: viewGoals, assistant: viewAssistant, progress: viewProgress };
    app.innerHTML = topbar() + `<main class="view" id="view">${(views[this.tab] || viewHome)()}</main>`;
    for (const [id, v] of Object.entries(keep)) { const el = document.getElementById(id); if (el && !el.value) el.value = v; }
    if (focused) document.getElementById(focused)?.focus();
    this.renderTabs(); this.renderComposer(); renderCheckin();
  },
  renderTabs() {
    const tabs = [["home", "Home"], ["today", "Today"], ["goals", "Goals"], ["assistant", "Assistant"], ["progress", "Progress"]];
    $("#tabbar").innerHTML = `<nav aria-label="Main">${tabs.map(([k, l]) => `<button class="tab" data-act="go" data-tab="${k}" ${this.tab === k ? 'aria-current="page"' : ""}>${icon(k)}<span>${l}</span></button>`).join("")}</nav>`;
  },
  renderComposer() {
    const slot = $("#composer-slot");
    if (this.tab !== "assistant") { slot.innerHTML = ""; return; }
    if (slot.dataset.mode === String(this.dumpMode) && slot.firstChild) return;
    const prev = $("#composer")?.value || "";
    slot.dataset.mode = String(this.dumpMode);
    slot.innerHTML = `<div class="composer"><form class="in" id="composer-form" autocomplete="off">
      <button type="button" class="icon-btn" data-act="voice" data-target="composer" aria-label="Voice input">${icon("mic")}</button>
      <textarea id="composer" rows="1" placeholder="${this.dumpMode ? "Everything on your mind. No need to organise it." : "Tell me what's on your mind…"}" aria-label="Message">${esc(prev)}</textarea>
      <button type="submit" class="icon-btn primary" aria-label="Send">${icon("send")}</button></form></div>`;
    const ta = $("#composer"); const grow = () => { ta.style.height = "auto"; ta.style.height = Math.min(180, ta.scrollHeight) + "px"; };
    ta.addEventListener("input", grow); grow();
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !this.dumpMode && window.matchMedia("(pointer:fine)").matches) { e.preventDefault(); $("#composer-form").requestSubmit(); } });
    $("#composer-form").addEventListener("submit", (e) => { e.preventDefault(); const v = ta.value.trim(); if (!v || UI.busy) return; ta.value = ""; grow(); sendChat(v); });
  },
  toast(text, action = null, ms = 4200) {
    const slot = $("#toast-slot"); const id = uid("toast");
    slot.innerHTML = `<div class="toast ${UI.sheetOpen ? "top" : ""}" id="${id}" role="status"><span>${esc(text)}</span>${action ? `<button data-toast="${id}">${esc(action.label)}</button>` : ""}</div>`;
    if (action) slot.querySelector("button").onclick = () => { slot.innerHTML = ""; action.fn(); };
    setTimeout(() => { if ($("#" + id)) slot.innerHTML = ""; }, action ? ms + 2500 : ms);
  },
  celebrate(r) {
    openSheet(`<div class="sb" style="padding-top:24px;text-align:center;gap:16px">
      <div class="seal">${icon("medal")}</div>
      <div class="eyebrow">Reward unlocked</div>
      <h2>You earned your reward.</h2>
      <p class="ink2">You've reached <b class="mono">${S.rewards.balance}</b> points.</p>
      <div class="card" style="text-align:center"><div class="eyebrow">Reward</div><div style="font-size:20px;font-weight:800;margin-top:4px">${esc(r.title)}</div></div>
      <p class="small muted">Claiming spends ${r.cost} points. You can also save it for later.</p>
    </div><div class="sf"><button class="btn ghost grow" data-act="close">Save for later</button><button class="btn brass grow" data-act="claim" data-id="${r.id}">Claim now</button></div>`, { title: "" });
  },
};
const toast = (...a) => UI.toast(...a);

function topbar() {
  const pend = Store.pending(), err = Store.lastError && Store.mode === "cloud";
  const mode = Store.mode === "cloud" ? (err ? "Not saved — retrying" : pend ? "Saving…" : "Saved") : Store.mode === "local" ? "Saved on this device" : "Not saved";
  return `<header class="topbar"><div class="date">${esc(D.long(D.today()))}</div>
    <div class="row"><span class="sync ${err ? "err" : pend ? "busy" : ""}" title="${mode}"><i></i><span>${mode}</span></span>
    <button class="avatar" data-act="settings" aria-label="Profile and settings">${esc((S.profile.name || "D").charAt(0).toUpperCase())}</button></div></header>`;
}

/* ---------- small renderers ---------- */
function crumbs(t) {
  const g = taskGoal(t), p = taskProject(t), m = t.milestoneId && S.goals.milestones[t.milestoneId];
  const parts = [g && g.title, m && m.title, p && p.title].filter(Boolean);
  return parts.length ? `<div class="crumb">${parts.map((x) => `<span>${esc(x)}</span>`).join("")}</div>` : "";
}
function taskTags(t) {
  const out = [];
  if (t.priority === "high") out.push('<span class="tag high">High</span>');
  const due = t.due; if (due) { const dd = D.diff(due, D.today()); out.push(`<span class="tag ${dd < 0 ? "high" : dd <= 1 ? "warn" : ""}">${dd < 0 ? "Overdue" : "Due " + D.label(due)}${t.dueTime ? " " + D.fmtTime(t.dueTime) : ""}</span>`); }
  out.push(`<span class="tag">${D.dur(t.estMin)}</span>`);
  if (t.postponed >= 2) out.push(`<span class="tag warn">Moved ×${t.postponed}</span>`);
  if (isBlocked(t)) out.push('<span class="tag">Waiting</span>');
  if (t.kind === "followup") out.push('<span class="tag">Follow-up</span>');
  return out.join(" ");
}
function taskRow(t, { time = "", showCrumb = true } = {}) {
  const done = t.status === "done";
  return `<div class="item ${done ? "done" : ""}">
    <button class="check round ${done ? "on" : ""}" data-act="toggle-task" data-id="${t.id}" aria-label="${done ? "Mark not done" : "Mark done"}">${done ? icon("check") : ""}</button>
    <button class="tap grow" data-act="task" data-id="${t.id}">${time ? `<div class="mono small muted">${time}</div>` : ""}<div class="title">${esc(t.title)}</div>
      <div class="row wrap" style="gap:6px;margin-top:4px">${taskTags(t)}</div>${showCrumb ? crumbs(t) : ""}</button></div>`;
}
function rewardNext() {
  const rules = [...S.rewards.rules].sort((a, b) => a.cost - b.cost);
  const r = rules.find((x) => x.cost > S.rewards.balance) || null;
  const ready = rules.filter((x) => x.cost <= S.rewards.balance);
  return { next: r, ready };
}

/* ================= HOME ================= */
function viewHome() {
  const p = S.profile, today = D.today(), day = dayPlan(today);
  const hasAnything = openTasks().length || Object.keys(S.goals.goals).length;
  const { now, next, later } = nowNext(today);
  const imp = importantToday(today), st = streak(), rn = rewardNext();
  const focus = day?.focus || (Object.values(S.goals.goals)[0] && nextActionFor(Object.values(S.goals.goals)[0].id)?.title) || "";
  let h = `<section class="hello section"><h1>${D.greeting()}, ${esc(p.name)}</h1>
    ${focus ? `<p class="focus-line">Today's focus · <b>${esc(focus)}</b></p>` : `<p class="focus-line">What do you need to do today? Let's find out.</p>`}</section>`;

  h += briefingHtml();
  if (!hasAnything) {
    h += `<section class="card" style="display:flex;flex-direction:column;gap:12px;padding:20px">
      <div class="eyebrow">Start here</div><h2>Don't organise anything yet.</h2>
      <p class="ink2">Tell me everything on your mind — tasks, deadlines, ideas, goals. I'll sort it into a plan.</p>
      <div class="row wrap"><button class="btn accent" data-act="dump">${icon("dump")}Brain dump</button><button class="btn ghost" data-act="add-goal">${icon("flag")}Add a goal</button></div></section>`;
  } else if (!day) {
    const pr = buildPlan(today);
    const nTasks = pr.blocks.filter((b) => b.type === "task").length, nHab = pr.blocks.filter((b) => b.type === "habit").length;
    h += `<section class="now"><div class="eyebrow">Today, not planned yet</div>
      <div class="t">${pr.windowMin < 30 ? "The day is nearly over." : "I've drafted today: " + nTasks + " task" + (nTasks === 1 ? "" : "s") + (nHab ? " and " + nHab + " habit" + (nHab > 1 ? "s" : "") : "") + "."}</div>
      <div class="meta">${D.dur(pr.budget)} available${pr.overloaded ? " · you've asked for " + D.dur(pr.requested) + ", so I prioritised" : ""}${pr.focus ? " · focus: " + esc(pr.focus) : ""}</div>
      <div class="row wrap"><button class="btn" data-act="plan" data-date="${today}">Review plan</button><button class="btn ghost" data-act="approve-now" data-date="${today}">Looks good</button></div></section>`;
  } else {
    h += nowCard(now, next);
    const rest = [next, ...later].filter(Boolean).filter((b) => b !== now);
    if (rest.length) {
      h += `<section class="card" style="padding:4px 14px"><div class="list">${rest.slice(0, 4).map((b, i) => `<button class="item tap ${b.type === "event" ? "event" : ""}" data-act="block" data-id="${b.id}">
        <span class="time">${i === 0 ? '<span class="eyebrow" style="display:block">Next</span>' : ""}${D.fmtRange(b.start, b.end)}</span><span class="grow"><span class="title">${esc(b.title)}</span>${b.type === "habit" ? ' <span class="tag brass">Habit</span>' : ""}</span>${icon("chev", "muted")}</button>`).join("")}
        ${rest.length > 4 ? `<button class="item tap link" data-act="go" data-tab="today">${rest.length - 4} more today ${icon("chev")}</button>` : ""}</div></section>`;
    } else if (!now) h += `<section class="card"><p class="ink2">Nothing else is scheduled today. ${openTasks().length ? "Ask what to do next, or plan tomorrow." : ""}</p><div class="row" style="margin-top:10px"><button class="btn soft sm" data-act="plan" data-date="${D.add(today, 1)}">Plan tomorrow</button></div></section>`;
  }

  h += `<button class="big-ask" data-act="now"><span>WHAT SHOULD I DO NOW?</span><small>${icon("compass")}</small></button>`;

  h += `<section class="stats"><div><span class="n">${imp.done}/${imp.total}</span><span class="l">Important today</span></div>
    <div><span class="n">${st}<span class="small muted"> day${st === 1 ? "" : "s"}</span></span><span class="l">Streak</span></div>
    <div><span class="n">${S.rewards.balance}</span><span class="l">Points</span></div></section>`;
  if (rn.ready.length) h += `<div class="notice"><div class="ico" style="background:var(--brass-soft);color:var(--brass)">${icon("medal")}</div><div class="grow"><b>${esc(rn.ready[0].title)}</b> is ready to claim.</div><button class="btn brass sm" data-act="claim" data-id="${rn.ready[0].id}">Claim</button></div>`;
  else if (rn.next) h += `<div class="section" style="gap:6px"><div class="row between small"><span class="ink2">Next reward: <b>${esc(rn.next.title)}</b></span><span class="mono muted">${rn.next.cost - S.rewards.balance} to go</span></div><div class="bar brass"><i style="width:${clamp(S.rewards.balance / rn.next.cost * 100, 2, 100)}%"></i></div></div>`;

  h += remindersHtml();

  h += `<section class="section"><div class="eyebrow">Quick actions</div><div class="quick">
    <button data-act="add-task">${icon("plus")}Add task</button>
    <button data-act="dump">${icon("dump")}Brain dump</button>
    <button data-act="add-goal">${icon("flag")}Add goal</button>
    <button data-act="go" data-tab="assistant">${icon("chat")}Ask assistant</button>
    <button data-act="reschedule-any">${icon("clock")}Reschedule</button>
    <button data-act="voice" data-target="dump">${icon("mic")}Voice</button></div></section>`;
  return h;
}
function nowCard(now, next) {
  if (!now) {
    const w = minutesUntilNextFixed();
    return `<section class="card" style="display:flex;flex-direction:column;gap:6px"><div class="eyebrow">Now</div>
      <div style="font-size:18px;font-weight:700">Free${next ? " until " + D.fmtTime(next.start) : w.event ? " until " + D.fmtTime(w.event.start) : ""}.</div>
      <p class="small muted">${next ? "Next: " + esc(next.title) + "." : "Nothing else is scheduled."} Tap “What should I do now?” to use this time well.</p></section>`;
  }
  if (now.type === "event") return `<section class="card"><div class="eyebrow">Now · until ${D.fmtTime(now.end)}</div><div style="font-size:19px;font-weight:700;margin-top:4px">${esc(now.title)}</div><p class="small muted" style="margin-top:4px">${next ? "After that: " + esc(next.title) + " at " + D.fmtTime(next.start) : ""}</p></section>`;
  const t = now.taskId && S.tasks.items[now.taskId];
  const g = t && taskGoal(t);
  return `<section class="now"><div class="row between"><span class="eyebrow">Now</span><span class="mono" style="font-size:13px">${D.fmtRange(now.start, now.end)}</span></div>
    <div class="t">${esc(now.title)}${now.session ? ` <span class="mono" style="font-size:13px;opacity:.8">· ${D.dur(now.session)} session</span>` : ""}</div>
    <div class="meta">${g ? "Moves “" + esc(g.title) + "” forward" : now.type === "habit" ? "Habit" : t ? D.dur(t.estMin) + " estimated" : ""}</div>
    <div class="row wrap"><button class="btn" data-act="focus" data-block="${now.id}">${icon("play")}Start</button><button class="btn ghost" data-act="block-done" data-id="${now.id}">${icon("check")}Done</button><button class="btn ghost" data-act="block" data-id="${now.id}" aria-label="More">${icon("more")}</button></div></section>`;
}
function briefingHtml() {
  const today = D.today(), hr = new Date().getHours(), seen = (S.profile.briefs || {})[today] || {};
  const day = dayPlan(today);
  if (hr >= 4 && hr < 12 && !seen.m && (openTasks().length || Object.keys(S.habits.items).length)) {
    const pr = day ? null : buildPlan(today);
    const nT = day ? day.blocks.filter((b) => b.type === "task").length : pr.blocks.filter((b) => b.type === "task").length;
    const load = day ? plannedLoad(today) : pr.used;
    const week = openTasks().filter((t) => t.due && D.diff(t.due, today) >= 0 && D.diff(t.due, today) <= 6).sort((a, b) => (a.due < b.due ? -1 : 1));
    const hab = Object.values(S.habits.items).filter((x) => habitDueOn(x, today));
    const risk = deadlineRisks()[0];
    const focus = day?.focus || pr?.focus;
    return `<section class="card section"><div class="row between"><span class="eyebrow">Morning briefing</span><button class="link small" data-act="brief-dismiss" data-k="m">Dismiss</button></div>
      ${focus ? `<div style="font-size:18px;font-weight:800">Focus: ${esc(focus)}</div>` : ""}
      <div class="small ink2">${nT} task${nT === 1 ? "" : "s"} · ${D.dur(load)} of ${D.dur(capacityFor(today))} free time${hab.length ? " · " + esc(hab.map((x) => x.title).join(", ")) : ""}</div>
      ${week.length ? `<div class="small"><span class="muted">Due this week:</span> ${week.slice(0, 3).map((t) => esc(t.title) + " <span class='muted'>(" + esc(D.label(t.due)) + ")</span>").join(" · ")}</div>` : ""}
      ${risk ? `<div class="small" style="color:var(--bad)">At risk: ${D.dur(risk.work)} of work due by ${esc(D.label(risk.date))}, about ${D.dur(risk.free)} free before then.</div>` : ""}
      ${day || risk ? `<div class="row wrap">${day ? `<button class="btn accent sm" data-act="brief-start">Start the first session</button>` : ""}${risk ? `<button class="btn soft sm" data-act="week">Plan the week</button>` : ""}</div>` : ""}</section>`;
  }
  if (hr >= 19 && !seen.e && day) {
    const tb = day.blocks.filter((b) => b.type === "task" && b.status !== "moved");
    const doneN = tb.filter((b) => b.status === "done" || S.tasks.items[b.taskId]?.status === "done").length;
    const left = tb.filter((b) => b.status === "planned" && S.tasks.items[b.taskId]?.status !== "done");
    const pts = sum(S.rewards.ledger.filter((l) => D.ymd(l.at) === today && l.pts > 0), (l) => l.pts);
    const tmr = D.add(today, 1);
    return `<section class="card section"><div class="row between"><span class="eyebrow">Evening wrap-up</span><button class="link small" data-act="brief-dismiss" data-k="e">Done for today</button></div>
      <div style="font-size:18px;font-weight:800">You finished ${doneN} of ${tb.length} planned task${tb.length === 1 ? "" : "s"}.</div>
      <div class="small ink2">${pts} points today · ${streak()} day streak</div>
      ${left.length ? `<div class="small"><span class="muted">Unfinished:</span> ${esc(left.map((b) => b.title).join(" · "))}</div><div class="row wrap"><button class="btn accent sm" data-act="wrap-move">Move ${left.length} to tomorrow</button><button class="btn soft sm" data-act="plan" data-date="${tmr}">Plan tomorrow</button></div>` : `<div class="row"><button class="btn accent sm" data-act="plan" data-date="${tmr}">${dayPlan(tmr) ? "Review tomorrow" : "Plan tomorrow"}</button></div>`}</section>`;
  }
  return "";
}
function remindersHtml() {
  const today = D.today(), out = [];
  const risks = deadlineRisks();
  if (risks.length) out.push(`<div class="notice warn"><div class="ico" style="color:var(--bad)">${icon("bell")}</div><div class="grow"><b>Deadline at risk: ${esc(D.label(risks[0].date))}</b><div class="small muted">${D.dur(risks[0].work)} of work due, about ${D.dur(risks[0].free)} of free time before then.</div></div><button class="btn soft sm" data-act="week">Plan week</button></div>`);
  const co = carryOver();
  if (co.length) out.push(`<div class="notice warn"><div class="ico">${icon("refresh")}</div><div class="grow"><b>${co.length} unfinished from earlier.</b><div class="small muted">${esc(co.slice(0, 3).map((t) => t.title).join(" · "))}</div></div><button class="btn soft sm" data-act="carry">Re-plan</button></div>`);
  const missed = missedBlocksToday();
  if (missed.length) out.push(`<div class="notice warn"><div class="ico">${icon("clock")}</div><div class="grow"><b>${missed.length} planned session${missed.length > 1 ? "s" : ""} passed without a check-in.</b><div class="small muted">${esc(missed.map((b) => b.title).join(" · "))}</div></div><button class="btn soft sm" data-act="missed">Sort out</button></div>`);
  const dueToday = openTasks().filter((t) => t.due === today && !(dayPlan(today)?.blocks || []).some((b) => b.taskId === t.id && b.status === "planned"));
  if (dueToday.length) out.push(`<div class="notice"><div class="ico">${icon("bell")}</div><div class="grow"><b>Due today, not scheduled</b><div class="small muted">${esc(dueToday.map((t) => t.title).join(" · "))}</div></div><button class="btn soft sm" data-act="task" data-id="${dueToday[0].id}">Open</button></div>`);
  const overdue = openTasks().filter((t) => t.due && D.diff(t.due, today) < 0);
  if (overdue.length) out.push(`<div class="notice"><div class="ico" style="color:var(--bad)">${icon("bell")}</div><div class="grow"><b>${overdue.length} overdue</b><div class="small muted">${esc(overdue.slice(0, 3).map((t) => t.title).join(" · "))}</div></div><button class="btn soft sm" data-act="reschedule-any">Review</button></div>`);
  const dow = D.dow(today), wk = reviewWeek();
  if ((dow === 0 || dow === 1 || dow === 5 || dow === 6) && !S.reviews.items[wk] && S.activity.events.length > 5) out.push(`<div class="notice"><div class="ico">${icon("progress")}</div><div class="grow"><b>Weekly review is ready.</b><div class="small muted">Reset next week in two minutes.</div></div><button class="btn soft sm" data-act="review" data-week="${wk}">Open</button></div>`);
  return out.length ? `<section class="section"><div class="eyebrow">Needs attention</div>${out.join("")}</section>` : "";
}
function reviewWeek() { const t = D.today(); return D.dow(t) === 1 ? D.add(D.weekStart(t), -7) : D.weekStart(t); }

/* ================= TODAY ================= */
function viewToday() {
  const today = D.today(); const date = UI.day || today; const day = dayPlan(date);
  let h = `<div class="days" role="tablist">${Array.from({ length: 8 }, (_, i) => D.add(today, i - 1)).map((d) => `<button class="day ${d === date ? "on" : ""}" data-act="day" data-date="${d}"><span>${d === today ? "Today" : DOW[D.dow(d)].toUpperCase()}</span><b>${D.parse(d).getDate()}</b></button>`).join("")}</div>`;
  const cap = capacityFor(date), load = plannedLoad(date);
  h += `<section class="section"><div class="row between"><h2>${esc(D.label(date) === "Today" ? "Today" : D.long(date))}</h2>
    <div class="row">${date >= today ? `<button class="btn soft sm" data-act="plan" data-date="${date}">${icon("refresh")}${day ? "Re-plan" : "Plan"}</button>` : ""}<button class="btn soft sm" data-act="add-task" data-date="${date}" aria-label="Add task">${icon("plus")}</button></div></div>
    <div class="row between small"><span class="ink2">${D.dur(load)} planned of ${D.dur(cap)} free time</span>${load > cap ? '<span class="tag high">Over capacity</span>' : ""}</div>
    <div class="bar ${load > cap ? "over" : ""}"><i style="width:${clamp(load / Math.max(1, cap) * 100, 1, 100)}%"></i></div></section>`;
  if (day) {
    const n = D.nowMin();
    h += `<section class="timeline">${day.blocks.filter((b) => b.status !== "moved").map((b) => {
      const t = b.taskId && S.tasks.items[b.taskId];
      const done = b.status === "done" || (t && t.status === "done" && b.status !== "partial" && b.status !== "skipped") || (b.type === "habit" && S.habits.items[b.habitId]?.log?.[date]);
      const live = date === today && b.start <= n && n < b.end && !done;
      const skipped = b.status === "skipped";
      return `<div class="tl ${b.type} ${done ? "done" : ""} ${live ? "live" : ""}"><div class="when">${D.toHHMM(b.start)}</div><div class="blk"><div class="inner">
        ${b.type === "event" ? `<span class="grow"><span class="title">${esc(b.title)}</span><div class="small muted mono">${D.fmtRange(b.start, b.end)}</div></span>` :
          `<button class="check ${b.type === "habit" ? "" : "round"} ${done ? "on" : ""}" data-act="block-toggle" data-id="${b.id}" data-date="${date}" aria-label="Toggle done">${done ? icon("check") : ""}</button>
          <button class="tap grow" data-act="block" data-id="${b.id}" data-date="${date}"><span class="title">${esc(b.title)}</span>
          <div class="row wrap" style="gap:6px;margin-top:4px"><span class="small muted mono">${D.fmtRange(b.start, b.end)}</span>${b.type === "habit" ? '<span class="tag brass">Habit</span>' : ""}${b.starter ? `<span class="tag warn">Starter · 25m</span>` : b.session ? `<span class="tag">Session</span>` : ""}${skipped ? '<span class="tag warn">Skipped</span>' : ""}${b.status === "partial" ? '<span class="tag warn">Partly done</span>' : ""}${t && t.goalId && taskGoal(t) ? `<span class="tag goal">${esc(taskGoal(t).title)}</span>` : ""}</div></button>`}
      </div></div></div>`;
    }).join("") || '<p class="muted">No blocks.</p>'}</section>`;
  } else if (date >= today) {
    const pr = buildPlan(date);
    h += `<section class="card section"><div class="eyebrow">Proposed · not approved</div>
      <p>${planMessage(pr)}</p>
      <div class="list">${pr.blocks.map((b) => `<div class="item ${b.type === "event" ? "event" : ""}"><span class="time">${D.fmtRange(b.start, b.end)}</span><span class="grow title">${esc(b.title)}</span></div>`).join("") || '<p class="muted">Nothing to schedule.</p>'}</div>
      <div class="row"><button class="btn accent grow" data-act="approve-now" data-date="${date}">Approve plan</button><button class="btn ghost" data-act="plan" data-date="${date}">Adjust</button></div></section>`;
  } else h += `<p class="muted">No plan was recorded for this day.</p>`;

  const habits = Object.values(S.habits.items);
  if (habits.length) h += `<section class="section"><div class="eyebrow">Habits this week</div><div class="card" style="padding:4px 14px"><div class="list">${habits.map((hb) => {
    const on = !!hb.log?.[date], cnt = habitWeekCount(hb, date);
    return `<div class="item"><button class="check ${on ? "on" : ""}" data-act="habit" data-id="${hb.id}" data-date="${date}" aria-label="Toggle ${esc(hb.title)}">${on ? icon("check") : ""}</button><span class="grow"><span class="title">${esc(hb.title)}</span><div class="small muted">${cnt}/${hb.perWeek} this week · ${hb.durMin}m${habitDueOn(hb, date) ? " · suggested today" : ""}</div></span></div>`;
  }).join("")}</div></div></section>`;

  const planned = new Set((day?.blocks || []).filter((b) => b.status !== "moved").map((b) => b.taskId));
  const pinned = openTasks().filter((t) => (t.planDate === date || (!t.planDate && t.due === date)) && !planned.has(t.id));
  if (pinned.length) h += `<section class="section"><div class="eyebrow">Meant for this day, not scheduled</div><div class="card" style="padding:4px 14px"><div class="list">${pinned.map((t) => taskRow(t)).join("")}</div></div></section>`;
  const inbox = openTasks().filter((t) => !t.planDate && !t.due && !planned.has(t.id)).sort((a, b) => scoreTask(b, date) - scoreTask(a, date));
  if (inbox.length) h += `<section class="section"><div class="row between"><div class="eyebrow">Open, no date (${inbox.length})</div><button class="link small" data-act="all-tasks">See all</button></div><div class="card" style="padding:4px 14px"><div class="list">${inbox.slice(0, 5).map((t) => taskRow(t)).join("")}</div></div></section>`;
  return h;
}
function planMessage(pr) {
  const nT = pr.blocks.filter((b) => b.type === "task").length;
  const dayword = pr.date === D.today() ? "today" : pr.date === D.add(D.today(), 1) ? "tomorrow" : "on " + D.label(pr.date);
  if (pr.windowMin < 30) return "There isn't meaningful time left " + dayword + ".";
  if (pr.overloaded) {
    const light = [1, 2, 3, 4, 5, 6].map((i) => D.add(pr.date, i)).find((d) => plannedLoad(d) < capacityFor(d) * 0.6);
    return `You have <b>${D.dur(pr.budget)}</b> available ${dayword} but <b>${D.dur(pr.requested)}</b> of planned work. I've prioritised the ${nT} task${nT === 1 ? "" : "s"} most connected to your goals and deadlines.${pr.overflow.length ? " The rest can move to " + (light ? D.label(light) : "later this week") + "." : ""}${paceNote(pr)}`;
  }
  return `${D.dur(pr.used)} planned of ${D.dur(pr.budget)} available ${dayword}.${pr.focus ? " Focus: <b>" + esc(pr.focus) + "</b>." : ""}${paceNote(pr)}`;
}
function paceNote(pr) {
  const bits = [];
  if (pr.pace && pr.pace !== 1) bits.push(`times adjusted to your real pace (about ${pr.pace.toFixed(1)}× your estimates)`);
  if (pr.peakUsed && pr.peakUsed !== S.profile.peak) bits.push(`demanding work placed in the ${pr.peakUsed}, when you actually finish the most`);
  if (pr.blocks.some((b) => b.starter)) bits.push("tasks you've postponed 3+ times start with a 25-minute first session");
  return bits.length ? ` <span class="small muted">I've ${bits.join("; ")}.</span>` : "";
}

/* ================= GOALS ================= */
function viewGoals() {
  if (UI.goalId && S.goals.goals[UI.goalId]) return viewGoal(S.goals.goals[UI.goalId]);
  const goals = Object.values(S.goals.goals).filter((g) => g.status !== "archived").sort((a, b) => a.createdAt - b.createdAt);
  let h = `<section class="section"><div class="eyebrow">Vision</div>
    <button class="tap card" data-act="vision" style="font-size:16px;font-weight:600;${S.goals.vision ? "" : "color:var(--muted)"}">${esc(S.goals.vision || "What are you building your life toward? Tap to write one line.")}</button></section>`;
  h += `<section class="section"><div class="row between"><h2>Goals</h2><button class="btn soft sm" data-act="add-goal">${icon("plus")}Goal</button></div>`;
  if (!goals.length) h += `<div class="card empty"><p>No goals yet. Tell me something big you want — “launch my business in six months” — and I'll break it into milestones, projects and this week's actions.</p><button class="btn accent" data-act="add-goal">Add a goal</button></div>`;
  goals.forEach((g) => {
    const pr = goalProgress(g.id), cm = currentMilestone(g.id), na = nextActionFor(g.id);
    h += `<div class="card goal"><button class="tap" data-act="goal" data-id="${g.id}"><div class="row between"><span class="gt">${esc(g.title)}</span><span class="mono small muted">${Math.round(pr * 100)}%</span></div>
      ${g.targetDate ? `<div class="small muted">Target ${esc(D.long(g.targetDate))} · ${Math.max(0, Math.round(D.diff(g.targetDate, D.today()) / 7))} weeks left</div>` : ""}</button>
      <div class="bar"><i style="width:${clamp(pr * 100, 2, 100)}%"></i></div>
      ${cm ? `<div class="small"><span class="muted">Milestone:</span> <b>${esc(cm.title)}</b> <span class="muted">· by ${esc(D.label(cm.due))}</span></div>` : ""}
      ${na ? `<div class="notice" style="padding:10px 12px"><div class="grow"><div class="eyebrow">Next action</div><div style="font-weight:700">${esc(na.title)}</div><div class="small muted">${D.dur(na.estMin)}</div></div><button class="btn accent sm" data-act="focus-task" data-id="${na.id}">${icon("play")}Start</button></div>` : !goalMilestones(g.id).length ? `<button class="btn soft sm" data-act="decompose" data-id="${g.id}">Break it down</button>` : ""}
    </div>`;
  });
  h += `</section>`;
  const loose = Object.values(S.goals.projects).filter((p) => !p.goalId && p.status !== "archived");
  if (loose.length) h += `<section class="section"><div class="eyebrow">Projects</div>${loose.map((p) => `<div class="proj"><b>${esc(p.title)}</b>${projectTasks(p.id).filter((t) => t.status !== "done").slice(0, 4).map((t) => taskRow(t, { showCrumb: false })).join("") || '<span class="small muted">No open tasks.</span>'}</div>`).join("")}</section>`;
  const habits = Object.values(S.habits.items);
  h += `<section class="section"><div class="row between"><div class="eyebrow">Habits</div><button class="link small" data-act="add-habit">Add habit</button></div>
    ${habits.length ? `<div class="card" style="padding:4px 14px"><div class="list">${habits.map((hb) => `<button class="item tap" data-act="habit-edit" data-id="${hb.id}"><span class="grow"><span class="title">${esc(hb.title)}</span><div class="small muted">${habitWeekCount(hb)}/${hb.perWeek} this week · ${hb.durMin}m · ${esc(hb.preferredTime)}</div></span>${icon("chev", "muted")}</button>`).join("")}</div></div>` : `<p class="small muted">Exercise, reading, prayer, study, journaling, sleep, water — flexible weekly targets that never stack up when you miss a day.</p>`}</section>`;
  h += `<section class="section"><button class="btn ghost block" data-act="all-tasks">All open tasks (${openTasks().length})</button></section>`;
  return h;
}
function viewGoal(g) {
  const pr = goalProgress(g.id), ms = goalMilestones(g.id), cm = currentMilestone(g.id), na = nextActionFor(g.id);
  const obj = thisWeekObjectives(g.id);
  let h = `<button class="row link" data-act="goal-back" style="gap:4px">${icon("back")}Goals</button>
    <section class="section"><div class="eyebrow">Goal${g.targetDate ? " · by " + esc(D.long(g.targetDate)) : ""}</div><h1 style="font-size:26px">${esc(g.title)}</h1>
    ${g.why ? `<p class="ink2"><b>Why it matters:</b> ${esc(g.why)}</p>` : `<button class="link small tap" data-act="goal-why" data-id="${g.id}">Add why it matters</button>`}
    <div class="row between small"><span class="muted">${ms.filter((m) => m.status === "done").length}/${ms.length} milestones</span><span class="mono">${Math.round(pr * 100)}%</span></div><div class="bar"><i style="width:${clamp(pr * 100, 2, 100)}%"></i></div></section>`;
  if (na) h += `<section class="now"><div class="eyebrow">Next action</div><div class="t">${esc(na.title)}</div><div class="meta">${D.dur(na.estMin)}${na.projectId && S.goals.projects[na.projectId] ? " · " + esc(S.goals.projects[na.projectId].title) : ""}</div><div class="row"><button class="btn" data-act="focus-task" data-id="${na.id}">${icon("play")}Start now</button><button class="btn ghost" data-act="task" data-id="${na.id}">Details</button></div></section>`;
  if (obj.length) h += `<section class="section"><div class="eyebrow">This week's objectives</div><div class="card" style="padding:4px 14px"><div class="list">${obj.map((o) => `<div class="item ${o.done ? "done" : ""}"><button class="check ${o.done ? "on" : ""}" data-act="objective" data-id="${o.id}" aria-label="Toggle objective">${o.done ? icon("check") : ""}</button><span class="grow title">${esc(o.title)}</span></div>`).join("")}</div></div></section>`;
  if (!ms.length) h += `<section class="card empty"><p>This goal isn't broken down yet.</p><button class="btn accent" data-act="decompose" data-id="${g.id}">Break it down</button></section>`;
  else h += `<section class="section"><div class="eyebrow">Milestones → projects → tasks</div><div class="tree">${ms.map((m) => {
    const projects = milestoneProjects(m.id);
    return `<div class="ms ${m.status === "done" ? "done" : m === cm ? "cur" : ""}"><div class="row between"><div><div style="font-weight:800">${esc(m.title)}</div><div class="small muted">by ${esc(D.long(m.due))}${m.status === "done" ? " · done" : m === cm ? " · current" : ""}</div></div>
      ${m.status !== "done" ? `<button class="btn soft sm" data-act="ms-done" data-id="${m.id}">Complete</button>` : ""}</div>
      ${projects.map((p) => { const ts = projectTasks(p.id); return `<div class="proj"><div class="row between"><b>${esc(p.title)}</b><button class="link small" data-act="add-task" data-project="${p.id}">+ Task</button></div>${ts.length ? ts.map((t) => taskRow(t, { showCrumb: false })).join("") : '<span class="small muted">No tasks yet — they arrive when this milestone is current.</span>'}</div>`; }).join("")}</div>`;
  }).join("")}</div></section>`;
  const orphan = goalTasks(g.id).filter((t) => !t.projectId && !t.parentId);
  if (orphan.length) h += `<section class="section"><div class="eyebrow">Other tasks</div><div class="card" style="padding:4px 14px">${orphan.map((t) => taskRow(t, { showCrumb: false })).join("")}</div></section>`;
  h += `<section class="row wrap"><button class="btn soft sm" data-act="plan-week" data-id="${g.id}">${icon("refresh")}Plan next steps</button><button class="btn ghost sm" data-act="goal-archive" data-id="${g.id}">Archive goal</button></section>`;
  return h;
}

/* ================= ASSISTANT ================= */
function viewAssistant() {
  const turns = S.chat.turns;
  let h = `<section class="row between"><h2>Assistant</h2><div class="row"><button class="btn soft sm" data-act="docs">${icon("file")}Documents</button></div></section>`;
  if (!AI.on && AI.ready) h += `<div class="notice warn"><div class="ico">${icon("help")}</div><div class="small">The assistant's AI isn't available in this view, so I'll handle simple requests (“remind me to…”, “what should I do now”, “plan tomorrow”) myself. Open the app on claude.ai for the full assistant.</div></div>`;
  if (UI.dumpMode) h += `<div class="dumpmode"><b>Brain dump mode.</b> Type everything — tasks, worries, ideas, deadlines — in any order. I'll organise it and show you before saving anything. <button class="link" data-act="dump-off">Cancel</button></div>`;
  h += `<section class="chat" id="chat">`;
  if (!turns.length) h += `<div class="msg ai"><div class="bubble">I'm here to remember things for you and work out what to do next. Tell me what's on your mind — as messy as it is.</div></div>`;
  turns.slice(-60).forEach((t) => (h += turnHtml(t)));
  if (!turns.length || turns.length < 3) h += `<div class="chips" style="margin-top:4px">${["I have a lot to do. I don't know where to start.", "What should I work on right now?", "Help me plan tomorrow", "I have two hours free. What can I realistically accomplish?", "I want to launch my business in six months"].map((s) => `<button class="chip outline" data-act="suggest" data-text="${esc(s)}">${esc(s)}</button>`).join("")}</div>`;
  h += `<div id="chat-end" style="height:90px"></div></section>`;
  return h;
}
function turnHtml(t) {
  if (t.role === "user") return `<div class="msg me"><div class="bubble">${esc(t.text)}</div></div>`;
  let h = `<div class="msg ai" id="turn-${t.id}">`;
  if (t.pending && !t.text) h += `<div class="bubble" id="bub-${t.id}"><span class="dots"><i></i><i></i><i></i></span></div>`;
  else if (t.text) h += `<div class="bubble" id="bub-${t.id}">${esc(t.text)}</div>`;
  if (t.error) h += `<div class="notice warn small"><div class="grow">${esc(t.error)}</div>${t.retry ? `<button class="btn soft sm" data-act="retry" data-id="${t.id}">Retry</button>` : ""}</div>`;
  (t.receipts || []).forEach((r, i) => (h += `<div class="receipt">${icon("check")}<span>${esc(r.text)}</span>${r.undo && !r.undone ? `<button data-act="undo" data-turn="${t.id}" data-i="${i}">Undo</button>` : r.undone ? '<span class="muted">Undone</span>' : ""}</div>`));
  (t.cards || []).forEach((c, i) => (h += cardHtml(c, t.id, i)));
  if (t.sources && t.sources.length) h += `<div class="src">Sources: ${t.sources.map((s) => esc(s)).join(" · ")}</div>`;
  return h + `</div>`;
}
function cardHtml(c, turnId, i) {
  const ref = `data-turn="${turnId}" data-i="${i}"`;
  if (c.resolved) return `<div class="receipt">${icon("check")}<span>${esc(c.resolved)}</span></div>`;
  switch (c.type) {
    case "now": { const r = recommendNow(); return `<div class="card section">${nowRecommendationHtml(r, ref)}</div>`; }
    case "plan": { const pr = buildPlan(c.date); return `<div class="card section"><div class="eyebrow">${esc(D.label(c.date))}</div><p>${planMessage(pr)}</p><div class="row"><button class="btn accent sm" data-act="plan" data-date="${c.date}">Review plan</button></div></div>`; }
    case "fit": { const f = fitTime(c.minutes); return `<div class="card section"><div class="eyebrow">In ${D.dur(c.minutes)}</div>${f.picks.length ? `<p class="small ink2">Realistically: ${f.picks.length} task${f.picks.length > 1 ? "s" : ""}, about ${D.dur(sum(f.picks, (t) => t.estMin))}.</p><div class="list">${f.picks.map((t) => taskRow(t)).join("")}</div><div class="row"><button class="btn accent sm" data-act="focus-task" data-id="${f.picks[0].id}">${icon("play")}Start “${esc(f.picks[0].title)}”</button><button class="btn soft sm" data-act="fit-add" ${ref}>Add all to today</button></div>` : `<p class="small">Nothing open fits in ${D.dur(c.minutes)}. Break a bigger task down or use the time for a habit.</p>`}</div>`; }
    case "reschedule": { const t = S.tasks.items[c.taskId]; if (!t) return ""; const ro = rescheduleOptions(t); return `<div class="card section"><div class="eyebrow">Move “${esc(t.title)}”</div><p class="small ink2">${esc(rescheduleText(t, ro))}</p><div class="chips">${ro.options.map((o) => `<button class="chip ${o.recommended ? "on" : ""}" data-act="move-to" data-task="${t.id}" data-date="${o.date}" data-start="${o.start ?? ""}" ${ref}>${esc(o.label)}</button>`).join("")}<button class="chip outline" data-act="reschedule" data-id="${t.id}">Other day</button></div></div>`; }
    case "move": { const t = S.tasks.items[c.taskId]; if (!t) return ""; return `<div class="card section"><p>Move <b>${esc(t.title)}</b> to ${esc(D.label(c.date))}${c.time ? " at " + D.fmtTime(c.time) : ""}?</p><div class="row"><button class="btn accent sm" data-act="move-to" data-task="${t.id}" data-date="${c.date}" data-start="${c.time ? D.toMin(c.time) : ""}" ${ref}>Move it</button><button class="btn ghost sm" data-act="card-dismiss" ${ref}>Keep it</button></div></div>`; }
    case "drop": { const t = S.tasks.items[c.taskId]; if (!t) return ""; return `<div class="card section"><p>Drop <b>${esc(t.title)}</b>? It leaves your plans but stays in history.</p><div class="row"><button class="btn sm" data-act="drop" data-id="${t.id}" ${ref}>Drop it</button><button class="btn ghost sm" data-act="card-dismiss" ${ref}>Keep it</button></div></div>`; }
    case "stuck": return `<div class="card section"><p>What's blocking you${c.taskId && S.tasks.items[c.taskId] ? " on <b>" + esc(S.tasks.items[c.taskId].title) + "</b>" : ""}?</p><div class="row"><button class="btn accent sm" data-act="stuck" data-id="${c.taskId || ""}">Work through it</button></div></div>`;
    case "goal": return `<div class="card section"><div class="eyebrow">New goal</div><p><b>${esc(c.title)}</b></p><div class="row wrap"><button class="btn accent sm" data-act="card-decompose" ${ref}>Break it down</button><button class="btn ghost sm" data-act="card-goal-save" ${ref}>Just save the goal</button></div></div>`;
    case "dump": return `<div class="receipt">${icon("dump")}<span>Brain dump mode is on. Type everything below.</span></div>`;
    case "carry": { const co = carryOver(); return `<div class="card section">${co.length ? `<p class="small ink2">${co.length} unfinished: ${esc(co.map((t) => t.title).join(" · "))}</p><div class="row"><button class="btn accent sm" data-act="carry">Re-plan them</button></div>` : `<p class="small">Nothing is left over from earlier days.</p>`}</div>`; }
    case "review": return `<div class="row"><button class="btn accent sm" data-act="review" data-week="${reviewWeek()}">Open weekly review</button></div>`;
    case "note": return `<div class="notice small">${esc(c.text)}</div>`;
    case "week": { const w = planWeek(); return `<div class="card section"><div class="eyebrow">This week</div><p class="small ink2">${w.assign.length ? `I can spread ${w.assign.length} task${w.assign.length > 1 ? "s" : ""} across the next 7 days, before their deadlines and within your free time.` : "Nothing needs spreading out — the week already fits."}${w.assign.some((a) => a.tight) ? " Some days will be tight." : ""}</p>${w.assign.length ? `<div class="row"><button class="btn accent sm" data-act="week">Review week plan</button></div>` : ""}</div>`; }
    case "reflow": { const r = reflowToday(); return r && r.moves.length + r.overflow.length ? `<div class="card section"><p class="small ink2">I can shift the rest of today: ${r.moves.length} session${r.moves.length === 1 ? "" : "s"} move later${r.overflow.length ? ", " + r.overflow.length + " go to tomorrow" : ""}.</p><div class="row"><button class="btn accent sm" data-act="reflow">Review</button></div></div>` : `<div class="notice small">Nothing left on today's plan to shift.</div>`; }
  }
  return "";
}
function nowRecommendationHtml(r, ref = "") {
  const w = r.event ? `You have ${D.dur(r.window)} before ${esc(r.event.title)}.` : r.window < 600 ? `You have ${D.dur(r.window)} of usable time left today.` : "";
  if (r.kind === "task") return `<div class="small ink2">${w}</div><div class="eyebrow">Your highest-impact action</div><div style="font-size:19px;font-weight:800">${esc(r.task.title)}</div><div class="small muted">${esc(r.reason)}${r.task.estMin > r.window ? " Start it now; it won't finish before the break." : ""}</div>
    <div class="row wrap"><button class="btn accent" data-act="focus-task" data-id="${r.task.id}" data-min="${Math.min(r.task.estMin, r.window)}">${icon("play")}Start</button><button class="btn soft" data-act="reschedule" data-id="${r.task.id}">Reschedule</button><button class="btn soft" data-act="now-else">Something else</button><button class="btn ghost" data-act="stuck" data-id="${r.task.id}">I'm stuck</button></div>`;
  if (r.kind === "habit") return `<div class="small ink2">${w}</div><div class="eyebrow">Recommended</div><div style="font-size:19px;font-weight:800">${esc(r.title || S.habits.items[r.habitId]?.title || r.block?.title)}</div><div class="small muted">${esc(r.reason)}</div><div class="row"><button class="btn accent" data-act="focus-habit" data-id="${r.habitId || r.block?.habitId}">${icon("play")}Start</button><button class="btn soft" data-act="now-else">Something else</button></div>`;
  if (r.kind === "event") return `<div style="font-weight:700">${esc(r.reason)}</div>`;
  if (r.kind === "break") return `<div style="font-weight:700">${esc(r.reason)}</div>`;
  return `<div>${esc(r.reason)}</div><div class="row"><button class="btn accent sm" data-act="dump">Brain dump</button></div>`;
}

/* ================= PROGRESS ================= */
function viewProgress() {
  const st = weekStats(), rn = rewardNext(), sk = streak();
  const pct = st.rate == null ? "—" : Math.round(st.rate * 100) + "%";
  let h = `<section class="section"><h2>This week</h2><div class="small muted">${esc(D.label(st.ws))} – ${esc(D.label(st.we))}</div></section>
    <section class="stats"><div><span class="n">${pct}</span><span class="l">Planned work done</span></div><div><span class="n">${st.completed.length}</span><span class="l">Tasks completed</span></div><div><span class="n">${(st.productiveMin / 60).toFixed(1)}h</span><span class="l">Focused work</span></div>
    <div><span class="n">${sk}</span><span class="l">Day streak</span></div><div><span class="n">${st.rescheduled}</span><span class="l">Rescheduled</span></div><div><span class="n" style="${st.overdue.length ? "color:var(--bad)" : ""}">${st.overdue.length}</span><span class="l">Overdue</span></div></section>`;
  // 7-day chart
  let max = Math.max(4, ...st.daily.map((d) => Math.max(d.completed, d.planned))); max += max % 2;
  const W = 320, H = 120, bw = 26, gap = (W - 20 - bw * 7) / 6;
  h += `<section class="card"><div class="row between"><div class="eyebrow">Completed vs planned</div><div class="row small muted" style="gap:10px"><span><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--accent)"></i> done</span><span><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--surface-2);border:1px solid var(--line)"></i> planned</span></div></div>
    <svg class="chart" viewBox="0 0 ${W} ${H + 22}" role="img" aria-label="Tasks completed per day this week">
    ${[0, max / 2, max].map((v) => { const y = 6 + H - (v / max) * H; return `<line x1="18" x2="${W}" y1="${y}" y2="${y}" stroke="var(--line)" stroke-width="1"/><text x="12" y="${y + 3}" text-anchor="end">${v}</text>`; }).join("")}
    ${st.daily.map((d, i) => { const x = 20 + i * (bw + gap); const hp = (d.planned / max) * H, hc = (d.completed / max) * H; return `<rect x="${x}" y="${6 + H - hp}" width="${bw}" height="${hp}" rx="5" fill="var(--surface-2)" stroke="var(--line)"/><rect x="${x + 4}" y="${6 + H - hc}" width="${bw - 8}" height="${hc}" rx="4" fill="var(--accent)"/><text x="${x + bw / 2}" y="${H + 20}" text-anchor="middle" ${d.d === D.today() ? 'style="fill:var(--ink);font-weight:600"' : ""}>${DOW[D.dow(d.d)].slice(0, 2)}</text>`; }).join("")}
    </svg></section>`;
  // rewards
  h += `<section class="section"><div class="row between"><h2>Rewards</h2><button class="link small" data-act="rewards-edit">Edit</button></div>
    <div class="card section"><div class="row between"><div><div class="mono" style="font-size:28px;font-weight:600">${S.rewards.balance}</div><div class="small muted">points to spend · ${S.rewards.lifetime} earned in total</div></div><div class="seal" style="width:52px;height:52px;margin:0">${icon("medal")}</div></div>
    ${S.rewards.rules.length ? [...S.rewards.rules].sort((a, b) => a.cost - b.cost).map((r) => `<div class="section" style="gap:6px"><div class="row between small"><b>${esc(r.title)}</b><span class="mono muted">${r.cost} pts${r.claimed ? " · claimed ×" + r.claimed : ""}</span></div><div class="row"><div class="bar brass grow"><i style="width:${clamp(S.rewards.balance / r.cost * 100, 2, 100)}%"></i></div>${S.rewards.balance >= r.cost ? `<button class="btn brass sm" data-act="claim" data-id="${r.id}">Claim</button>` : ""}</div></div>`).join("") : `<p class="small muted">No rewards yet. Add one — e.g. “500 points = Movie night”.</p>`}
    <div class="small muted">Task ${S.profile.pointsRules.task} · habit ${S.profile.pointsRules.habit} · full day ${S.profile.pointsRules.daily} · week's objectives ${S.profile.pointsRules.weekly} · milestone ${S.profile.pointsRules.milestone}. High-priority tasks count double.</div></div></section>`;
  // goals
  if (st.goals.length) h += `<section class="section"><div class="eyebrow">Goal progress</div><div class="card section">${st.goals.map((x) => `<div class="section" style="gap:6px"><div class="row between small"><b>${esc(x.g.title)}</b><span class="mono muted">${Math.round(x.progress * 100)}% · ${x.doneThisWeek} this week</span></div><div class="bar"><i style="width:${clamp(x.progress * 100, 2, 100)}%"></i></div></div>`).join("")}</div></section>`;
  // insight
  const bp = bestDaypart();
  const insights = [];
  const ps = paceStats();
  if (ps) insights.push(`Tasks take you about <b>${ps.factor.toFixed(1)}×</b> your estimates (from ${ps.n} focus sessions). ${Math.abs(ps.factor - 1) >= 0.1 ? "Plans now use your real pace." : "Your estimates are accurate."}`);
  if (st.postponed.length) insights.push(`You keep postponing <b>${esc(st.postponed[0].t.title)}</b> (${st.postponed[0].n}× this week).`);
  if (bp) insights.push(`You finish the most in the <b>${bp}</b>${bp !== S.profile.peak ? ` — you said you're most productive in the ${esc(S.profile.peak)}.` : "."}`);
  st.habits.forEach((x) => { if (x.done < x.target && D.dow(D.today()) === 0) insights.push(`${esc(x.h.title)}: ${x.done}/${x.target} this week.`); });
  if (insights.length) h += `<section class="section"><div class="eyebrow">Patterns</div><div class="card section small">${insights.map((i) => `<p>${i}</p>`).join("")}</div></section>`;
  if (st.habits.length) h += `<section class="section"><div class="eyebrow">Habits</div><div class="card" style="padding:4px 14px">${st.habits.map((x) => `<div class="item"><span class="grow title">${esc(x.h.title)}</span><span class="mono">${x.done}/${x.target}</span></div>`).join("")}</div></section>`;
  // review
  const wk = reviewWeek(), rv = S.reviews.items[wk];
  h += `<section class="section"><div class="row between"><h2>Weekly review</h2></div>
    <div class="card section"><p class="small ink2">${rv ? "Written " + esc(new Date(rv.at).toLocaleDateString()) + "." : "What you completed, what moved forward, what you keep postponing, and next week's priorities."}</p><div class="row"><button class="btn accent sm" data-act="review" data-week="${wk}">${rv ? "Open review" : "Write this week's review"}</button></div></div>
    ${Object.keys(S.reviews.items).filter((k) => k !== wk).sort().reverse().slice(0, 4).map((k) => `<button class="item tap" data-act="review" data-week="${k}"><span class="grow">Week of ${esc(D.long(k))}</span>${icon("chev", "muted")}</button>`).join("")}</section>`;
  return h;
}
