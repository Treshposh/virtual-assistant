/* ============================================================
   05 FLOWS — sheets, chat, brain dump, decomposition, planning,
   rescheduling, stuck, focus, check-ins, settings, onboarding
   ============================================================ */

/* ---------------- Sheets ---------------- */
function openSheet(body, { title = "", id = "" } = {}) {
  const slot = $("#sheet-slot");
  slot.innerHTML = `<div class="scrim" data-scrim="1"><div class="sheet" role="dialog" aria-modal="true" ${id ? `data-sheet="${id}"` : ""}>
    <div class="grab"></div>${title ? `<div class="sh"><h2>${esc(title)}</h2><button class="icon-btn" style="width:40px;height:40px" data-act="close" aria-label="Close">${icon("x")}</button></div>` : ""}
    <div class="sheet-body" style="display:contents">${body}</div></div></div>`;
  UI.sheetOpen = id || true;
  setTimeout(() => { const f = slot.querySelector("[autofocus]"); f && f.focus(); }, 60);
}
function setSheet(body) { const b = $("#sheet-slot .sheet-body"); if (b) b.innerHTML = body; }
function closeSheet() { $("#sheet-slot").innerHTML = ""; UI.sheetOpen = null; UI.render(); }
const loadingBody = (msg, lines = 4) => `<div class="sb"><p class="ink2">${esc(msg)}</p>${Array.from({ length: lines }, (_, i) => `<div class="skeleton" style="width:${90 - i * 12}%"></div>`).join("")}<p class="small muted">This usually takes 10–40 seconds.</p></div>`;

/* ---------------- Chat ---------------- */
const OVERWHELM = /(don'?t|do not) know where to (start|begin)|overwhelm|brain ?dump|so much (on my mind|to do)|a lot (to do|on my (mind|plate))|everything on my mind/i;
function aiTurn(o) { const t = { id: uid("a"), role: "ai", at: Date.now(), text: "", ...o }; S.chat.turns.push(t); return t; }
function trimChat() { if (S.chat.turns.length > 140) S.chat.turns = S.chat.turns.slice(-110); Store.save("chat"); }
function scrollChat() { const e = $("#chat-end"); e && e.scrollIntoView({ block: "end", behavior: "smooth" }); }

async function sendChat(text, { retry = false } = {}) {
  if (!retry) S.chat.turns.push({ id: uid("u"), role: "user", text, at: Date.now() });
  if (UI.tab !== "assistant") UI.tab = "assistant";
  if (UI.dumpMode) {
    UI.dumpMode = false;
    aiTurn({ text: "Got it. Organising it now — I'll show you everything before saving.", local: true });
    trimChat(); UI.render(); scrollChat();
    runBrainDump(text);
    return;
  }
  if (!retry && OVERWHELM.test(text) && text.length < 160) {
    UI.dumpMode = true;
    aiTurn({ text: "Don't worry about organising it. Tell me everything — tasks, deadlines, people to call, ideas, worries — in any order.", local: true });
    trimChat(); UI.render(); scrollChat(); setTimeout(() => $("#composer")?.focus(), 50);
    return;
  }
  if (!AI.on) { localIntent(text); trimChat(); UI.render(); scrollChat(); return; }
  const turn = aiTurn({ pending: true });
  UI.busy = true; UI.render(); scrollChat();
  try {
    const res = await aiChat(text, { onText: (t) => { const b = $("#bub-" + turn.id); if (b && t) { b.textContent = t; } } });
    const { receipts, cards } = applyActions(res.actions, "chat");
    turn.pending = false; turn.text = res.reply || (receipts.length ? "Done." : "");
    turn.receipts = receipts; turn.cards = cards;
    const named = res.excerpts.filter((c) => turn.text.toLowerCase().includes(c.name.toLowerCase().replace(/\.[a-z0-9]+$/, "")) || /document|file|notes say|plan says/i.test(turn.text));
    turn.sources = [...new Set(named.map((c) => c.name + " · part " + c.part))].slice(0, 3);
    if (cards.some((c) => c.type === "dump")) UI.dumpMode = true;
    const g = cards.find((c) => c.type === "goal");
    if (g && AI.on) { g.resolved = "Breaking down “" + g.title + "”…"; setTimeout(() => runDecompose({ title: g.title, why: g.why, months: monthsFromWhen(g.when), extra: text, card: { turn: turn.id, i: cards.indexOf(g) } }), 150); }
  } catch (e) {
    turn.pending = false; turn.error = AI.message(e); turn.retry = !["not_granted", "sampling_disabled", "refused"].includes(e?.code);
    if (!AI.on) { S.chat.turns = S.chat.turns.filter((x) => x !== turn); localIntent(text); }
  }
  UI.busy = false; trimChat(); UI.render(); scrollChat();
}
function monthsFromWhen(when) { const w = resolveWhen(when || ""); if (!w?.date) return 6; return clamp(Math.round(D.diff(w.date, D.today()) / 30.4), 1, 24); }

/* Deterministic intents when the model isn't available */
function localIntent(text) {
  const s = text.toLowerCase(); let m;
  const cards = [], receipts = []; let reply = "";
  if (/what should i (do|work on)|what now|what next/.test(s)) { cards.push({ type: "now" }); reply = "Here's the best use of your time right now."; }
  else if (/plan (my |the )?(day|today)|plan today/.test(s)) { cards.push({ type: "plan", date: D.today() }); reply = "Here's a realistic plan for today."; }
  else if (/tomorrow/.test(s) && /plan/.test(s)) { cards.push({ type: "plan", date: D.add(D.today(), 1) }); reply = "Here's a draft for tomorrow."; }
  else if ((m = s.match(/(\d+(?:\.\d+)?|one|two|three|four|five|an?) (hours?|hrs?|minutes?|mins?) free/))) { const n = NUMW[m[1]] || parseFloat(m[1]) || 1; cards.push({ type: "fit", minutes: Math.round(/^h/.test(m[2]) ? n * 60 : n) }); reply = "Here's what realistically fits."; }
  else if (/didn'?t finish|couldn'?t finish|did nothing|didn'?t do anything/.test(s)) { cards.push({ type: "carry" }); reply = "No problem. Let's put the unfinished work somewhere realistic."; }
  else if (/stuck|avoiding|procrastinat/.test(s)) { cards.push({ type: "stuck", taskId: null }); reply = "Let's make it smaller."; }
  else if (/(this|the) week/.test(s) && /(too much|plan|organi[sz]e|overload)/.test(s)) { cards.push({ type: "week" }); reply = "Let's spread it across the week, before the deadlines."; }
  else if (/running late|ran over|behind schedule|push (everything|it all) back/.test(s)) { cards.push({ type: "reflow" }); reply = "I'll shift the rest of today."; }
  else if (/weekly review/.test(s)) { cards.push({ type: "review" }); reply = "Your weekly review:"; }
  else {
    const body = text.replace(/^(please )?(remind me to|remember to|i need to|add( a)? task( to)?|todo:?)\s*/i, "");
    const { title, when } = splitQuickAdd(body);
    const t = createTask({ title: cap1(title), due: when?.date || null, dueTime: when?.time || null, source: "chat" });
    if (when?.date && when.time) t.planDate = when.date;
    receipts.push({ text: "Added “" + t.title + "”" + (t.due ? " · " + D.label(t.due) + (t.dueTime ? " " + D.fmtTime(t.dueTime) : "") : ""), undo: { kind: "task", id: t.id } });
    reply = "Saved as a task.";
  }
  aiTurn({ text: reply, receipts, cards, local: true });
}

/* ---------------- Brain dump ---------------- */
const KINDS = ["task", "followup", "appointment", "habit", "goal", "project", "idea", "info"];
const Dump = {
  items: [], text: "", focus: "", note: "",
  async run(text) {
    this.text = text;
    openSheet(loadingBody("Organising what you told me…", 5), { title: "Brain dump", id: "dump" });
    let res; this.note = "";
    try { res = AI.on ? await aiBrainDump(text) : heuristicDump(text); if (!AI.on) this.note = "The AI isn't available here, so I used a simpler parser. Check the items."; }
    catch (e) { res = heuristicDump(text); this.note = AI.message(e) + " I used a simpler parser — check the items."; }
    this.items = res.items.filter((i) => i && i.title).map((i) => ({ ...i, kind: KINDS.includes(i.kind) ? i.kind : i.kind === "deadline" ? "task" : "task", sel: true }));
    this.focus = res.focus || "";
    if (!this.items.length) { setSheet(`<div class="sb"><p>I couldn't find anything actionable in that. Try listing things in plain sentences.</p></div><div class="sf"><button class="btn block" data-act="close">Close</button></div>`); return; }
    this.render();
  },
  headline() {
    const sel = this.items.filter((i) => i.sel), n = (k) => sel.filter((i) => i.kind === k).length;
    const act = n("task") + n("followup") + n("appointment");
    const parts = [`${act} actionable item${act === 1 ? "" : "s"}`];
    if (n("project")) parts.push(`${n("project")} new project${n("project") > 1 ? "s" : ""}`);
    if (n("goal")) parts.push(`${n("goal")} goal${n("goal") > 1 ? "s" : ""}`);
    if (n("habit")) parts.push(`${n("habit")} habit${n("habit") > 1 ? "s" : ""}`);
    if (n("idea") + n("info")) parts.push(`${n("idea") + n("info")} note${n("idea") + n("info") > 1 ? "s" : ""}`);
    return "I found " + (parts.length > 1 ? parts.slice(0, -1).join(", ") + " and " + parts.at(-1) : parts[0]) + ".";
  },
  render() {
    setSheet(`<div class="sb"><h3 id="dump-head">${esc(this.headline())}</h3>
      ${this.note ? `<div class="notice warn small">${esc(this.note)}</div>` : ""}
      <p class="small muted">Nothing is saved yet. Untick anything wrong, tap a label to change its type, edit titles or dates.</p>
      <div>${this.items.map((it, i) => {
        const w = resolveWhen(it.when);
        return `<div class="review-item"><button class="check ${it.sel ? "on" : ""}" data-act="dump-sel" data-i="${i}" aria-label="Include">${it.sel ? icon("check") : ""}</button>
        <div class="grow" style="display:flex;flex-direction:column;gap:6px"><input class="title" id="dump-t-${i}" data-dump-title="${i}" value="${esc(it.title)}" aria-label="Title">
        <div class="row wrap" style="gap:6px"><button class="kind ${it.kind}" data-act="dump-kind" data-i="${i}">${it.kind}</button>
        ${["task", "followup", "appointment", "goal"].includes(it.kind) ? `<input class="input" id="dump-w-${i}" data-dump-when="${i}" value="${esc(it.when || "")}" placeholder="when?" style="min-height:30px;padding:4px 8px;font-size:13px;width:130px"><span class="small muted" id="dump-wl-${i}">${w?.date ? esc(D.label(w.date)) + (w.time ? " " + D.fmtTime(w.time) : "") : ""}</span>` : ""}
        ${it.kind === "habit" ? `<span class="small muted">${it.perWeek || 3}×/week</span>` : ""}
        ${it.estMin && ["task", "followup"].includes(it.kind) ? `<span class="small muted mono">${D.dur(it.estMin)}</span>` : ""}
        ${it.project ? `<span class="tag goal">${esc(it.project)}</span>` : ""}</div></div></div>`;
      }).join("")}</div></div>
      <div class="sf"><button class="btn ghost" data-act="close">Cancel</button><button class="btn accent grow" data-act="dump-commit">Save & organise</button></div>`);
  },
  commit() {
    const sel = this.items.filter((i) => i.sel);
    const created = { goals: [], projects: [], tasks: [], deadlines: 0, habits: [], events: [], notes: [] };
    // goals & projects first so tasks can link to them by name
    for (const it of sel.filter((i) => i.kind === "goal")) {
      const w = resolveWhen(it.when);
      const g = { id: uid("g"), title: it.title, why: it.notes || "", targetDate: w?.date || D.addMonths(D.today(), 6), status: "active", createdAt: Date.now() };
      S.goals.goals[g.id] = g; created.goals.push(g);
    }
    for (const it of sel.filter((i) => i.kind === "project")) {
      const g = it.project ? findByName(S.goals.goals, it.project) : null;
      if (findByName(S.goals.projects, it.title)) continue;
      const p = { id: uid("p"), title: it.title, goalId: g?.id || null, milestoneId: null, status: "active", createdAt: Date.now() };
      S.goals.projects[p.id] = p; created.projects.push(p);
    }
    Store.save("goals");
    for (const it of sel) {
      if (it.kind === "task" || it.kind === "followup") { const t = taskFromSpec({ ...it, kind: it.kind }, "dump"); created.tasks.push(t); if (t.due) created.deadlines++; }
      else if (it.kind === "appointment") {
        const w = resolveWhen(it.when);
        if (w?.date && w.time) created.events.push(addEvent({ title: it.title, date: w.date, start: w.time, durMin: it.durMin || 60 }));
        else { const t = taskFromSpec({ ...it, estMin: it.estMin || 30 }, "dump"); created.tasks.push(t); if (t.due) created.deadlines++; }
      } else if (it.kind === "habit") created.habits.push(addHabit({ title: it.title, perWeek: it.perWeek || 3, durMin: it.durMin || 30, preferredTime: "any" }));
      else if (it.kind === "idea" || it.kind === "info") created.notes.push(remember(it.title + (it.notes ? " — " + it.notes : ""), it.kind === "idea" ? "idea" : "fact"));
    }
    logActivity("dump", { n: sel.length });
    this.result(created);
  },
  result(c) {
    const today = D.today(); const pr = buildPlan(today);
    const top3 = candidateTasks(today).slice(0, 3);
    const focus = this.focus || (c.goals[0] && c.goals[0].title) || top3[0]?.title || "";
    const line = (n, s, p) => n ? `<div class="item"><span class="mono" style="width:32px;font-size:20px;font-weight:600">${n}</span><span class="grow">${n === 1 ? s : p}</span></div>` : "";
    setSheet(`<div class="sb"><div class="eyebrow">Done</div><h2>I've organised it.</h2>
      <div class="card" style="padding:4px 14px"><div class="list">${line(c.goals.length, "major goal", "major goals")}${line(c.projects.length, "active project", "active projects")}${line(c.tasks.length, "task", "tasks")}${line(c.deadlines, "deadline", "deadlines")}${line(c.habits.length, "recurring habit", "recurring habits")}${line(c.events.length, "appointment", "appointments")}${line(c.notes.length, "note kept in memory", "notes kept in memory")}</div></div>
      ${focus ? `<p>Your most important objective this week: <b>${esc(focus)}</b>.</p>` : ""}
      ${top3.length ? `<div class="section"><p><b>Today, you only need to focus on ${top3.length === 1 ? "this" : "these " + ["", "", "two", "three"][top3.length]}:</b></p><div class="card" style="padding:4px 14px">${top3.map((t) => `<div class="item"><span class="grow"><span class="title">${esc(t.title)}</span><div class="small muted">${D.dur(t.estMin)}${t.due ? " · due " + esc(D.label(t.due)) : ""}</div></span></div>`).join("")}</div></div>` : ""}
      ${c.goals.length && AI.on ? `<button class="btn soft" data-act="decompose" data-id="${c.goals[0].id}">Break down “${esc(c.goals[0].title)}”</button>` : ""}</div>
      <div class="sf"><button class="btn ghost" data-act="close">Later</button><button class="btn accent grow" data-act="plan" data-date="${today}">Schedule today</button></div>`);
    const turn = aiTurn({ text: `Organised: ${c.tasks.length} tasks${c.goals.length ? ", " + c.goals.length + " goal" + (c.goals.length > 1 ? "s" : "") : ""}${c.projects.length ? ", " + c.projects.length + " project" + (c.projects.length > 1 ? "s" : "") : ""}${c.habits.length ? ", " + c.habits.length + " habit" + (c.habits.length > 1 ? "s" : "") : ""}.${focus ? " Most important this week: " + focus + "." : ""}`, local: true, cards: [{ type: "plan", date: today }] });
    trimChat();
  },
};
const runBrainDump = (t) => Dump.run(t);
function openDumpSheet(prefill = "") {
  openSheet(`<div class="sb"><p class="ink2">Everything on your mind — tasks, deadlines, people, ideas, worries. Any order. I'll sort it and show you before saving.</p>
    <textarea class="input" id="dump-text" rows="9" placeholder="I need to call David, finish the proposal, read that book, exercise three times this week…" autofocus>${esc(prefill)}</textarea></div>
    <div class="sf"><button class="icon-btn" data-act="voice" data-target="dump-text" aria-label="Voice">${icon("mic")}</button><button class="btn accent grow" data-act="dump-go">Organise it</button></div>`, { title: "Brain dump", id: "dump-in" });
}

/* ---------------- Goal decomposition ---------------- */
const Decomp = {
  r: null, months: 6, goalId: null, sel: new Set(), hsel: new Set(), card: null,
  async run({ title, why = "", months = 6, extra = "", goalId = null, card = null }) {
    Object.assign(this, { months, goalId, card, r: null });
    openSheet(loadingBody("Breaking “" + title + "” into milestones, projects and this week's actions…", 6), { title: "Goal breakdown", id: "decomp" });
    try { this.r = await aiDecompose({ title, why, months, extra }); }
    catch (e) { setSheet(`<div class="sb"><div class="notice warn">${esc(AI.message(e))}</div><p class="small muted">You can still save the goal and add milestones yourself.</p></div><div class="sf"><button class="btn ghost" data-act="close">Close</button>${e?.code !== "not_granted" ? `<button class="btn accent grow" data-act="decomp-retry" data-title="${esc(title)}" data-why="${esc(why)}" data-months="${months}">Try again</button>` : ""}</div>`); this.last = { title, why, months, extra, goalId, card }; return; }
    const r = this.r;
    if (!r || !r.goal || !Array.isArray(r.milestones)) { setSheet(`<div class="sb"><p>I couldn't structure that goal. Try rephrasing it.</p></div><div class="sf"><button class="btn block" data-act="close">Close</button></div>`); return; }
    r.goal.title = r.goal.title || title; r.tasks = (r.tasks || []).slice(0, 10);
    this.sel = new Set(r.tasks.map((_, i) => i)); this.hsel = new Set((r.habits || []).map((_, i) => i));
    this.render();
  },
  render() {
    const r = this.r, today = D.today();
    const nP = sum(r.milestones, (m) => (m.projects || []).length);
    const selTasks = r.tasks.filter((_, i) => this.sel.has(i));
    setSheet(`<div class="sb">
      <input class="input" id="dc-title" value="${esc(r.goal.title)}" style="font-size:19px;font-weight:800" aria-label="Goal title">
      ${r.goal.why ? `<p class="small ink2"><b>Why:</b> ${esc(r.goal.why)}</p>` : ""}
      <div class="crumb"><span>${this.months}-month goal</span><span>${r.milestones.length} milestones</span><span>${nP} projects</span><span>${selTasks.length} actions this week (${D.dur(sum(selTasks, (t) => +t.estMin || 30))})</span></div>
      ${r.note ? `<div class="notice small">${esc(r.note)}</div>` : ""}
      <div class="section"><div class="eyebrow">Milestones</div><div class="tree">${r.milestones.map((m, i) => `<div class="ms ${i === 0 ? "cur" : ""}"><div><b>${esc(m.title)}</b> <span class="small muted">· by ${esc(D.label(D.endOfMonth(D.addMonths(today, clamp(+m.month || i + 1, 1, this.months) - 1))))}</span></div><div class="chips">${(m.projects || []).map((p) => `<span class="tag goal">${esc(p.title)}</span>`).join("")}</div></div>`).join("")}</div></div>
      ${(r.weekly_objectives || []).length ? `<div class="section"><div class="eyebrow">This week's objectives</div>${r.weekly_objectives.map((o) => `<div class="small">• ${esc(o.title)}</div>`).join("")}</div>` : ""}
      <div class="section"><div class="eyebrow">This week's actions</div>${r.tasks.map((t, i) => `<div class="review-item"><button class="check ${this.sel.has(i) ? "on" : ""}" data-act="dc-sel" data-i="${i}">${this.sel.has(i) ? icon("check") : ""}</button><div class="grow"><div style="font-weight:600">${esc(t.title)}${i === 0 ? ' <span class="tag goal">Next action</span>' : ""}</div><div class="small muted">${esc(D.label(D.add(today, clamp(+t.day || 0, 0, 6))))} · ${D.dur(+t.estMin || 30)} · ${esc(t.priority || "medium")}</div></div></div>`).join("")}</div>
      ${(r.habits || []).length ? `<div class="section"><div class="eyebrow">Habits</div>${r.habits.map((h, i) => `<div class="review-item"><button class="check ${this.hsel.has(i) ? "on" : ""}" data-act="dc-hsel" data-i="${i}">${this.hsel.has(i) ? icon("check") : ""}</button><div class="grow"><b>${esc(h.title)}</b> <span class="small muted">${h.perWeek}×/week · ${h.durMin || 30}m</span></div></div>`).join("")}</div>` : ""}
      ${(r.commitments || []).length ? `<div class="section"><div class="eyebrow">Fixed commitments</div><p class="small muted">Add times so I schedule around them. Leave blank to skip.</p>${r.commitments.map((c, i) => `<div class="review-item"><div class="grow"><b>${esc(c.title)}</b><div class="small muted">${esc((c.days || []).join(", ") || "days not given")}</div>
        <div class="row" style="margin-top:6px"><input class="input" type="time" id="dc-cs-${i}" value="${esc(c.start || "")}" style="min-height:38px" aria-label="Start"><span class="muted">–</span><input class="input" type="time" id="dc-ce-${i}" value="${esc(c.end || "")}" style="min-height:38px" aria-label="End"></div>
        <div class="chips" style="margin-top:6px">${["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map((d) => `<button class="chip ${(c.days || []).map((x) => String(x).toLowerCase().slice(0, 3)).includes(d) ? "on" : ""}" data-act="dc-day" data-i="${i}" data-d="${d}" style="min-height:30px;padding:0 9px">${d.slice(0, 2)}</button>`).join("")}</div></div></div>`).join("")}</div>` : ""}
    </div><div class="sf"><button class="btn ghost" data-act="close">Cancel</button><button class="btn accent grow" data-act="dc-commit">Create goal & plan</button></div>`);
  },
  commit() {
    const r = this.r;
    r.goal.title = $("#dc-title")?.value.trim() || r.goal.title;
    (r.commitments || []).forEach((c, i) => { c.start = $("#dc-cs-" + i)?.value || null; c.end = $("#dc-ce-" + i)?.value || null; });
    const g = commitDecomposition(r, { months: this.months, sel: this.sel, habitSel: this.hsel, goalId: this.goalId });
    if (this.card) { const t = S.chat.turns.find((x) => x.id === this.card.turn); if (t?.cards?.[this.card.i]) t.cards[this.card.i].resolved = "Goal created: " + g.title; Store.save("chat"); }
    UI.toast("Goal created with " + goalMilestones(g.id).length + " milestones.");
    PlanSheet.open(D.today(), { intro: "Here's today with the first steps of “" + g.title + "”" + (Object.keys(S.cal.events).length ? ", around your fixed commitments" : "") + "." });
  },
};
const runDecompose = (o) => Decomp.run(o);

/* ---------------- Plan review ---------------- */
const PlanSheet = {
  pr: null, excluded: new Set(), intro: "",
  open(date, { intro = "" } = {}) { this.pr = buildPlan(date); this.excluded = new Set(); this.intro = intro; openSheet("", { title: date === D.today() ? "Plan for today" : "Plan for " + D.label(date), id: "plan" }); this.render(); },
  render() {
    const pr = this.pr, date = pr.date;
    const existing = dayPlan(date);
    const light = [1, 2, 3, 4, 5, 6].map((i) => D.add(date, i)).find((d) => plannedLoad(d) < capacityFor(d) * 0.6) || D.add(date, 1);
    setSheet(`<div class="sb">
      ${this.intro ? `<p><b>${esc(this.intro)}</b></p>` : ""}
      <p class="ink2">${planMessage(pr)}</p>
      ${existing ? `<p class="small muted">This replaces the rest of the current plan. Finished items stay.</p>` : ""}
      <div class="card" style="padding:4px 14px"><div class="list">${pr.blocks.map((b) => `<div class="item ${b.type === "event" ? "event" : ""}" style="${this.excluded.has(b.id) ? "opacity:.4" : ""}"><span class="time">${D.fmtRange(b.start, b.end)}</span><span class="grow"><span class="title">${esc(b.title)}</span>${b.type === "habit" ? ' <span class="tag brass">Habit</span>' : ""}${b.session ? ' <span class="tag">Session</span>' : ""}</span>
        ${b.type !== "event" ? `<button class="btn ghost sm" data-act="plan-x" data-id="${b.id}" aria-label="${this.excluded.has(b.id) ? "Include" : "Remove"}">${this.excluded.has(b.id) ? "Add back" : icon("x")}</button>` : ""}</div>`).join("") || '<p class="muted small" style="padding:12px 0">Nothing to schedule. Add tasks or a goal first.</p>'}</div></div>
      ${pr.overflow.length ? `<div class="section"><div class="row between"><div class="eyebrow">Didn't fit (${pr.overflow.length})</div><button class="link small" data-act="overflow-move" data-date="${light}">Move all to ${esc(D.label(light))}</button></div><div class="card" style="padding:4px 14px">${pr.overflow.map((o) => `<div class="item"><span class="grow"><span class="title">${esc(o.title)}</span><div class="small muted">${D.dur(o.full || o.est)} · ${o.reason === "capacity" ? "over your free time" : "no free slot"}</div></span>${o.taskId ? `<button class="btn soft sm" data-act="reschedule" data-id="${o.taskId}">Move</button>` : ""}</div>`).join("")}</div></div>` : ""}
    </div><div class="sf"><button class="btn ghost" data-act="close">Not now</button><button class="btn accent grow" data-act="plan-approve" ${pr.blocks.filter((b) => b.type !== "event").length ? "" : "disabled"}>Approve plan</button></div>`);
  },
  approve() {
    const pr = this.pr;
    approvePlan({ ...pr, blocks: pr.blocks.filter((b) => !this.excluded.has(b.id)) });
    for (const b of pr.blocks) if (this.excluded.has(b.id) && b.taskId && S.tasks.items[b.taskId]?.planDate === pr.date) S.tasks.items[b.taskId].planDate = null;
    closeSheet(); UI.toast("Plan saved. I'll check in when sessions start and end.");
  },
};

/* ---------------- Task & block sheets ---------------- */
function openTaskSheet(id, block = null, date = D.today()) {
  const t = S.tasks.items[id]; if (!t) return;
  const kids = childrenOf(t.id);
  const goalOpts = Object.values(S.goals.projects);
  const strictLine = t.postponed >= 2 ? strictCopy(t) : "";
  openSheet(`<div class="sb">
    ${crumbs(t)}
    <input class="input" id="ts-title" data-tfield="title" data-id="${t.id}" value="${esc(t.title)}" style="font-size:18px;font-weight:700" aria-label="Title">
    ${block ? `<div class="row small"><span class="mono">${D.fmtRange(block.start, block.end)}</span><span class="muted">${esc(D.label(date))}${block.session ? " · one session of a larger task" : ""}</span></div>` : ""}
    ${strictLine ? `<div class="notice warn small">${esc(strictLine)}</div>` : ""}
    <div class="row wrap">${t.status === "done" ? `<button class="btn soft" data-act="toggle-task" data-id="${t.id}">Mark not done</button>` : `<button class="btn accent" data-act="${block ? "block-done" : "toggle-task"}" data-id="${block ? block.id : t.id}">${icon("check")}Done</button><button class="btn soft" data-act="focus-task" data-id="${t.id}">${icon("play")}Start</button><button class="btn soft" data-act="reschedule" data-id="${t.id}">${icon("clock")}Move</button><button class="btn ghost" data-act="stuck" data-id="${t.id}">I'm stuck</button>`}</div>
    <div class="field"><label>Estimate</label><div class="chips">${[15, 30, 45, 60, 90, 120, 180].map((m) => `<button class="chip ${t.estMin === m ? "on" : ""}" data-act="t-est" data-id="${t.id}" data-v="${m}">${D.dur(m)}</button>`).join("")}</div></div>
    <div class="field"><label>Priority</label><div class="seg">${["high", "medium", "low"].map((p) => `<button class="${t.priority === p ? "on" : ""}" data-act="t-pri" data-id="${t.id}" data-v="${p}">${cap1(p)}</button>`).join("")}</div></div>
    <div class="field"><label>Energy needed</label><div class="seg">${["high", "medium", "low"].map((p) => `<button class="${t.energy === p ? "on" : ""}" data-act="t-en" data-id="${t.id}" data-v="${p}">${cap1(p)}</button>`).join("")}</div></div>
    <div class="field"><label>Repeats</label><div class="seg">${[["", "Never"], ["daily", "Daily"], ["weekdays", "Weekdays"], ["weekly", "Weekly"]].map(([v, l]) => `<button class="${(t.recurrence || "") === v ? "on" : ""}" data-act="t-rec" data-id="${t.id}" data-v="${v}">${l}</button>`).join("")}</div></div>
    <div class="row" style="gap:10px"><div class="field grow"><label for="ts-due">Deadline</label><input class="input" type="date" id="ts-due" data-tfield="due" data-id="${t.id}" value="${t.due || ""}"></div>
      <div class="field grow"><label for="ts-plan">Planned for</label><input class="input" type="date" id="ts-plan" data-tfield="planDate" data-id="${t.id}" value="${t.planDate || ""}"></div></div>
    <div class="field"><label for="ts-proj">Project</label><select class="input" id="ts-proj" data-tfield="projectId" data-id="${t.id}"><option value="">None</option>${goalOpts.map((p) => `<option value="${p.id}" ${t.projectId === p.id ? "selected" : ""}>${esc(p.title)}${p.goalId && S.goals.goals[p.goalId] ? " — " + esc(S.goals.goals[p.goalId].title) : ""}</option>`).join("")}</select></div>
    <div class="field"><label for="ts-notes">Notes</label><textarea class="input" id="ts-notes" data-tfield="notes" data-id="${t.id}" rows="3" style="min-height:80px">${esc(t.notes)}</textarea></div>
    <div class="field"><label>Steps</label>${kids.map((k) => `<div class="item ${k.status === "done" ? "done" : ""}"><button class="check round ${k.status === "done" ? "on" : ""}" data-act="toggle-task" data-id="${k.id}" data-keep="1">${k.status === "done" ? icon("check") : ""}</button><span class="grow title">${esc(k.title)}</span><span class="small muted mono">${D.dur(k.estMin)}</span></div>`).join("")}
      <form class="row" data-form="add-step" data-id="${t.id}"><input class="input" id="ts-step" placeholder="Add a step" style="min-height:40px"><button class="btn soft sm" type="submit">Add</button></form></div>
    ${t.deps?.length ? `<p class="small muted">Waiting on: ${esc(t.deps.map((d) => S.tasks.items[d]?.title).filter(Boolean).join(", "))}</p>` : ""}
    <div class="row wrap">${block && block.status === "planned" ? `<button class="btn ghost sm" data-act="block-skip" data-id="${block.id}" data-date="${date}">Skip this session</button>` : ""}<button class="btn ghost sm" data-act="drop" data-id="${t.id}">Drop task</button><button class="btn ghost sm" data-act="delete-task" data-id="${t.id}" style="color:var(--bad)">${icon("trash")}Delete</button></div>
    <p class="small muted">Added ${esc(new Date(t.createdAt).toLocaleDateString())} · from ${esc(t.source)}${t.postponed ? " · moved " + t.postponed + "×" : ""}</p>
  </div>`, { title: "Task", id: "task:" + t.id });
}
function strictCopy(t) {
  const n = t.postponed, lvl = S.profile.strictness;
  if (lvl === "gentle") return "This has moved a few times. Want to shrink it or drop it?";
  if (lvl === "direct") return `You've postponed this ${n} times. Let's schedule it now — or make it smaller.`;
  if (lvl === "strict") return `This has been postponed ${n} times. It stays on today's plan. Do the smallest version: 15 minutes.`;
  return `This has moved ${n} times. The smallest useful step might be easier to start.`;
}
function openBlock(id, date = D.today()) {
  const day = dayPlan(date); const b = day?.blocks.find((x) => x.id === id); if (!b) return;
  if (b.taskId) return openTaskSheet(b.taskId, b, date);
  if (b.type === "habit") {
    const h = S.habits.items[b.habitId]; if (!h) return;
    return openSheet(`<div class="sb"><div class="row small"><span class="mono">${D.fmtRange(b.start, b.end)}</span><span class="muted">${esc(D.label(date))}</span></div><h2>${esc(h.title)}</h2><p class="small muted">${habitWeekCount(h, date)}/${h.perWeek} this week. Missing a day never stacks sessions — I'll spread the rest out.</p></div>
      <div class="sf"><button class="btn ghost" data-act="block-skip" data-id="${b.id}" data-date="${date}">Skip today</button><button class="btn soft" data-act="focus-habit" data-id="${h.id}" data-block="${b.id}">Start</button><button class="btn accent grow" data-act="block-done" data-id="${b.id}" data-date="${date}">Done</button></div>`, { title: "Habit" });
  }
  const ev = S.cal.events[b.eventId];
  openSheet(`<div class="sb"><div class="row small"><span class="mono">${D.fmtRange(b.start, b.end)}</span></div><h2>${esc(b.title)}</h2><p class="small muted">${ev?.days ? "Repeats " + ev.days.map((d) => DOW[d]).join(", ") : "One-off"} · ${esc(CalendarProviders[ev?.source || "internal"]?.label || "Calendar")}</p></div>
    <div class="sf"><button class="btn ghost" data-act="close">Close</button>${ev ? `<button class="btn ghost" data-act="event-del" data-id="${ev.id}" style="color:var(--bad)">Delete event</button>` : ""}</div>`, { title: "Calendar" });
}

/* ---------------- Rescheduling ---------------- */
function openReschedule(id) {
  const t = S.tasks.items[id]; if (!t) return;
  const ro = rescheduleOptions(t);
  const strict = t.postponed >= 2 ? strictCopy(t) : "";
  openSheet(`<div class="sb"><h3>${esc(t.title)}</h3>
    <p class="ink2">${esc(rescheduleText(t, ro))}</p>
    ${strict ? `<div class="notice warn small">${esc(strict)}</div>` : ""}
    <div class="section">${ro.options.map((o) => `<button class="btn ${o.recommended ? "accent" : "soft"} block" data-act="move-to" data-task="${t.id}" data-date="${o.date}" data-start="${o.start ?? ""}" style="justify-content:space-between"><span>${esc(o.label)}</span><span class="small" style="opacity:.8">${o.id === "later" ? "" : esc(loadWord(o))}${o.recommended ? " · lighter" : ""}</span></button>`).join("")}</div>
    <details><summary class="link small" style="cursor:pointer">Other days</summary><div class="section" style="margin-top:8px">${ro.all.filter((o) => !ro.options.includes(o)).map((o) => `<button class="item tap" data-act="move-to" data-task="${t.id}" data-date="${o.date}" data-start="${o.start ?? ""}"><span class="grow">${esc(o.label)}</span><span class="small muted">${D.dur(o.load)} of ${D.dur(o.cap)} · ${esc(loadWord(o))}</span></button>`).join("")}</div></details>
    <div class="row wrap">${t.estMin > 20 ? `<button class="btn ghost sm" data-act="shrink" data-id="${t.id}">Do a 15-minute version today</button>` : ""}<button class="btn ghost sm" data-act="t-unplan" data-id="${t.id}">No date</button><button class="btn ghost sm" data-act="drop" data-id="${t.id}">Drop it</button></div>
  </div>`, { title: "Reschedule" });
}
function openRescheduleAny() {
  const today = D.today(), day = dayPlan(today), n = D.nowMin();
  const upcoming = (day?.blocks || []).filter((b) => b.type === "task" && b.status === "planned" && b.end > n).map((b) => ({ b, t: S.tasks.items[b.taskId] })).filter((x) => x.t && x.t.status !== "done");
  const overdue = openTasks().filter((t) => (t.due && D.diff(t.due, today) < 0) || (t.planDate && D.diff(t.planDate, today) < 0));
  const cap = capacityFor(today) - doneMinutesOn(today), load = sum(upcoming, (x) => x.b.end - x.b.start);
  openSheet(`<div class="sb">
    ${load > cap * 0.9 && upcoming.length > 1 ? `<div class="notice warn"><div class="grow small">Today still has ${D.dur(load)} planned and about ${D.dur(Math.max(0, cap))} of your free time left.</div><button class="btn soft sm" data-act="lighten">Lighten today</button></div>` : ""}
    ${upcoming.length ? `<div class="eyebrow">Still planned today</div><div class="card" style="padding:4px 14px">${upcoming.map(({ b, t }) => `<button class="item tap" data-act="reschedule" data-id="${t.id}"><span class="time">${D.fmtRange(b.start, b.end)}</span><span class="grow title">${esc(t.title)}</span>${icon("chev", "muted")}</button>`).join("")}</div>` : '<p class="muted small">Nothing left on today\'s plan.</p>'}
    ${overdue.length ? `<div class="eyebrow">Overdue or left over</div><div class="card" style="padding:4px 14px">${overdue.map((t) => `<button class="item tap" data-act="reschedule" data-id="${t.id}"><span class="grow"><span class="title">${esc(t.title)}</span><div class="small muted">${t.due && D.diff(t.due, today) < 0 ? "was due " + esc(D.label(t.due)) : "planned " + esc(D.label(t.planDate))}</div></span>${icon("chev", "muted")}</button>`).join("")}</div>` : ""}
  </div>`, { title: "Reschedule" });
}
function lightenToday() {
  const today = D.today(), day = dayPlan(today), n = D.nowMin();
  const up = (day?.blocks || []).filter((b) => b.type === "task" && b.status === "planned" && b.end > n);
  let load = sum(up, (b) => b.end - b.start); const cap = Math.max(0, capacityFor(today) - doneMinutesOn(today)) * 0.85;
  const sorted = up.map((b) => ({ b, t: S.tasks.items[b.taskId] })).filter((x) => x.t).sort((a, b) => scoreTask(a.t, today) - scoreTask(b.t, today));
  const move = []; for (const x of sorted) { if (load <= cap) break; if (isMustDo(x.t, today) && x.t.due === today) continue; move.push(x); load -= x.b.end - x.b.start; }
  if (!move.length) { UI.toast("Everything left today is due today. Consider shrinking a task instead."); return; }
  const tmr = D.add(today, 1);
  openSheet(`<div class="sb"><p>Moving these lower-impact items to <b>${esc(D.label(tmr))}</b> brings today back to about ${D.dur(load)}:</p><div class="card" style="padding:4px 14px">${move.map((x) => `<div class="item"><span class="grow title">${esc(x.t.title)}</span><span class="small muted">${D.dur(x.t.estMin)}</span></div>`).join("")}</div></div>
    <div class="sf"><button class="btn ghost" data-act="close">Cancel</button><button class="btn accent grow" data-act="lighten-apply" data-ids="${move.map((x) => x.t.id).join(",")}">Move ${move.length} to tomorrow</button></div>`, { title: "Lighten today" });
}

/* ---------------- Stuck ---------------- */
function openStuck(taskId) {
  const t = taskId && S.tasks.items[taskId];
  const tasks = t ? [] : candidateTasks(D.today()).slice(0, 6);
  openSheet(`<div class="sb">${t ? `<h3>${esc(t.title)}</h3>` : `<div class="field"><label for="st-task">Which task?</label><select class="input" id="st-task">${tasks.map((x) => `<option value="${x.id}">${esc(x.title)}</option>`).join("")}</select></div>`}
    <p class="ink2">What is blocking you?</p>
    <div class="chips" id="st-chips">${["It's too big", "I don't know where to start", "I'm missing information", "Low energy", "I keep avoiding it", "I'm not sure it matters"].map((c) => `<button class="chip" data-act="st-chip" data-v="${esc(c)}">${esc(c)}</button>`).join("")}</div>
    <textarea class="input" id="st-text" rows="3" style="min-height:80px" placeholder="Or say it in your own words"></textarea></div>
    <div class="sf"><button class="btn accent block" data-act="st-go" data-id="${t ? t.id : ""}">Help me move</button></div>`, { title: "I'm stuck" });
}
async function runStuck(taskId, blocker) {
  const t = S.tasks.items[taskId];
  setSheet(loadingBody("Finding the smallest useful step…", 3));
  let r;
  try { r = AI.on ? await aiStuck(t, blocker) : null; } catch (e) { r = null; UI.toast(AI.message(e)); }
  if (!r || !r.firstStep) r = { reply: t ? `Let's shrink it. Open “${t.title}” and work on it for 15 minutes — just the first piece. Stop after that if you want.` : "Pick one thing and give it 15 minutes.", firstStep: { title: t ? "First 15 minutes: " + t.title : "15 minutes on the top task", estMin: 15 }, steps: [] };
  Stuck.r = r; Stuck.taskId = taskId; logActivity("stuck", { taskId, blocker });
  setSheet(`<div class="sb"><p>${esc(r.reply)}</p>
    <div class="now"><div class="eyebrow">Smallest next step</div><div class="t">${esc(r.firstStep.title)}</div><div class="meta">${D.dur(r.firstStep.estMin || 15)}</div><div class="row"><button class="btn" data-act="st-start">${icon("play")}Start now</button></div></div>
    ${(r.steps || []).length ? `<div class="section"><div class="eyebrow">Then</div><div class="card" style="padding:4px 14px">${r.steps.map((s) => `<div class="item"><span class="grow">${esc(s.title)}</span><span class="small muted mono">${D.dur(s.estMin || 15)}</span></div>`).join("")}</div><button class="btn soft" data-act="st-steps">Save these as steps</button></div>` : ""}
  </div>`);
}
const Stuck = { r: null, taskId: null };

/* ---------------- Focus mode ---------------- */
const Focus = {
  timer: null, end: 0, paused: 0, ctx: null, lock: null,
  start(ctx) {
    this.ctx = ctx; const min = clamp(ctx.minutes || 25, 5, 180);
    this.end = Date.now() + min * 60000; this.startedAt = Date.now(); this.paused = 0;
    const day = dayPlan(); const b = ctx.blockId && day?.blocks.find((x) => x.id === ctx.blockId); if (b) { b.status = "active"; b.startPrompted = true; Store.save("plan"); }
    closeSheetQuiet();
    $("#overlay-slot").innerHTML = `<div class="focus" role="dialog" aria-label="Focus session"><div class="eyebrow" style="color:inherit;opacity:.75">Focus · ${min} min</div><div class="t">${esc(ctx.title)}</div><div class="clock" id="focus-clock">${String(min).padStart(2, "0")}:00</div>
      <div class="row wrap" style="justify-content:center"><button class="btn" data-act="focus-done">${icon("check")}Done</button><button class="btn ghost" data-act="focus-pause" id="focus-pause">Pause</button><button class="btn ghost" data-act="focus-stop">${icon("stop")}Stop</button></div>
      <p class="small" style="opacity:.75;max-width:34ch">Stay with this one thing. I'll ask how it went when the time is up.</p></div>`;
    try { navigator.wakeLock?.request("screen").then((l) => (this.lock = l)).catch(() => {}); } catch {}
    clearInterval(this.timer); this.timer = setInterval(() => this.tick(), 500); this.tick();
    logActivity("focus-start", { taskId: ctx.taskId || null });
  },
  tick() {
    if (this.paused) return;
    const left = Math.max(0, this.end - Date.now()); const el = $("#focus-clock");
    if (el) el.textContent = String(Math.floor(left / 60000)).padStart(2, "0") + ":" + String(Math.floor(left / 1000) % 60).padStart(2, "0");
    if (left <= 0) { this.finish(); askHowItWent(this.ctx); }
  },
  pause() { if (this.paused) { this.end += Date.now() - this.paused; this.paused = 0; $("#focus-pause").textContent = "Pause"; } else { this.paused = Date.now(); $("#focus-pause").textContent = "Resume"; } },
  finish() { clearInterval(this.timer); $("#overlay-slot").innerHTML = ""; try { this.lock?.release(); } catch {} const mins = Math.round((Date.now() - this.startedAt) / 60000); return mins; },
};
function closeSheetQuiet() { $("#sheet-slot").innerHTML = ""; UI.sheetOpen = null; }
function startFocusTask(id, minutes) {
  const t = S.tasks.items[id]; if (!t) return;
  const day = dayPlan(); const b = day?.blocks.find((x) => x.taskId === id && (x.status === "planned" || x.status === "active"));
  Focus.start({ taskId: id, blockId: b?.id, title: t.title, minutes: minutes || (b ? b.end - b.start : Math.min(t.estMin, 50)) });
}
function askHowItWent(ctx) {
  UI.checkin = { kind: "end", blockId: ctx.blockId || null, taskId: ctx.taskId || null, habitId: ctx.habitId || null, title: ctx.title, date: D.today() };
  UI.render();
}

/* ---------------- Check-ins (accountability) ---------------- */
function checkinTick() {
  if (!BOOTED || !S.profile.onboarded || UI.checkin || $("#overlay-slot").innerHTML || UI.sheetOpen) return;
  const pref = S.profile.remind; if (pref === "quiet") return;
  const date = D.today(), day = dayPlan(date); if (!day) return;
  const n = D.nowMin();
  for (const b of day.blocks) {
    if (b.type === "event") continue;
    const done = b.status === "done" || (b.taskId && S.tasks.items[b.taskId]?.status === "done");
    if (done || b.status === "skipped" || b.status === "moved") continue;
    if (b.status === "planned" && !b.startPrompted && n >= b.start && n < b.start + 15) { UI.checkin = { kind: "start", blockId: b.id, title: b.title, date }; break; }
    if (pref !== "start" && !b.checked && n >= b.end && n < b.end + 180) { UI.checkin = { kind: "end", blockId: b.id, taskId: b.taskId, habitId: b.habitId, title: b.title, date }; break; }
  }
  if (UI.checkin) renderCheckin();
}
function renderCheckin() {
  const slot = $("#checkin-slot"); if (!slot) return;
  const c = UI.checkin; if (!c || !S.profile.onboarded) { slot.innerHTML = ""; return; }
  if (c.kind === "start") slot.innerHTML = `<div class="checkin"><div class="c" role="alertdialog" aria-label="Session starting"><div class="row between"><span class="eyebrow">Starting now</span><button class="icon-btn" style="width:34px;height:34px" data-act="ci-dismiss" aria-label="Dismiss">${icon("x")}</button></div><div style="font-weight:700">Your “${esc(c.title)}” session starts now.</div><div class="row"><button class="btn accent grow" data-act="ci-start">${icon("play")}Start</button><button class="btn soft" data-act="ci-later">Move it</button></div></div></div>`;
  else {
    const habit = !!c.habitId && !c.taskId;
    slot.innerHTML = `<div class="checkin"><div class="c" role="alertdialog" aria-label="Check-in"><div class="row between"><span class="eyebrow">Check-in</span><button class="icon-btn" style="width:34px;height:34px" data-act="ci-dismiss" aria-label="Dismiss">${icon("x")}</button></div><div style="font-weight:700">How did “${esc(c.title)}” go?</div>
      <div class="chips"><button class="chip on" data-act="ci" data-v="done">Done</button>${habit ? "" : `<button class="chip" data-act="ci" data-v="partial">Partially done</button><button class="chip" data-act="ci" data-v="working">Still working</button><button class="chip" data-act="ci" data-v="stuck">Stuck</button>`}<button class="chip" data-act="ci" data-v="skip">Skip</button></div></div></div>`;
  }
}
function checkinAnswer(v) {
  const c = UI.checkin; if (!c) return; UI.checkin = null;
  const day = dayPlan(c.date); const b = c.blockId && day?.blocks.find((x) => x.id === c.blockId);
  if (b) { b.checked = true; Store.save("plan"); }
  const t = c.taskId && S.tasks.items[c.taskId];
  logActivity("checkin", { v, taskId: c.taskId || null });
  if (v === "done") { if (b) completeBlock(b); else if (t) completeTask(t.id); else if (c.habitId) toggleHabit(c.habitId); UI.render(); UI.toast("Logged. +" + (t ? S.profile.pointsRules.task * (t.priority === "high" ? 2 : 1) : S.profile.pointsRules.habit) + " points."); return; }
  if (v === "partial" && t) { completeTask(t.id, { partial: true }); UI.render(); openReschedule(t.id); return; }
  if (v === "working") {
    if (b) { b.end = Math.max(b.end, D.nowMin()) + 20; b.checked = false; b.status = "active"; Store.save("plan"); }
    const clash = b && day.blocks.some((x) => x !== b && x.type !== "event" && x.status === "planned" && x.start < b.end + 5 && x.end > b.start);
    UI.render();
    if (clash) UI.toast("Extended by 20 minutes. That runs into your next session.", { label: "Shift the rest", fn: openReflow });
    else UI.toast("Extended by 20 minutes. I'll check again after.");
    return;
  }
  if (v === "stuck") { UI.render(); openStuck(t?.id || null); return; }
  if (v === "skip") { if (b) { b.status = "skipped"; Store.save("plan"); } logActivity("skip", { taskId: t?.id || null }); UI.render(); if (t) openReschedule(t.id); return; }
  UI.render();
}

/* ---------------- Weekly review ---------------- */
async function openReview(ws) {
  const existing = S.reviews.items[ws];
  if (existing) return showReview(ws, existing);
  openSheet(loadingBody("Reviewing your week…", 5), { title: "Weekly review", id: "review" });
  let r;
  try { if (!AI.on) throw { code: "not_granted" }; r = await aiWeeklyReview(ws); }
  catch (e) {
    const st = weekStats(ws);
    r = { completed: st.completed.length ? `${st.completed.length} tasks: ${st.completed.slice(0, 6).map((t) => t.title).join(", ")}.` : "No tasks completed.", movedForward: st.goals.filter((x) => x.doneThisWeek).map((x) => x.g.title + " (" + x.doneThisWeek + " tasks)").join(", ") || "No goal moved this week.", missed: st.rate == null ? "No plans were approved." : `${st.planned - st.plannedDone} of ${st.planned} planned tasks weren't finished.`, postponing: st.postponed.slice(0, 3).map((x) => x.t.title + " ×" + x.n).join(", ") || "Nothing repeatedly postponed.", attention: st.overdue.length ? st.overdue.length + " overdue: " + st.overdue.slice(0, 3).map((t) => t.title).join(", ") : "Nothing overdue.", priorities: candidateTasks(D.add(ws, 7)).slice(0, 3).map((t) => ({ title: t.title, taskId: t.id })), adjustment: bestDaypart() ? "Put demanding work in the " + bestDaypart() + ", when you finish the most." : "", stats: { rate: st.rate, completed: st.completed.length }, fallback: e?.code !== "not_granted" ? AI.message(e) : "" };
  }
  r.at = Date.now(); S.reviews.items[ws] = r; Store.save("reviews");
  showReview(ws, r);
}
function showReview(ws, r) {
  const sec = (h, b) => b ? `<div class="section" style="gap:4px"><div class="eyebrow">${h}</div><p>${esc(b)}</p></div>` : "";
  openSheet(`<div class="sb"><p class="small muted">Week of ${esc(D.long(ws))}${r.stats?.rate != null ? " · " + Math.round(r.stats.rate * 100) + "% of planned work done" : ""}</p>
    ${r.fallback ? `<div class="notice warn small">${esc(r.fallback)} This version is built from your numbers only.</div>` : ""}
    ${sec("What you completed", r.completed)}${sec("What moved forward", r.movedForward)}${sec("What was missed", r.missed)}${sec("What you keep postponing", r.postponing)}${sec("What needs attention", r.attention)}
    ${(r.priorities || []).length ? `<div class="section" style="gap:6px"><div class="eyebrow">Next week's priorities</div>${r.priorities.map((p) => `<div class="item"><span class="grow title">${esc(p.title)}</span></div>`).join("")}</div>` : ""}
    ${r.adjustment ? `<div class="notice"><div class="grow"><div class="eyebrow">Adjustment</div><p>${esc(r.adjustment)}</p></div></div>` : ""}
  </div><div class="sf"><button class="btn ghost" data-act="review-redo" data-week="${ws}">Rewrite</button><button class="btn accent grow" data-act="review-apply" data-week="${ws}">Make these next week's focus</button></div>`, { title: "Weekly review", id: "review" });
}

/* ---------------- Quick-add sheets ---------------- */
function openAddTask({ date = null, projectId = null } = {}) {
  const projects = Object.values(S.goals.projects);
  openSheet(`<form class="sb" data-form="add-task" autocomplete="off">
    <input class="input" id="at-title" placeholder="Call John tomorrow at 3pm" autofocus style="font-size:17px">
    <div class="small muted" id="at-preview">${date ? "For " + esc(D.label(date)) : "Type a day or time and I'll pick it up."}</div>
    <div class="field"><label>Estimate</label><div class="chips" data-group="at-est">${[15, 30, 60, 90, 120].map((m) => `<button type="button" class="chip ${m === 30 ? "on" : ""}" data-act="pick" data-group="at-est" data-v="${m}">${D.dur(m)}</button>`).join("")}</div></div>
    <div class="field"><label>Priority</label><div class="seg" data-group="at-pri">${["high", "medium", "low"].map((p) => `<button type="button" class="${p === "medium" ? "on" : ""}" data-act="pick" data-group="at-pri" data-v="${p}">${cap1(p)}</button>`).join("")}</div></div>
    ${projects.length ? `<div class="field"><label for="at-proj">Project</label><select class="input" id="at-proj"><option value="">None</option>${projects.map((p) => `<option value="${p.id}" ${projectId === p.id ? "selected" : ""}>${esc(p.title)}</option>`).join("")}</select></div>` : ""}
    <input type="hidden" id="at-date" value="${date || ""}">
    <button class="btn accent block" type="submit">Add task</button></form>`, { title: "Add task" });
  const inp = $("#at-title"); inp.addEventListener("input", () => { const { title, when } = splitQuickAdd(inp.value); $("#at-preview").textContent = when?.date ? "“" + title + "” · " + D.label(when.date) + (when.time ? " at " + D.fmtTime(when.time) : " (deadline)") : date ? "For " + D.label(date) : "No date — I'll fit it in by priority."; });
}
function submitAddTask() {
  const raw = $("#at-title").value.trim(); if (!raw) return;
  const { title, when } = splitQuickAdd(raw);
  const est = +($('[data-group="at-est"] .on')?.dataset.v || 30), pri = $('[data-group="at-pri"] .on')?.dataset.v || "medium";
  const fixed = $("#at-date").value;
  const t = createTask({ title: cap1(title), estMin: est, priority: pri, due: when?.date || null, dueTime: when?.time || null, projectId: $("#at-proj")?.value || null, source: "manual" });
  if (fixed) t.planDate = fixed; else if (when?.time) t.planDate = when.date;
  let msg = "Added “" + t.title + "”.";
  if (t.planDate && dayPlan(t.planDate)) { const st = insertIntoDay(t, t.planDate, when?.time ? D.toMin(when.time) : null); if (st != null) msg += " Slotted at " + D.fmtTime(st) + "."; }
  closeSheet(); UI.toast(msg, { label: "Undo", fn: () => { undoReceipt({ kind: "task", id: t.id }); UI.render(); } });
}
function openAddGoal() {
  openSheet(`<form class="sb" data-form="add-goal" autocomplete="off">
    <div class="field"><label for="ag-title">What do you want to achieve?</label><input class="input" id="ag-title" placeholder="Launch my business" autofocus></div>
    <div class="field"><label for="ag-why">Why does it matter?</label><input class="input" id="ag-why" placeholder="Optional — helps me prioritise"></div>
    <div class="field"><label>Timeframe</label><div class="chips">${[1, 3, 6, 12].map((m) => `<button type="button" class="chip ${m === 6 ? "on" : ""}" data-act="pick" data-group="ag-m" data-v="${m}">${m} month${m > 1 ? "s" : ""}</button>`).join("")}</div></div>
    <div class="field"><label for="ag-extra">Anything else I should know?</label><textarea class="input" id="ag-extra" rows="3" style="min-height:80px" placeholder="Workstreams, constraints, school, exercise…"></textarea></div>
    <button class="btn accent block" type="submit">${AI.on ? "Break it down" : "Save goal"}</button></form>`, { title: "Add goal" });
}
function submitAddGoal() {
  const title = $("#ag-title").value.trim(); if (!title) return;
  const why = $("#ag-why").value.trim(), extra = $("#ag-extra").value.trim(), months = +($('[data-group="ag-m"].on')?.dataset.v || $$('[data-act="pick"][data-group="ag-m"]').find((b) => b.classList.contains("on"))?.dataset.v || 6);
  if (AI.on) return runDecompose({ title, why, months, extra });
  const g = { id: uid("g"), title, why, targetDate: D.addMonths(D.today(), months), status: "active", createdAt: Date.now() };
  S.goals.goals[g.id] = g; Store.save("goals"); closeSheet(); UI.goalId = g.id; UI.go("goals");
}
function openHabit(id = null) {
  const h = id ? S.habits.items[id] : { title: "", perWeek: 3, durMin: 30, preferredTime: "any" };
  openSheet(`<form class="sb" data-form="habit" data-id="${id || ""}" autocomplete="off">
    <div class="field"><label for="hb-title">Habit</label><input class="input" id="hb-title" value="${esc(h.title)}" placeholder="Exercise" autofocus></div>
    <div class="chips">${["Exercise", "Reading", "Prayer", "Study", "Journaling", "Sleep by 11", "Drink water", "Deep work"].map((s) => `<button type="button" class="chip outline" data-act="hb-preset" data-v="${s}">${s}</button>`).join("")}</div>
    <div class="field"><label>Times per week</label><div class="chips">${[1, 2, 3, 4, 5, 6, 7].map((n) => `<button type="button" class="chip ${h.perWeek === n ? "on" : ""}" data-act="pick" data-group="hb-n" data-v="${n}">${n}</button>`).join("")}</div></div>
    <div class="field"><label>Minutes</label><div class="chips">${[10, 15, 30, 45, 60, 90].map((n) => `<button type="button" class="chip ${h.durMin === n ? "on" : ""}" data-act="pick" data-group="hb-d" data-v="${n}">${n}</button>`).join("")}</div></div>
    <div class="field"><label>Best time</label><div class="seg">${["any", "morning", "afternoon", "evening"].map((n) => `<button type="button" class="${h.preferredTime === n ? "on" : ""}" data-act="pick" data-group="hb-t" data-v="${n}">${cap1(n)}</button>`).join("")}</div></div>
    <div class="row"><button class="btn accent grow" type="submit">Save habit</button>${id ? `<button class="btn ghost" type="button" data-act="habit-del" data-id="${id}" style="color:var(--bad)">Delete</button>` : ""}</div></form>`, { title: id ? "Edit habit" : "Add habit" });
}
function openAllTasks() {
  const today = D.today(), open = openTasks().sort((a, b) => scoreTask(b, today) - scoreTask(a, today));
  const groups = [["Overdue", open.filter((t) => t.due && D.diff(t.due, today) < 0)], ["Today", open.filter((t) => (t.planDate === today || t.due === today) && !(t.due && D.diff(t.due, today) < 0))], ["Upcoming", open.filter((t) => (t.planDate && t.planDate > today) || (t.due && t.due > today && t.planDate !== today))], ["No date", open.filter((t) => !t.planDate && !t.due)]];
  const seen = new Set();
  const done = allTasks().filter((t) => t.status === "done").sort((a, b) => b.doneAt - a.doneAt).slice(0, 10);
  openSheet(`<div class="sb">${groups.map(([h, ts]) => { const list = ts.filter((t) => !seen.has(t.id)); list.forEach((t) => seen.add(t.id)); return list.length ? `<div class="section"><div class="eyebrow">${h} (${list.length})</div><div class="card" style="padding:4px 14px">${list.map((t) => taskRow(t)).join("")}</div></div>` : ""; }).join("") || '<p class="muted">No open tasks.</p>'}
    ${done.length ? `<div class="section"><div class="eyebrow">Recently done</div><div class="card" style="padding:4px 14px">${done.map((t) => taskRow(t)).join("")}</div></div>` : ""}</div>`, { title: "All tasks" });
}

/* ---------------- Documents & memory ---------------- */
function loadScript(src) { return new Promise((res, rej) => { if ($$(`script[src="${src}"]`).length) return res(); const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("Couldn't load " + src)); document.head.appendChild(s); }); }
async function extractText(file) {
  const name = file.name.toLowerCase();
  if (name.endsWith(".pdf")) {
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js");
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js");
    const lib = window.pdfjsLib || window["pdfjs-dist/build/pdf"];
    lib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    const pdf = await lib.getDocument({ data: await file.arrayBuffer(), isEvalSupported: false }).promise;
    let out = "";
    for (let i = 1; i <= Math.min(pdf.numPages, 300); i++) { const pg = await pdf.getPage(i); const c = await pg.getTextContent(); out += c.items.map((x) => x.str + (x.hasEOL ? "\n" : " ")).join("") + "\n\n"; }
    return out;
  }
  if (name.endsWith(".docx")) {
    await loadScript("https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js");
    const r = await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() }); return r.value;
  }
  if (/\.(txt|md|markdown|csv|json|html?|ics|rtf)$/.test(name) || file.type.startsWith("text/")) {
    let t = await file.text(); if (/\.html?$/.test(name)) { const d = new DOMParser().parseFromString(t, "text/html"); t = d.body.innerText || d.body.textContent; } return t;
  }
  throw new Error("Unsupported file type. Use PDF, Word (.docx), text, Markdown or CSV.");
}
function openDocs() {
  const docs = Object.values(S.kbindex.docs).sort((a, b) => b.addedAt - a.addedAt);
  const facts = Object.values(S.memory.facts).sort((a, b) => b.at - a.at);
  const labels = { preference: "Preference", fact: "Fact", person: "Person", goal_context: "Goal context", idea: "Idea" };
  openSheet(`<div class="sb">
    <p class="small ink2">Upload plans, notes, schedules or reference files. I search them when you ask a question and name the file I'm quoting. If something isn't in them, I'll say so.</p>
    <label class="btn accent block" for="doc-file" style="cursor:pointer">${icon("upload")}Upload files</label>
    <input type="file" id="doc-file" multiple accept=".pdf,.docx,.txt,.md,.csv,.json,.html,.htm" style="position:absolute;opacity:0;width:1px;height:1px">
    <div id="doc-status" class="small muted"></div>
    <div class="section"><div class="eyebrow">Documents (${docs.length})</div>${docs.length ? `<div class="card" style="padding:4px 14px">${docs.map((d) => `<div class="item"><span class="grow"><span class="title">${esc(d.name)}</span><div class="small muted">${d.chunks} passages · ${esc(new Date(d.addedAt).toLocaleDateString())}</div></span><button class="btn ghost sm" data-act="doc-del" data-id="${d.id}" aria-label="Delete document">${icon("trash")}</button></div>`).join("")}</div>` : '<p class="small muted">None yet.</p>'}</div>
    <div class="section"><div class="eyebrow">What I remember about you (${facts.length})</div>
      <p class="small muted">Only things you told me that should last — preferences, people, context. Tasks and chats aren't stored here.</p>
      ${facts.length ? `<div class="card" style="padding:4px 14px">${facts.map((f) => `<div class="item"><span class="grow"><span class="small muted">${esc(labels[f.type] || f.type)}</span><div>${esc(f.text)}</div></span><button class="btn ghost sm" data-act="fact-del" data-id="${f.id}" aria-label="Forget">${icon("x")}</button></div>`).join("")}</div>` : ""}
      <form class="row" data-form="add-fact"><input class="input" id="fact-text" placeholder="e.g. I study best after 8 PM"><button class="btn soft sm" type="submit">Save</button></form></div>
    ${S.profile.summary ? `<div class="section"><div class="eyebrow">Your profile</div><p class="small">${esc(S.profile.summary)}</p></div>` : ""}
  </div>`, { title: "Documents & memory", id: "docs" });
  $("#doc-file").addEventListener("change", async (e) => {
    const files = [...e.target.files]; const st = $("#doc-status");
    for (const f of files) {
      if (f.size > 25e6) { st.textContent = f.name + " is over 25 MB."; continue; }
      st.textContent = "Reading " + f.name + "…";
      try { const text = await extractText(f); if (!text.trim()) throw new Error("No readable text (scanned PDFs need OCR first)."); await KB.add(f.name, text); st.textContent = "Added " + f.name + "."; }
      catch (err) { st.textContent = f.name + ": " + (err.message || "couldn't read it") + (err.code === "quota_exceeded" ? " Storage is full." : ""); }
    }
    setTimeout(openDocs, 600);
  });
}

/* ---------------- Settings ---------------- */
function openSettings() {
  const p = S.profile;
  const ev = Object.values(S.cal.events).filter((e) => e.days || D.diff(e.date, D.today()) >= 0);
  openSheet(`<div class="sb">
    <div class="field"><label for="st-name">Name</label><input class="input" id="st-name" data-pref="name" value="${esc(p.name)}"></div>
    <div class="row" style="gap:10px"><div class="field grow"><label for="st-wake">Wake up</label><input class="input" type="time" id="st-wake" data-pref="wake" value="${p.wake}"></div><div class="field grow"><label for="st-sleep">Sleep</label><input class="input" type="time" id="st-sleep" data-pref="sleep" value="${p.sleep}"></div></div>
    <div class="field"><label>Most productive</label><div class="seg">${["morning", "afternoon", "evening", "night"].map((x) => `<button class="${p.peak === x ? "on" : ""}" data-act="set-pref" data-k="peak" data-v="${x}">${cap1(x)}</button>`).join("")}</div></div>
    <div class="row" style="gap:10px"><div class="field grow"><label for="st-fw">Free hours · weekdays</label><input class="input" type="number" min="0" max="16" step="0.5" id="st-fw" data-pref="freeHours.weekday" value="${p.freeHours.weekday}"></div><div class="field grow"><label for="st-fe">Free hours · weekends</label><input class="input" type="number" min="0" max="16" step="0.5" id="st-fe" data-pref="freeHours.weekend" value="${p.freeHours.weekend}"></div></div>
    <div class="field"><label>How strict should I be?</label><div class="seg">${Object.keys(STRICT).map((x) => `<button class="${p.strictness === x ? "on" : ""}" data-act="set-pref" data-k="strictness" data-v="${x}">${cap1(x)}</button>`).join("")}</div><p class="small muted">${esc(STRICT[p.strictness].split("—")[1] || "")}</p></div>
    <div class="field"><label>Check-ins</label><div class="seg">${[["checkins", "Start & end"], ["start", "Start only"], ["quiet", "Quiet"]].map(([k, l]) => `<button class="${p.remind === k ? "on" : ""}" data-act="set-pref" data-k="remind" data-v="${k}">${l}</button>`).join("")}</div><p class="small muted">Check-ins appear while the app is open. Phone notifications and WhatsApp come later.</p></div>
    <div class="field"><label>Learn from my behaviour</label><div class="seg">${[["on", "On"], ["off", "Off"]].map(([k, l]) => `<button class="${(p.adaptive !== false) === (k === "on") ? "on" : ""}" data-act="set-adaptive" data-v="${k}">${l}</button>`).join("")}</div><p class="small muted">Adjusts plans to how long things really take you and when you actually get work done.${paceStats() ? " Current pace: " + paceStats().factor.toFixed(1) + "× estimates." : ""}${bestDaypart() ? " Best time: " + bestDaypart() + "." : ""}</p></div>
    <div class="section"><div class="row between"><div class="eyebrow">Fixed commitments</div><button class="link small" data-act="add-commit">Add</button></div>${ev.length ? `<div class="card" style="padding:4px 14px">${ev.map((e) => `<div class="item"><span class="grow"><span class="title">${esc(e.title)}</span><div class="small muted mono">${e.days ? e.days.map((d) => DOW[d]).join(" ") : esc(D.label(e.date))} · ${e.start}–${e.end}</div></span><button class="btn ghost sm" data-act="event-del" data-id="${e.id}" aria-label="Delete">${icon("trash")}</button></div>`).join("")}</div>` : '<p class="small muted">School, work, classes — anything I should plan around.</p>'}</div>
    <div class="section"><div class="eyebrow">Calendars</div><div class="card" style="padding:4px 14px"><div class="item"><span class="grow"><span class="title">Della calendar</span><div class="small muted">Built in · active</div></span><span class="tag goal">On</span></div>${["Google Calendar", "Apple Calendar", "Outlook"].map((c) => `<div class="item"><span class="grow"><span class="title">${c}</span><div class="small muted">Planned for a later release</div></span></div>`).join("")}</div></div>
    <div class="row wrap"><button class="btn soft sm" data-act="docs">${icon("file")}Documents & memory</button><button class="btn soft sm" data-act="rewards-edit">${icon("medal")}Rewards & points</button><button class="btn soft sm" data-act="redo-onb">Redo onboarding</button></div>
    ${NATIVE ? `<div class="section"><div class="eyebrow">Assistant</div><p class="small muted">The AI features use your own Anthropic API key (from console.anthropic.com). It's stored securely on this phone and only sent to Anthropic.</p>
      <form class="row" data-form="api-key"><input class="input" type="password" id="api-key" placeholder="${NATIVE_KEY ? "Key saved — paste to replace" : "sk-ant-…"}" autocomplete="off"><button class="btn soft sm" type="submit">Save</button></form>
      <div class="seg">${[["quick", "Fast"], ["default", "Balanced"], ["complex", "Best"]].map(([k, l]) => `<button class="${(p.aiTier || "default") === k ? "on" : ""}" data-act="set-pref" data-k="aiTier" data-v="${k}">${l}</button>`).join("")}</div></div>` : ""}
    <div class="section"><div class="eyebrow">Data</div><p class="small muted">${NATIVE ? "Saved on this phone. Reminders arrive as phone notifications." : Store.mode === "cloud" ? "Saved privately to your account — only you can see it, on any device where you open this app." : Store.mode === "local" ? "Saved in this browser only." : "Storage is unavailable here; changes are lost when you close the page."}</p>
      <button class="btn ghost sm" data-act="reset" style="color:var(--bad);align-self:flex-start">Erase all data…</button></div>
  </div>`, { title: "Settings", id: "settings" });
}
function openRewards() {
  const pr = S.profile.pointsRules;
  openSheet(`<div class="sb">
    <p class="small ink2">Points reward meaningful progress, not busywork. Set what they're worth and what they buy.</p>
    <div class="section">${[["task", "Task"], ["habit", "Habit session"], ["daily", "Full day's plan"], ["weekly", "Week's objectives"], ["milestone", "Milestone"]].map(([k, l]) => `<div class="row between"><label for="pr-${k}" class="grow">${l}</label><input class="input" type="number" min="0" id="pr-${k}" data-pref="pointsRules.${k}" value="${pr[k]}" style="width:110px;text-align:right"></div>`).join("")}</div>
    <div class="section"><div class="eyebrow">Rewards</div>${S.rewards.rules.map((r) => `<div class="item"><span class="grow"><b>${esc(r.title)}</b><div class="small muted mono">${r.cost} points</div></span><button class="btn ghost sm" data-act="reward-del" data-id="${r.id}" aria-label="Delete">${icon("trash")}</button></div>`).join("") || '<p class="small muted">None yet.</p>'}
    <form class="row" data-form="add-reward"><input class="input grow" id="rw-title" placeholder="Movie night"><input class="input" id="rw-cost" type="number" min="10" placeholder="500" style="width:92px"><button class="btn soft sm" type="submit">Add</button></form></div>
  </div>`, { title: "Rewards & points", id: "rewards" });
}

/* ---------------- Voice (architecture: any transcript → the same text pipeline) ---------------- */
const Voice = {
  start(target) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const fallback = () => { UI.toast("Voice input isn't available in this view yet. Type instead — voice will feed the same pipeline."); if (target === "dump") openDumpSheet(); else $("#" + target)?.focus(); };
    if (!SR) return fallback();
    if (target === "dump") { openDumpSheet(); target = "dump-text"; }
    try {
      const r = new SR(); r.lang = navigator.language || "en-US"; r.interimResults = true; r.continuous = false;
      const el = $("#" + target); const base = el ? el.value : "";
      r.onresult = (e) => { const tx = [...e.results].map((x) => x[0].transcript).join(" "); if (el) el.value = (base ? base + " " : "") + tx; };
      r.onerror = () => fallback(); r.onend = () => UI.toast("Got it.");
      r.start(); UI.toast("Listening…");
    } catch { fallback(); }
  },
};

/* ---------------- Onboarding ---------------- */
const Onboarding = {
  step: 0,
  steps: [
    { k: "name", q: "Hi. I'm your assistant.", sub: "I'll remember things for you, turn big goals into steps, and tell you what to do next. First — what should I call you?", type: "text", ph: "Your name" },
    { k: "goals", q: "What are your biggest goals right now?", sub: "Messy is fine. One per line, or just talk.", type: "area", ph: "Launch my business in six months…" },
    { k: "working", q: "What are you currently working on?", type: "area", ph: "Website, a proposal, exams…" },
    { k: "commitments", q: "What commitments do you already have?", sub: "School, work, classes, family — with days and times if you know them.", type: "area", ph: "School Mon–Fri 8am–2pm, gym Tue/Thu…" },
    { k: "forgets", q: "What do you frequently forget?", type: "chips+", opts: ["Calls & replies", "Deadlines", "Bills", "Appointments", "Follow-ups", "Groceries", "Birthdays"] },
    { k: "blockers", q: "What usually stops you from finishing things?", type: "chips+", opts: ["Too many things at once", "Don't know where to start", "Distractions", "Low energy", "Perfectionism", "Plans change", "I forget"] },
    { k: "wake", q: "What time do you normally wake up?", type: "time", opts: ["05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "09:00"] },
    { k: "sleep", q: "And when do you normally sleep?", type: "time", opts: ["21:30", "22:00", "22:30", "23:00", "23:30", "00:00", "01:00"] },
    { k: "peak", q: "When are you most productive?", type: "one", opts: [["morning", "Morning"], ["afternoon", "Afternoon"], ["evening", "Evening"], ["night", "Late night"]] },
    { k: "free", q: "How much free time do you normally have?", sub: "Time for your own goals — after school, work and commitments.", type: "free" },
    { k: "strictness", q: "How strict should I be with you?", type: "one", opts: [["gentle", "Gentle"], ["balanced", "Balanced"], ["direct", "Direct"], ["strict", "Strict"]], ex: true },
    { k: "remind", q: "How do you prefer to be reminded?", type: "one", opts: [["checkins", "Check in when sessions start and end"], ["start", "Only when sessions start"], ["quiet", "Keep it quiet — I'll check the app"]] },
    { k: "motivators", q: "What motivates you?", type: "chips+", opts: ["Points", "Streaks", "Entertainment", "Gaming", "Food", "Social media", "Money", "Free time"] },
    { k: "rewards", q: "What rewards do you want?", sub: "Pick some, or write your own like “500 = Movie night”.", type: "rewards" },
    { k: "files", q: "Are there files I should understand?", sub: "Plans, schedules, notes. You can add them now or later from the Assistant tab.", type: "files" },
  ],
  a() { S.profile.onb = S.profile.onb || {}; return S.profile.onb; },
  view() {
    const s = this.steps[this.step], a = this.a();
    if (this.step === 0 && a.name == null) a.name = S.profile.name || "";
    let body = "";
    if (s.type === "text") body = `<input class="input" id="ob-in" value="${esc(a[s.k] || "")}" placeholder="${esc(s.ph)}" style="font-size:20px" autofocus>`;
    if (s.type === "area") body = `<textarea class="input" id="ob-in" rows="6" placeholder="${esc(s.ph)}" autofocus>${esc(a[s.k] || "")}</textarea><button class="btn ghost sm" style="align-self:flex-start" data-act="voice" data-target="ob-in">${icon("mic")}Speak instead</button>`;
    if (s.type === "chips+") { const sel = a[s.k] || []; body = `<div class="chips">${s.opts.map((o) => `<button class="chip ${sel.includes(o) ? "on" : ""}" data-act="ob-multi" data-v="${esc(o)}">${esc(o)}</button>`).join("")}</div><input class="input" id="ob-in" value="${esc(a[s.k + "_x"] || "")}" placeholder="Anything else?">`; }
    if (s.type === "time") body = `<div class="chips">${s.opts.map((o) => `<button class="chip ${a[s.k] === o ? "on" : ""}" data-act="ob-one" data-v="${o}">${D.fmtTime(o)}</button>`).join("")}</div><div class="field"><label for="ob-in">Or exactly</label><input class="input" type="time" id="ob-in" value="${esc(a[s.k] || "")}"></div>`;
    if (s.type === "one") body = `<div class="section">${s.opts.map(([v, l]) => `<button class="btn ${a[s.k] === v ? "accent" : "soft"} block" style="justify-content:flex-start;min-height:52px" data-act="ob-one" data-v="${v}">${esc(l)}${s.ex ? `<span class="small" style="opacity:.75;font-weight:500;margin-left:auto;text-align:right;max-width:60%">${esc((STRICT[v].split("e.g.")[1] || STRICT[v].split("—")[1] || "").replace(/'/g, "").trim())}</span>` : ""}</button>`).join("")}</div>`;
    if (s.type === "free") body = `<div class="field"><label>On weekdays</label><div class="chips">${[1, 2, 3, 4, 5, 6, 8].map((n) => `<button class="chip ${a.freeW == n ? "on" : ""}" data-act="ob-free" data-k="freeW" data-v="${n}">${n === 8 ? "8h+" : n + "h"}</button>`).join("")}</div></div><div class="field"><label>On weekends</label><div class="chips">${[1, 2, 3, 4, 6, 8, 10].map((n) => `<button class="chip ${a.freeE == n ? "on" : ""}" data-act="ob-free" data-k="freeE" data-v="${n}">${n === 10 ? "10h+" : n + "h"}</button>`).join("")}</div></div>`;
    if (s.type === "rewards") { const sel = a.rewards || []; const presets = ["300 = Episode of a show", "500 = Movie night", "800 = Favourite meal out", "1000 = Gaming evening", "1500 = Free afternoon", "2500 = Something I've wanted to buy"]; body = `<div class="chips">${presets.map((o) => `<button class="chip ${sel.includes(o) ? "on" : ""}" data-act="ob-reward" data-v="${esc(o)}">${esc(o)}</button>`).join("")}</div><input class="input" id="ob-in" placeholder="700 = Dinner with friends"><p class="small muted">A small task earns 10 points, a full day's plan 50, a week's objectives 250, a milestone 1,000. You can change these later.</p>`; }
    if (s.type === "files") body = `<button class="btn soft" data-act="docs">${icon("upload")}Add files</button><p class="small muted">${Object.keys(S.kbindex.docs).length} added.</p>`;
    const last = this.step === this.steps.length - 1;
    return `<div class="onb"><div class="progress-dots">${this.steps.map((_, i) => `<i class="${i <= this.step ? "on" : ""}"></i>`).join("")}</div>
      <div class="section" style="gap:8px"><div class="q">${esc(this.step === 0 ? s.q : s.q)}</div>${s.sub ? `<p class="ink2">${esc(s.sub)}</p>` : ""}</div>
      <div class="section">${body}</div>
      <div class="row">${this.step ? `<button class="btn ghost" data-act="ob-back">Back</button>` : ""}<span class="grow"></span>${this.step > 0 && !last ? `<button class="btn ghost" data-act="ob-skip">Skip</button>` : ""}<button class="btn accent" data-act="ob-next">${last ? "Build my profile" : "Continue"}</button></div>
      ${this.step === 0 ? `<button class="link small" data-act="ob-quick" style="align-self:center">Skip setup and start with a brain dump</button>` : ""}</div>`;
  },
  capture() {
    const s = this.steps[this.step], a = this.a(), v = $("#ob-in")?.value?.trim();
    if (s.type === "text" || s.type === "area") a[s.k] = v || "";
    if (s.type === "chips+") a[s.k + "_x"] = v || "";
    if (s.type === "time" && v) a[s.k] = v;
    if (s.type === "rewards" && v) { a.rewards = a.rewards || []; if (/\d/.test(v)) a.rewards.push(v); }
    Store.save("profile");
  },
  next() { this.capture(); if (this.step < this.steps.length - 1) { this.step++; UI.render(); window.scrollTo(0, 0); } else this.finish(); },
  back() { this.capture(); this.step = Math.max(0, this.step - 1); UI.render(); },
  applyBasics() {
    const a = this.a(), p = S.profile;
    if (a.name) p.name = a.name.slice(0, 40);
    if (a.wake) p.wake = a.wake; if (a.sleep) p.sleep = a.sleep; if (a.peak) p.peak = a.peak;
    if (a.freeW) p.freeHours.weekday = +a.freeW; if (a.freeE) p.freeHours.weekend = +a.freeE;
    if (a.strictness) p.strictness = a.strictness; if (a.remind) p.remind = a.remind;
    p.motivators = a.motivators || []; p.forgets = [...(a.forgets || []), a.forgets_x].filter(Boolean).join(", "); p.blockers = [...(a.blockers || []), a.blockers_x].filter(Boolean).join(", ");
    p.working = a.working || ""; p.commitmentsText = a.commitments || "";
    for (const r of a.rewards || []) { const m = String(r).match(/(\d[\d,]*)\s*(?:points?|pts)?\s*[=:\-–]\s*(.+)/i) || String(r).match(/(.+?)\s*[=:\-–]\s*(\d[\d,]*)/); if (!m) continue; const cost = +(String(m[1]).match(/\d/) ? m[1] : m[2]).replace(/,/g, ""); const title = String(m[1]).match(/\d/) ? m[2] : m[1]; if (cost && title && !S.rewards.rules.some((x) => x.title === title.trim())) S.rewards.rules.push({ id: uid("r"), title: title.trim(), cost, claimed: 0 }); }
    Store.save("profile", "rewards");
  },
  async finish() {
    this.applyBasics();
    const a = this.a();
    const answers = { "Biggest goals": a.goals, "Currently working on": a.working, "Existing commitments": a.commitments, "Frequently forgets": S.profile.forgets, "What prevents completion": S.profile.blockers, "Wakes": S.profile.wake, "Sleeps": S.profile.sleep, "Most productive": S.profile.peak, "Free time": S.profile.freeHours.weekday + "h weekdays / " + S.profile.freeHours.weekend + "h weekends", "Strictness": S.profile.strictness, "Motivators": S.profile.motivators };
    $("#app").innerHTML = `<div class="onb"><div class="q">Building your profile…</div><p class="ink2">Turning what you told me into goals, commitments and a first plan.</p>${Array.from({ length: 5 }, (_, i) => `<div class="skeleton" style="width:${92 - i * 11}%"></div>`).join("")}</div>`;
    let r = null;
    if (AI.on && (a.goals || a.working || a.commitments)) { try { r = await aiOnboard(answers); } catch (e) { UI.toast(AI.message(e)); } }
    if (!r) r = { summary: "", goals: String(a.goals || "").split(/\n+/).map((s) => s.trim()).filter(Boolean).slice(0, 4).map((t) => ({ title: cap1(t.replace(/^[-*•\d.)\s]+/, "")), why: "", when: t })), commitments: [], habits: [], tasks: [], memory: [], focus: "" };
    this.r = r;
    this.review();
  },
  review() {
    const r = this.r;
    $("#tabbar").innerHTML = "";
    $("#app").innerHTML = `<div class="onb"><div class="eyebrow">Your profile</div><div class="q">Here's how I understand you.</div>
      ${r.summary ? `<p class="ink2" style="font-size:16px">${esc(r.summary)}</p>` : ""}
      ${(r.goals || []).length ? `<div class="section"><div class="eyebrow">Goals</div>${r.goals.map((g, i) => `<div class="review-item"><button class="check on" data-act="ob-tog" data-g="goals" data-i="${i}">${icon("check")}</button><div class="grow"><b>${esc(g.title)}</b>${g.why ? `<div class="small muted">${esc(g.why)}</div>` : ""}</div></div>`).join("")}</div>` : ""}
      ${(r.commitments || []).length ? `<div class="section"><div class="eyebrow">Fixed commitments</div>${r.commitments.map((c, i) => `<div class="review-item"><div class="grow"><b>${esc(c.title)}</b><div class="small muted">${esc((c.days || []).join(", "))}</div><div class="row" style="margin-top:6px"><input class="input" type="time" id="ob-cs-${i}" value="${esc(c.start || "")}" style="min-height:38px" aria-label="Start"><span class="muted">–</span><input class="input" type="time" id="ob-ce-${i}" value="${esc(c.end || "")}" style="min-height:38px" aria-label="End"></div></div></div>`).join("")}</div>` : ""}
      ${(r.habits || []).length ? `<div class="section"><div class="eyebrow">Habits</div>${r.habits.map((h, i) => `<div class="review-item"><button class="check on" data-act="ob-tog" data-g="habits" data-i="${i}">${icon("check")}</button><div class="grow"><b>${esc(h.title)}</b> <span class="small muted">${h.perWeek}×/week</span></div></div>`).join("")}</div>` : ""}
      ${(r.tasks || []).length ? `<div class="section"><div class="eyebrow">Tasks</div>${r.tasks.map((t, i) => `<div class="review-item"><button class="check on" data-act="ob-tog" data-g="tasks" data-i="${i}">${icon("check")}</button><div class="grow"><b>${esc(t.title)}</b>${t.when ? ` <span class="small muted">${esc(t.when)}</span>` : ""}</div></div>`).join("")}</div>` : ""}
      <div class="row"><button class="btn ghost" data-act="ob-back-q">Back</button><button class="btn accent grow" data-act="ob-commit">Looks right</button></div></div>`;
  },
  commit() {
    const r = this.r, off = (g) => new Set($$(`[data-act="ob-tog"][data-g="${g}"]`).filter((b) => !b.classList.contains("on")).map((b) => +b.dataset.i));
    const gOff = off("goals"), hOff = off("habits"), tOff = off("tasks");
    S.profile.summary = r.summary || "";
    const goals = [];
    (r.goals || []).forEach((g, i) => { if (gOff.has(i)) return; const w = resolveWhen(g.when); const ng = { id: uid("g"), title: g.title, why: g.why || "", targetDate: w?.date && D.diff(w.date, D.today()) > 14 ? w.date : D.addMonths(D.today(), 6), status: "active", createdAt: Date.now() }; S.goals.goals[ng.id] = ng; goals.push(ng); });
    (r.commitments || []).forEach((c, i) => { const s = $("#ob-cs-" + i)?.value, e = $("#ob-ce-" + i)?.value; if (s && e) addEvent({ title: c.title, days: daysFrom(c.days) || [1, 2, 3, 4, 5], start: s, end: e, kind: "commitment" }); });
    (r.habits || []).forEach((h, i) => { if (!hOff.has(i)) addHabit(h); });
    (r.tasks || []).forEach((t, i) => { if (!tOff.has(i)) taskFromSpec(t, "onboarding"); });
    (r.memory || []).forEach((m) => m.text && remember(m.text, m.category || "fact"));
    if (S.rewards.rules.length === 0) S.rewards.rules.push({ id: uid("r"), title: "Movie night", cost: 500, claimed: 0 });
    S.profile.onboarded = true; S.profile.onboardedAt = Date.now();
    Store.save("profile", "goals", "rewards");
    UI.tab = "home"; UI.render();
    const big = goals[0];
    if (big && AI.on) setTimeout(() => runDecompose({ title: big.title, why: big.why, months: Math.max(1, Math.round(D.diff(big.targetDate, D.today()) / 30.4)), goalId: big.id, extra: [this.a().goals, this.a().working, this.a().commitments].filter(Boolean).join("\n") }), 250);
    else if (openTasks().length) PlanSheet.open(D.today(), { intro: "Your profile is set. Here's a first plan for today." });
  },
};


/* ---------------- Week plan & reflow sheets ---------------- */
const WeekSheet = {
  w: null, off: new Set(),
  open() { this.w = planWeek(); this.off = new Set(); openSheet("", { title: "Plan the week", id: "week" }); this.render(); },
  render() {
    const w = this.w, by = {};
    w.assign.forEach((a, i) => (by[a.date] = by[a.date] || []).push([a, i]));
    const risks = deadlineRisks();
    setSheet(`<div class="sb">
      <p class="ink2">${w.assign.length ? `I spread ${w.assign.length} task${w.assign.length > 1 ? "s" : ""} across the next 7 days — each before its deadline, on the lightest day that still has room.` : "Nothing needs spreading out. Your week already fits."}</p>
      ${risks.length ? `<div class="notice warn small"><div class="grow">${risks.map((r) => `${esc(D.label(r.date))}: ${D.dur(r.work)} due, ~${D.dur(r.free)} free before then.`).join("<br>")} Consider dropping, shrinking or renegotiating something.</div></div>` : ""}
      ${w.days.map((d) => { const items = by[d] || []; const load = w.load[d], cap = w.cap[d]; return `<div class="section" style="gap:6px"><div class="row between small"><b>${esc(D.label(d))}</b><span class="mono muted">${D.dur(load)} / ${D.dur(cap)}</span></div><div class="bar ${load > cap ? "over" : ""}"><i style="width:${clamp(load / Math.max(1, cap) * 100, 1, 100)}%"></i></div>
        ${items.map(([a, i]) => `<div class="item" style="${this.off.has(i) ? "opacity:.4" : ""}"><span class="grow"><span class="title">${esc(a.t.title)}</span><div class="small muted">${D.dur(a.t.estMin)}${a.t.due ? " · due " + esc(D.label(a.t.due)) : ""}${a.tight ? " · tight day" : ""}</div></span><button class="btn ghost sm" data-act="week-x" data-i="${i}">${this.off.has(i) ? "Add back" : icon("x")}</button></div>`).join("")}</div>`; }).join("")}
      ${w.unplaced.length ? `<p class="small muted">Not scheduled (no deadline and no room): ${esc(w.unplaced.slice(0, 6).map((t) => t.title).join(", "))}.</p>` : ""}
    </div><div class="sf"><button class="btn ghost" data-act="close">Not now</button><button class="btn accent grow" data-act="week-apply" ${w.assign.length ? "" : "disabled"}>Apply to my week</button></div>`);
  },
  apply() { applyWeek({ ...this.w, assign: this.w.assign.filter((_, i) => !this.off.has(i)) }); closeSheet(); UI.toast("Week planned. Each day's plan uses these."); },
};
let REFLOW = null;
function openReflow() {
  REFLOW = reflowToday();
  if (!REFLOW || !(REFLOW.moves.length + REFLOW.overflow.length)) { UI.toast("Nothing left on today's plan to shift."); return; }
  const changed = REFLOW.moves.filter((m) => m.from !== m.to);
  openSheet(`<div class="sb"><p class="ink2">Here's the rest of today, shifted to start from now. Order stays the same.</p>
    <div class="card" style="padding:4px 14px">${REFLOW.moves.map((m) => `<div class="item"><span class="time">${D.toHHMM(m.to)}</span><span class="grow"><span class="title">${esc(m.b.title)}</span>${m.from !== m.to ? `<div class="small muted">was ${D.toHHMM(m.from)}</div>` : ""}</span></div>`).join("")}</div>
    ${REFLOW.overflow.length ? `<div class="notice warn small"><div class="grow">No room today for: ${esc(REFLOW.overflow.map((b) => b.title).join(", "))}. These move to tomorrow.</div></div>` : ""}
    ${!changed.length && !REFLOW.overflow.length ? '<p class="small muted">Everything already fits.</p>' : ""}</div>
    <div class="sf"><button class="btn ghost" data-act="close">Keep as is</button><button class="btn accent grow" data-act="reflow-apply">Shift the rest of today</button></div>`, { title: "Shift today" });
}
