/* Expo/React Native bridge — gives the page the same `window.claude` surface it has on claude.ai.
   db → phone storage (AsyncStorage), user → this device, sample → Anthropic API via native code. */
(function () {
  if (!window.ReactNativeWebView) return;
  let seq = 0; const pending = {};
  window.__nativeReply = (id, ok, data) => { const p = pending[id]; if (!p) return; delete pending[id]; ok ? p.res(data) : p.rej(data); };
  const call = (type, payload) => new Promise((res, rej) => { const id = "n" + ++seq; pending[id] = { res, rej }; window.ReactNativeWebView.postMessage(JSON.stringify({ id, type, ...payload })); });
  window.__native = { call };
  const db = { doc: (path) => ({ path,
    async get() { const v = await call("db.get", { path }); return { exists: v != null, id: path.split("/").pop(), data: () => v, metadata: {} }; },
    async set(data) { await call("db.set", { path, data }); },
    async delete() { await call("db.delete", { path }); } }) };
  const user = { id: async () => "local", isOwner: () => true, canEdit: () => true };
  function parseJSON(t) {
    try { return JSON.parse(t); } catch {}
    const f = t.match(/```(?:json)?\s*([\s\S]*?)```/); if (f) { try { return JSON.parse(f[1]); } catch {} }
    const a = Math.min(...["{", "["].map((c) => { const i = t.indexOf(c); return i < 0 ? Infinity : i; })), b = Math.max(t.lastIndexOf("}"), t.lastIndexOf("]"));
    if (a < b) { try { return JSON.parse(t.slice(a, b + 1)); } catch {} }
    throw { code: "invalid_json", message: "No JSON in reply", text: t };
  }
  const tier = (o) => (o && o.modelTier) || (typeof S !== "undefined" && S.profile && S.profile.aiTier) || "default";
  async function sample(input, opts = {}) { const text = await call("ai", { input, tier: tier(opts), json: false }); opts.onText && opts.onText({ text, delta: text }); return { text, truncated: false, modelTierApplied: tier(opts) }; }
  sample.json = async (input, opts = {}) => { const text = await call("ai", { input, tier: tier(opts), json: true }); opts.onText && opts.onText({ text, delta: text }); return parseJSON(text); };
  sample.limits = async () => ({ maxPromptBytes: 65536 });
  window.claude = { use: async (name) => (name === "db" ? db : name === "user" ? user : name === "sample" ? sample : null) };
})();
