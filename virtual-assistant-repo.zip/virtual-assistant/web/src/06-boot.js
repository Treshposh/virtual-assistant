/* ============================================================
   06 WIRING & BOOT
   ============================================================ */
let BOOTED = false;
function resolveCard(ds, text) { const t = S.chat.turns.find((x) => x.id === ds.turn); if (t && t.cards && t.cards[+ds.i]) { t.cards[+ds.i].resolved = text; Store.save("chat"); } }

const ACT = {
  go: (d) => { closeSheetQuiet(); UI.go(d.tab); },
  close: () => closeSheet(),
  settings: () => openSettings(),
  dump: () => openDumpSheet(),
  "dump-go": () => { const v = $("#dump-text").value.trim(); if (!v) return; S.chat.turns.push({ id: uid("u"), role: "user", text: v, at: Date.now() }); trimChat(); runBrainDump(v); },
  "dump-off": () => { UI.dumpMode = false; UI.render(); },
  "dump-sel": (d) => { const it = Dump.items[+d.i]; it.sel = !it.sel; Dump.render(); },
  "dump-kind": (d) => { const it = Dump.items[+d.i]; it.kind = KINDS[(KINDS.indexOf(it.kind) + 1) % KINDS.length]; Dump.render(); },
  "dump-commit": () => Dump.commit(),
  "add-task": (d) => openAddTask({ date: d.date || null, projectId: d.project || null }),
  "add-goal": () => openAddGoal(),
  "add-habit": () => openHabit(),
  "habit-edit": (d) => openHabit(d.id),
  "habit-del": (d) => { delete S.habits.items[d.id]; Store.save("habits"); closeSheet(); },
  "hb-preset": (d) => { $("#hb-title").value = d.v; },
  pick: (d, el) => { $$(`[data-act="pick"][data-group="${d.group}"]`).forEach((b) => b.classList.toggle("on", b === el)); },
  plan: (d) => PlanSheet.open(d.date || D.today()),
  "plan-x": (d) => { PlanSheet.excluded.has(d.id) ? PlanSheet.excluded.delete(d.id) : PlanSheet.excluded.add(d.id); PlanSheet.render(); },
  "plan-approve": () => PlanSheet.approve(),
  "approve-now": (d) => { approvePlan(buildPlan(d.date)); UI.render(); UI.toast("Plan saved for " + D.label(d.date).toLowerCase() + "."); },
  "overflow-move": (d) => { for (const o of PlanSheet.pr.overflow) if (o.taskId && S.tasks.items[o.taskId]) moveTask(S.tasks.items[o.taskId], d.date, null, { reason: "overflow" }); PlanSheet.pr = buildPlan(PlanSheet.pr.date); PlanSheet.render(); UI.toast("Moved to " + D.label(d.date) + "."); },
  day: (d) => { UI.day = d.date; UI.render(); },
  block: (d) => openBlock(d.id, d.date || D.today()),
  "block-done": (d) => { const date = d.date || D.today(); const b = dayPlan(date)?.blocks.find((x) => x.id === d.id); if (b) { b.checked = true; completeBlock(b); } closeSheetQuiet(); UI.render(); },
  "block-toggle": (d) => {
    const date = d.date || D.today(); const b = dayPlan(date)?.blocks.find((x) => x.id === d.id); if (!b) return;
    if (b.type === "habit") toggleHabit(b.habitId, date);
    else { const t = S.tasks.items[b.taskId]; if (!t) return; if (t.status === "done") uncompleteTask(t.id); else { b.checked = true; completeBlock(b); } }
    UI.render();
  },
  "block-skip": (d) => { const b = dayPlan(d.date || D.today())?.blocks.find((x) => x.id === d.id); if (b) { b.status = "skipped"; b.checked = true; Store.save("plan"); logActivity("skip", { taskId: b.taskId }); } closeSheetQuiet(); UI.render(); if (b?.taskId) openReschedule(b.taskId); },
  habit: (d) => { toggleHabit(d.id, d.date || D.today()); UI.render(); },
  task: (d) => openTaskSheet(d.id),
  "toggle-task": (d) => { const t = S.tasks.items[d.id]; if (!t) return; if (t.status === "done") uncompleteTask(t.id); else completeTask(t.id); if (d.keep && UI.sheetOpen) openTaskSheet(t.parentId || t.id); else { if (UI.sheetOpen && String(UI.sheetOpen).startsWith("task:")) closeSheetQuiet(); UI.render(); } },
  "delete-task": (d) => { const t = S.tasks.items[d.id]; if (!t) return; const copy = clone(t); undoReceipt({ kind: "task", id: d.id }); closeSheet(); UI.toast("Deleted “" + copy.title + "”.", { label: "Undo", fn: () => { S.tasks.items[copy.id] = copy; Store.save("tasks"); UI.render(); } }); },
  drop: (d) => { const t = S.tasks.items[d.id]; if (!t) return; t.status = "dropped"; Object.values(S.plan.days).forEach((day) => day.blocks.forEach((b) => { if (b.taskId === t.id && b.status === "planned") b.status = "moved"; })); logActivity("drop", { taskId: t.id }); Store.save("tasks", "plan"); if (d.turn) resolveCard(d, "Dropped “" + t.title + "”"); closeSheetQuiet(); UI.render(); UI.toast("Dropped.", { label: "Undo", fn: () => { t.status = "todo"; Store.save("tasks"); UI.render(); } }); },
  "t-est": (d) => { const t = S.tasks.items[d.id]; t.estMin = +d.v; Store.save("tasks"); openTaskSheet(t.id); },
  "t-pri": (d) => { const t = S.tasks.items[d.id]; t.priority = d.v; Store.save("tasks"); openTaskSheet(t.id); },
  "t-en": (d) => { const t = S.tasks.items[d.id]; t.energy = d.v; Store.save("tasks"); openTaskSheet(t.id); },
  "t-unplan": (d) => { const t = S.tasks.items[d.id]; t.planDate = null; Object.values(S.plan.days).forEach((day) => day.blocks.forEach((b) => { if (b.taskId === t.id && b.status === "planned") b.status = "moved"; })); Store.save("tasks", "plan"); closeSheet(); },
  reschedule: (d) => openReschedule(d.id),
  "reschedule-any": () => openRescheduleAny(),
  "move-to": (d) => {
    const t = S.tasks.items[d.task]; if (!t) return;
    const st = moveTask(t, d.date, d.start !== "" && d.start != null ? +d.start : null);
    const msg = "Moved to " + D.label(d.date) + (st != null ? " at " + D.fmtTime(st) : "") + ".";
    if (d.turn) resolveCard(d, "“" + t.title + "” → " + D.label(d.date) + (st != null ? " " + D.fmtTime(st) : ""));
    closeSheetQuiet(); UI.render(); UI.toast(msg);
  },
  shrink: (d) => { const t = S.tasks.items[d.id]; const s = createTask({ title: "15 minutes: " + t.title, estMin: 15, parentId: t.id, goalId: t.goalId, projectId: t.projectId, priority: "high", planDate: D.today(), source: "shrink" }); insertIntoDay(s, D.today()); closeSheetQuiet(); UI.render(); UI.toast("Added a 15-minute version to today."); },
  lighten: () => lightenToday(),
  "lighten-apply": (d) => { const tmr = D.add(D.today(), 1); d.ids.split(",").forEach((id) => S.tasks.items[id] && moveTask(S.tasks.items[id], tmr, null, { reason: "lighten" })); closeSheet(); UI.toast("Today is lighter. Those moved to tomorrow."); },
  carry: () => { const co = carryOver(); co.forEach((t) => { t.planDate = D.today(); }); Store.save("tasks"); co.forEach((t) => logActivity("postpone", { taskId: t.id, reason: "carry" })); co.forEach((t) => (t.postponed = (t.postponed || 0) + 1)); PlanSheet.open(D.today(), { intro: co.length ? "Yesterday's unfinished work is back in the mix, weighed against today's priorities." : "" }); },
  missed: () => { const m = missedBlocksToday(); m.forEach((b) => { b.status = "skipped"; b.checked = true; }); Store.save("plan"); PlanSheet.open(D.today(), { intro: m.length + " earlier session" + (m.length > 1 ? "s" : "") + " didn't happen. Here's a realistic plan for the rest of today." }); },
  now: () => { const r = recommendNow(); openSheet(`<div class="sb">${nowRecommendationHtml(r)}</div>`, { title: "Right now" }); },
  "now-else": () => { const r = recommendNow(); const alts = r.alternatives || candidateTasks(D.today()).slice(0, 4); openSheet(`<div class="sb"><p class="small ink2">Other good options:</p><div class="card" style="padding:4px 14px">${alts.map((t) => `<div class="item"><span class="grow"><span class="title">${esc(t.title)}</span><div class="small muted">${D.dur(t.estMin)}${t.due ? " · due " + esc(D.label(t.due)) : ""}</div></span><button class="btn accent sm" data-act="focus-task" data-id="${t.id}">${icon("play")}Start</button></div>`).join("") || '<p class="small muted">Nothing else is open.</p>'}</div></div>`, { title: "Something else" }); },
  focus: (d) => { const b = dayPlan()?.blocks.find((x) => x.id === d.block); if (!b) return; Focus.start({ taskId: b.taskId, habitId: b.habitId, blockId: b.id, title: b.title, minutes: Math.max(5, b.end - Math.max(b.start, D.nowMin())) }); },
  "focus-task": (d) => startFocusTask(d.id, d.min ? +d.min : null),
  "focus-habit": (d) => { const h = S.habits.items[d.id]; if (h) Focus.start({ habitId: h.id, blockId: d.block || dayPlan()?.blocks.find((b) => b.habitId === h.id)?.id, title: h.title, minutes: h.durMin }); },
  "focus-done": () => { const c = Focus.ctx; const mins = Focus.finish(); logActual(c, mins); UI.checkin = { kind: "end", blockId: c.blockId, taskId: c.taskId, habitId: c.habitId, title: c.title, date: D.today() }; checkinAnswer("done"); },
  "focus-pause": () => Focus.pause(),
  "focus-stop": () => { const c = Focus.ctx; const mins = Focus.finish(); if (mins >= 3) logActivity("focus", { taskId: c.taskId || null, min: mins }); askHowItWent(c); },
  week: () => WeekSheet.open(),
  "week-x": (d) => { const i = +d.i; WeekSheet.off.has(i) ? WeekSheet.off.delete(i) : WeekSheet.off.add(i); WeekSheet.render(); },
  "week-apply": () => WeekSheet.apply(),
  reflow: () => openReflow(),
  "reflow-apply": () => { applyReflow(REFLOW); closeSheet(); UI.toast("Rest of today shifted."); },
  "t-rec": (d) => { const t = S.tasks.items[d.id]; t.recurrence = d.v || null; if (t.recurrence && !t.planDate && !t.due) t.planDate = D.today(); Store.save("tasks"); openTaskSheet(t.id); },
  "set-adaptive": (d) => { S.profile.adaptive = d.v === "on"; Store.save("profile"); openSettings(); },
  "brief-dismiss": (d) => { markBrief(d.k); UI.render(); },
  "brief-start": () => { const today = D.today(); markBrief("m"); if (!dayPlan(today)) { approvePlan(buildPlan(today)); UI.render(); UI.toast("Plan saved. Have a good day."); return; } const { now, next } = nowNext(today); const b = [now, next].find((x) => x && x.type !== "event"); if (b) ACT.focus({ block: b.id }); else UI.render(); },
  "wrap-move": () => { const today = D.today(), tmr = D.add(today, 1); const day = dayPlan(today); let n = 0; day.blocks.filter((b) => b.type === "task" && b.status === "planned").forEach((b) => { const t = S.tasks.items[b.taskId]; if (t && t.status !== "done") { moveTask(t, tmr, null, { reason: "wrapup" }); n++; } }); markBrief("e"); UI.render(); UI.toast(n + " moved to tomorrow.", { label: "Plan tomorrow", fn: () => PlanSheet.open(tmr) }); },
  "ci": (d) => checkinAnswer(d.v),
  "ci-start": () => { const c = UI.checkin; UI.checkin = null; const b = dayPlan(c.date)?.blocks.find((x) => x.id === c.blockId); if (b) { b.startPrompted = true; Store.save("plan"); Focus.start({ taskId: b.taskId, habitId: b.habitId, blockId: b.id, title: b.title, minutes: Math.max(5, b.end - D.nowMin()) }); } renderCheckin(); },
  "ci-later": () => { const c = UI.checkin; UI.checkin = null; const b = dayPlan(c.date)?.blocks.find((x) => x.id === c.blockId); if (b) { b.startPrompted = true; Store.save("plan"); } renderCheckin(); if (b?.taskId) openReschedule(b.taskId); },
  "ci-dismiss": () => { const c = UI.checkin; UI.checkin = null; const b = c && dayPlan(c.date)?.blocks.find((x) => x.id === c.blockId); if (b) { if (c.kind === "start") b.startPrompted = true; else b.checked = true; Store.save("plan"); } renderCheckin(); },
  stuck: (d) => openStuck(d.id || null),
  "st-chip": (d, el) => { $$("#st-chips .chip").forEach((c) => c.classList.toggle("on", c === el)); },
  "st-go": (d) => { const id = d.id || $("#st-task")?.value; const chip = $("#st-chips .chip.on")?.dataset.v || ""; const txt = $("#st-text").value.trim(); runStuck(id, [chip, txt].filter(Boolean).join(". ") || "Not sure"); },
  "st-start": () => { const t = S.tasks.items[Stuck.taskId]; const s = createTask({ title: Stuck.r.firstStep.title, estMin: Stuck.r.firstStep.estMin || 15, parentId: t?.id || null, goalId: t?.goalId, projectId: t?.projectId, priority: "high", planDate: D.today(), source: "stuck" }); insertIntoDay(s, D.today()); startFocusTask(s.id, s.estMin); },
  "st-steps": () => { const t = S.tasks.items[Stuck.taskId]; (Stuck.r.steps || []).forEach((st, i) => createTask({ title: st.title, estMin: st.estMin || 15, parentId: t?.id || null, goalId: t?.goalId, projectId: t?.projectId, isNextAction: i === 0, source: "stuck" })); UI.toast("Saved " + (Stuck.r.steps || []).length + " steps."); closeSheet(); },
  goal: (d) => { UI.goalId = d.id; UI.render(); window.scrollTo(0, 0); },
  "goal-back": () => { UI.goalId = null; UI.render(); },
  decompose: (d) => { const g = S.goals.goals[d.id]; if (!g) return; if (!AI.on) return UI.toast("The breakdown needs the assistant, which isn't available in this view."); runDecompose({ title: g.title, why: g.why, months: g.targetDate ? clamp(Math.round(D.diff(g.targetDate, D.today()) / 30.4), 1, 24) : 6, goalId: g.id }); },
  "decomp-retry": (d) => runDecompose(Decomp.last || { title: d.title, why: d.why, months: +d.months }),
  "dc-sel": (d) => { const i = +d.i; Decomp.sel.has(i) ? Decomp.sel.delete(i) : Decomp.sel.add(i); keepInputs(() => Decomp.render()); },
  "dc-hsel": (d) => { const i = +d.i; Decomp.hsel.has(i) ? Decomp.hsel.delete(i) : Decomp.hsel.add(i); keepInputs(() => Decomp.render()); },
  "dc-day": (d) => { const c = Decomp.r.commitments[+d.i]; c.days = (c.days || []).map((x) => String(x).toLowerCase().slice(0, 3)); c.days.includes(d.d) ? (c.days = c.days.filter((x) => x !== d.d)) : c.days.push(d.d); keepInputs(() => Decomp.render()); },
  "dc-commit": () => Decomp.commit(),
  "plan-week": (d) => { const g = S.goals.goals[d.id]; if (!AI.on) return UI.toast("Planning next steps needs the assistant."); const cm = currentMilestone(g.id); runDecompose({ title: g.title, why: g.why, months: g.targetDate ? clamp(Math.round(D.diff(g.targetDate, D.today()) / 30.4), 1, 24) : 6, goalId: g.id, extra: "Existing milestones: " + goalMilestones(g.id).map((m) => m.title + (m.status === "done" ? " (done)" : "")).join("; ") + ". Current milestone: " + (cm?.title || "none") + ". Open tasks: " + goalTasks(g.id).filter((t) => t.status === "todo").map((t) => t.title).join("; ") + ". Plan only the next week; keep existing milestones where sensible." }); },
  "goal-archive": (d) => { const g = S.goals.goals[d.id]; g.status = "archived"; Store.save("goals"); UI.goalId = null; UI.render(); UI.toast("Archived.", { label: "Undo", fn: () => { g.status = "active"; Store.save("goals"); UI.render(); } }); },
  "goal-why": (d) => { const g = S.goals.goals[d.id]; openSheet(`<form class="sb" data-form="goal-why" data-id="${g.id}"><textarea class="input" id="gw-text" rows="4" autofocus placeholder="Why does this matter to you?">${esc(g.why)}</textarea><button class="btn accent block" type="submit">Save</button></form>`, { title: "Why it matters" }); },
  vision: () => openSheet(`<form class="sb" data-form="vision"><p class="small ink2">One line about the life or work you're building toward. Every goal should serve it.</p><textarea class="input" id="vi-text" rows="3" autofocus>${esc(S.goals.vision)}</textarea><button class="btn accent block" type="submit">Save</button></form>`, { title: "Vision" }),
  objective: (d) => { const o = S.goals.objectives[d.id]; o.done = !o.done; Store.save("goals"); if (o.done) checkWeekly(); UI.render(); },
  "ms-done": (d) => { completeMilestone(d.id); UI.render(); UI.toast("Milestone complete. +" + S.profile.pointsRules.milestone + " points."); },
  "all-tasks": () => openAllTasks(),
  docs: () => openDocs(),
  "doc-del": async (d) => { await KB.remove(d.id); openDocs(); },
  "fact-del": (d) => { delete S.memory.facts[d.id]; Store.save("memory"); openDocs(); },
  claim: (d) => { const r = S.rewards.rules.find((x) => x.id === d.id); if (claimReward(d.id)) { closeSheetQuiet(); UI.render(); UI.toast("Enjoy it: " + r.title + "."); } },
  "rewards-edit": () => openRewards(),
  "reward-del": (d) => { S.rewards.rules = S.rewards.rules.filter((r) => r.id !== d.id); Store.save("rewards"); openRewards(); },
  review: (d) => openReview(d.week || reviewWeek()),
  "review-redo": (d) => { delete S.reviews.items[d.week]; openReview(d.week); },
  "review-apply": (d) => { const r = S.reviews.items[d.week]; let n = 0; (r?.priorities || []).forEach((p) => { const t = findTask(p.taskId || p.title); if (t) { t.priority = "high"; t.isNextAction = true; n++; } else if (p.title) { createTask({ title: p.title, priority: "high", isNextAction: true, source: "review" }); n++; } }); Store.save("tasks"); closeSheet(); UI.toast(n + " priorities set for next week."); },
  "set-pref": (d) => { S.profile[d.k] = d.v; Store.save("profile"); UI.sheetOpen === "settings" ? openSettings() : UI.render(); },
  "add-commit": () => openSheet(`<form class="sb" data-form="commit"><div class="field"><label for="cm-title">What</label><input class="input" id="cm-title" placeholder="School" autofocus></div><div class="field"><label>Days</label><div class="chips">${["mon", "tue", "wed", "thu", "fri", "sat", "sun"].map((x, i) => `<button type="button" class="chip ${i < 5 ? "on" : ""}" data-act="toggle-chip" data-v="${x}">${cap1(x)}</button>`).join("")}</div></div><div class="row"><div class="field grow"><label for="cm-s">Start</label><input class="input" type="time" id="cm-s" value="09:00"></div><div class="field grow"><label for="cm-e">End</label><input class="input" type="time" id="cm-e" value="14:00"></div></div><button class="btn accent block" type="submit">Add commitment</button></form>`, { title: "Fixed commitment" }),
  "toggle-chip": (d, el) => el.classList.toggle("on"),
  "event-del": (d) => { delete S.cal.events[d.id]; Store.save("cal"); Object.values(S.plan.days).forEach((day) => (day.blocks = day.blocks.filter((b) => b.eventId !== d.id))); Store.save("plan"); UI.sheetOpen === "settings" ? openSettings() : closeSheet(); },
  reset: () => openSheet(`<div class="sb"><p>This permanently erases your tasks, goals, plans, rewards, memory and documents${Store.mode === "cloud" ? " from your account" : ""}. It can't be undone.</p></div><div class="sf"><button class="btn ghost grow" data-act="close">Keep my data</button><button class="btn grow" style="background:var(--bad);color:#fff" data-act="reset-yes">Erase everything</button></div>`, { title: "Erase all data?" }),
  "reset-yes": async () => { for (const d of Object.values(S.kbindex.docs)) await KB.remove(d.id).catch(() => {}); S = DEFAULTS(); KEYS.forEach((k) => Store.save(k)); await Store.flush(); Onboarding.step = 0; closeSheet(); },
  "redo-onb": () => { S.profile.onboarded = false; Onboarding.step = 0; Store.save("profile"); closeSheet(); },
  voice: (d) => Voice.start(d.target || "composer"),
  suggest: (d) => sendChat(d.text),
  retry: (d) => { const i = S.chat.turns.findIndex((t) => t.id === d.id); const lastUser = [...S.chat.turns.slice(0, i)].reverse().find((t) => t.role === "user"); S.chat.turns.splice(i, 1); if (lastUser) sendChat(lastUser.text, { retry: true }); },
  undo: (d) => { const t = S.chat.turns.find((x) => x.id === d.turn); const r = t?.receipts?.[+d.i]; if (!r || r.undone) return; undoReceipt(r.undo); r.undone = true; Store.save("chat"); UI.render(); },
  "fit-add": (d) => { const t = S.chat.turns.find((x) => x.id === d.turn); const c = t?.cards?.[+d.i]; if (!c) return; const f = fitTime(c.minutes); let n = 0; f.picks.forEach((x) => { if (insertIntoDay(x, D.today()) != null || !dayPlan()) { x.planDate = D.today(); n++; } }); Store.save("tasks"); resolveCard(d, "Added " + n + " task" + (n === 1 ? "" : "s") + " to today"); UI.render(); },
  "card-dismiss": (d) => { resolveCard(d, "Kept as is"); UI.render(); },
  "card-decompose": (d) => { const t = S.chat.turns.find((x) => x.id === d.turn); const c = t.cards[+d.i]; c.resolved = "Breaking down “" + c.title + "”…"; runDecompose({ title: c.title, why: c.why, months: monthsFromWhen(c.when), card: { turn: t.id, i: +d.i } }); },
  "card-goal-save": (d) => { const t = S.chat.turns.find((x) => x.id === d.turn); const c = t.cards[+d.i]; const w = resolveWhen(c.when); const g = { id: uid("g"), title: c.title, why: c.why || "", targetDate: w?.date || D.addMonths(D.today(), 6), status: "active", createdAt: Date.now() }; S.goals.goals[g.id] = g; Store.save("goals"); resolveCard(d, "Saved goal: " + g.title); UI.render(); },
  // onboarding
  "ob-next": () => Onboarding.next(),
  "ob-back": () => Onboarding.back(),
  "ob-skip": () => { Onboarding.step++; UI.render(); },
  "ob-one": (d) => { const s = Onboarding.steps[Onboarding.step]; Onboarding.a()[s.k] = d.v; Store.save("profile"); UI.render(); },
  "ob-multi": (d) => { const s = Onboarding.steps[Onboarding.step], a = Onboarding.a(); a[s.k] = a[s.k] || []; a[s.k].includes(d.v) ? (a[s.k] = a[s.k].filter((x) => x !== d.v)) : a[s.k].push(d.v); Onboarding.capture(); UI.render(); },
  "ob-free": (d) => { Onboarding.a()[d.k] = +d.v; Store.save("profile"); UI.render(); },
  "ob-reward": (d) => { const a = Onboarding.a(); a.rewards = a.rewards || []; a.rewards.includes(d.v) ? (a.rewards = a.rewards.filter((x) => x !== d.v)) : a.rewards.push(d.v); Store.save("profile"); UI.render(); },
  "ob-tog": (d, el) => { el.classList.toggle("on"); el.innerHTML = el.classList.contains("on") ? icon("check") : ""; },
  "ob-back-q": () => { S.profile.onboarded = false; UI.render(); },
  "ob-commit": () => Onboarding.commit(),
  "ob-quick": () => { Onboarding.capture(); Onboarding.applyBasics(); S.profile.onboarded = true; if (!S.rewards.rules.length) S.rewards.rules.push({ id: uid("r"), title: "Movie night", cost: 500, claimed: 0 }); Store.save("profile", "rewards"); UI.render(); openDumpSheet(); },
};
function keepInputs(fn) { const keep = {}; $$("#sheet-slot input[id]").forEach((i) => (keep[i.id] = i.value)); fn(); for (const [k, v] of Object.entries(keep)) { const el = document.getElementById(k); if (el) el.value = v; } }

document.addEventListener("click", (e) => {
  if (e.target.matches?.("[data-scrim]")) { closeSheet(); return; }
  const el = e.target.closest("[data-act]"); if (!el) return;
  const fn = ACT[el.dataset.act]; if (!fn) return;
  e.preventDefault();
  try { const r = fn(el.dataset, el); if (r && r.catch) r.catch((err) => { console.error(err); UI.toast("Something went wrong. Try again."); }); }
  catch (err) { console.error(err); UI.toast("Something went wrong. Try again."); }
});
document.addEventListener("submit", (e) => {
  const f = e.target.closest("[data-form]"); if (!f) return; e.preventDefault();
  const k = f.dataset.form;
  try {
    if (k === "add-task") submitAddTask();
    if (k === "add-goal") submitAddGoal();
    if (k === "habit") {
      const title = $("#hb-title").value.trim(); if (!title) return;
      const v = (g, dflt) => $(`[data-act="pick"][data-group="${g}"].on`)?.dataset.v ?? dflt;
      const o = { title, perWeek: +v("hb-n", 3), durMin: +v("hb-d", 30), preferredTime: v("hb-t", "any") };
      if (f.dataset.id) { Object.assign(S.habits.items[f.dataset.id], o); Store.save("habits"); } else addHabit(o);
      closeSheet();
    }
    if (k === "add-step") { const v = $("#ts-step").value.trim(); if (!v) return; const p = S.tasks.items[f.dataset.id]; createTask({ title: v, estMin: 15, parentId: p.id, goalId: p.goalId, projectId: p.projectId, planDate: p.planDate, source: "manual" }); openTaskSheet(p.id); }
    if (k === "goal-why") { S.goals.goals[f.dataset.id].why = $("#gw-text").value.trim(); Store.save("goals"); closeSheet(); }
    if (k === "vision") { S.goals.vision = $("#vi-text").value.trim(); Store.save("goals"); closeSheet(); }
    if (k === "add-fact") { const v = $("#fact-text").value.trim(); if (v) { remember(v, "preference"); openDocs(); } }
    if (k === "add-reward") { const t = $("#rw-title").value.trim(), c = +$("#rw-cost").value; if (t && c > 0) { S.rewards.rules.push({ id: uid("r"), title: t, cost: c, claimed: 0 }); Store.save("rewards"); checkRewardUnlocks(); openRewards(); } }
    if (k === "api-key") { const v = $("#api-key").value.trim(); if (!v) return; window.__native.call("key.set", { key: v }).then(() => { NATIVE_KEY = true; AI.off = false; UI.toast("Key saved."); openSettings(); }).catch(() => UI.toast("Couldn't save the key.")); }
    if (k === "commit") { const t = $("#cm-title").value.trim(), s = $("#cm-s").value, en = $("#cm-e").value; const days = $$('[data-act="toggle-chip"].on').map((b) => DAYMAP[b.dataset.v]); if (t && s && en && days.length && D.toMin(en) > D.toMin(s)) { addEvent({ title: t, days, start: s, end: en, kind: "commitment" }); openSettings(); } else UI.toast("Add a name, days, and an end time after the start."); }
  } catch (err) { console.error(err); UI.toast("Couldn't save that. Try again."); }
});
document.addEventListener("change", (e) => {
  const el = e.target;
  if (el.dataset.pref) {
    const path = el.dataset.pref.split("."); let o = S.profile; while (path.length > 1) o = o[path.shift()];
    o[path[0]] = el.type === "number" ? Math.max(0, +el.value || 0) : el.value; Store.save("profile");
  }
  if (el.dataset.tfield) {
    const t = S.tasks.items[el.dataset.id]; if (!t) return; const f = el.dataset.tfield;
    if (f === "projectId") { t.projectId = el.value || null; const p = S.goals.projects[t.projectId]; t.goalId = p?.goalId || (t.projectId ? null : t.goalId); t.milestoneId = p?.milestoneId || null; }
    else if (f === "planDate") { if (el.value) moveTask(t, el.value); else t.planDate = null; }
    else t[f] = el.value || (f === "title" ? t.title : f === "notes" ? "" : null);
    Store.save("tasks");
  }
});
document.addEventListener("input", (e) => {
  const el = e.target;
  if (el.dataset.dumpTitle != null) Dump.items[+el.dataset.dumpTitle].title = el.value;
  if (el.dataset.dumpWhen != null) { const i = +el.dataset.dumpWhen; Dump.items[i].when = el.value; const w = resolveWhen(el.value); const l = $("#dump-wl-" + i); if (l) l.textContent = w?.date ? D.label(w.date) + (w.time ? " " + D.fmtTime(w.time) : "") : el.value ? "?" : ""; }
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && UI.sheetOpen) closeSheet(); });

/* ---------- Native (Expo) bridge: phone notifications for plan sessions ---------- */
const NATIVE = !!window.ReactNativeWebView;
let NATIVE_KEY = false, REM_T = null, REM_LAST = "";
function syncReminders() {
  if (!NATIVE || !BOOTED) return;
  const items = [], now = Date.now(), pref = S.profile.remind;
  for (const date of [D.today(), D.add(D.today(), 1)]) {
    const day = S.plan.days[date]; if (!day) continue;
    const base = D.parse(date).getTime();
    for (const b of day.blocks) {
      if (b.type === "event" || b.status !== "planned") continue;
      if (b.taskId && S.tasks.items[b.taskId]?.status === "done") continue;
      const st = base + b.start * 60000, en = base + b.end * 60000;
      if (pref !== "quiet" && st > now) items.push({ id: b.id + ":s", at: st, title: b.title, body: "Your session starts now." });
      if (pref === "checkins" && en > now) items.push({ id: b.id + ":e", at: en, title: "How did it go?", body: b.title + " — tap to check in." });
    }
  }
  const hr = D.toMin(S.profile.wake || "07:00") + 15, brief = D.parse(D.add(D.today(), 1)).getTime() + hr * 60000;
  if (pref !== "quiet") items.push({ id: "brief", at: brief, title: "Morning briefing", body: "Your plan for today is ready." });
  const sig = JSON.stringify(items); if (sig === REM_LAST) return; REM_LAST = sig;
  window.__native.call("reminders", { items: items.slice(0, 60) }).catch(() => {});
}
function markBrief(k) { const b = (S.profile.briefs = S.profile.briefs || {}); const d = D.today(); b[d] = { ...(b[d] || {}), [k]: 1 }; for (const x of Object.keys(b)) if (D.diff(d, x) > 7) delete b[x]; Store.save("profile"); }
function logActual(c, mins) {
  if (!c || !c.taskId || mins < 3) return;
  const b = c.blockId && dayPlan()?.blocks.find((x) => x.id === c.blockId);
  const est = b ? b.end - b.start : S.tasks.items[c.taskId]?.estMin;
  if (est) logActivity("actual", { taskId: c.taskId, est, min: mins });
}
async function boot() {
  UI.init(); UI.render();
  await Store.init();
  try { await Store.loadAll(); } catch (e) { Store.lastError = e; }
  if (S.profile.onb && !S.profile.onboarded) Onboarding.step = 0;
  BOOTED = true;
  if (NATIVE) { window.__native.call("key.status", {}).then((v) => (NATIVE_KEY = !!v)).catch(() => {}); Store.onChange(() => { clearTimeout(REM_T); REM_T = setTimeout(syncReminders, 1500); }); setTimeout(syncReminders, 3000); }
  Store.onChange(() => { const sy = $(".sync"); if (sy) { const tmp = document.createElement("div"); tmp.innerHTML = topbar(); const n = tmp.querySelector(".sync"); if (n) sy.replaceWith(n); } });
  UI.render();
  AI.init();
  setInterval(() => { checkinTick(); }, 20000);
  setTimeout(checkinTick, 2500);
  let lastMin = D.nowMin(), lastDay = D.today();
  setInterval(() => { // keep NOW / NEXT current without disturbing input
    const m = D.nowMin(); if (m === lastMin) return; lastMin = m;
    if (D.today() !== lastDay) { lastDay = D.today(); UI.day = null; }
    const active = document.activeElement; if (UI.sheetOpen || (active && /INPUT|TEXTAREA|SELECT/.test(active.tagName)) || UI.busy) return;
    if (UI.tab === "home" || UI.tab === "today") UI.render();
  }, 30000);
  document.addEventListener("visibilitychange", async () => {
    if (document.visibilityState !== "visible" || Store.pending() || UI.busy || UI.sheetOpen) return;
    try { await Store.loadAll(); UI.render(); checkinTick(); } catch {}
  });
  window.addEventListener("pagehide", () => { if (Store.pending()) Store.flush(); });
}
boot();
